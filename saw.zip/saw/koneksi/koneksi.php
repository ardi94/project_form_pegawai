<?php
session_start();
$servername = "localhost";
$user= "root";
$pass= "";
$dbname = "saw_topsis";
// Create connection
$conn = new mysqli($servername, $user, $pass,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>