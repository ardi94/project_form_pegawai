<?php 
    session_start();
    if(empty($_SESSION['username'])){
        header('Location: /saw');
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">

<?php 
    include "template/header/index.php";
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php 
      include "template/header/navigation.php";
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
        <?php 
            include "template/menu/index.php";
        ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <h4 class="font-weight-bold mb-0">Dashboard</h4>
                </div>
                <!-- <div>
                    <button type="button" class="btn btn-primary btn-icon-text btn-rounded">
                      <i class="ti-clipboard btn-icon-prepend"></i>Report
                    </button>
                </div> -->
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                <p>
                  <h3>
                  PT Permata Karya Jasa<br>
                  <br>
                  Gedung PGN Area Juanda<br>
                  Jl. Ir. H. Juanda, No. 4-B. RT.14/RW.4,<br>
                  Kebon Kelapa, Kecamatan Gambir,<br>
                  Kota Jakarta Pusat<br>
                  Daerah Khusus Ibukota Jakarta 10120<br>
                  Indonesia
                  
                  </h3>
                  
                </p>
                

                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2020 <a href="" target="_blank">Templatewatch</a>. Modified By Nita Candra Mulya</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="ti-heart text-danger ml-1"></i></span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php 
    include "template/footer/footer.php";
?>
</body>

</html>

