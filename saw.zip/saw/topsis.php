<?php 
    session_start();
    if(empty($_SESSION['username'])){
        header('Location: /saw');
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">

<?php 
    include "template/header/index.php";
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php 
      include "template/header/navigation.php";
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
        <?php 
            include "template/menu/index.php";
        ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <h4 class="font-weight-bold mb-0">RoyalUI Dashboard</h4>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-12">
              <div class="card">
                <div class="card-body">
                      <?php
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        //$username = "u6124251_faf";
                        //$password = "bismillah94";
                        $dbname = "saw_topsis";
                        // Create connection
                        $conn = new mysqli($servername, $username, $password,$dbname);
                        $sqlmat="select * from tbl_user tu inner join tbl_penilaian tp on tu.id=tp.id_user where jabatan='pegawai'  order by id_user asc";
                        $resulmat=mysqli_query($conn,$sqlmat);
                        $start_time = microtime(true); 
                      ?>
                        <div class="white-box">

                            <h3 class="box-title">Daftar Pegawai</h3>
                             <div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>NAMA</th>
                                            <th>C1<br>PRODUKTIVITAS</th>
                                            <th>C2<br>KOMPETENSI</th>
                                            <th>C3<br>BUDAYA</th>
                                          
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $listNilai=[];
                                            while($rowmat=mysqli_fetch_array($resulmat,MYSQLI_NUM))
                                            {
                                              $hasilNilai = json_decode($rowmat[11]);
                                              $hasilPegawai =array(
                                                round($hasilNilai[1],2),
                                                round($hasilNilai[3],2),
                                                round($hasilNilai[5],2)
                                              );
                                              $no=1;

                                              $a=0;
                                              unset($nilai);
                                              $nilai = array();
                                            
                                              for($i=0; $i<3; $i++){
                                                $nilai[$i]=$hasilPegawai[$i];
                                              }
                                              // var_dump($nilai);
                                              $listNilai[]=$nilai;
                                        ?>
                                        <tr>
                                            <td><?php  echo $rowmat['0']; ?></td>
                                            <td><?php  echo $rowmat['3']." ".$rowmat['4']; ?></td>

                                            <td><?php  echo $hasilPegawai[0]; ?></td>

                                            <td><?php  echo $hasilPegawai[1]; ?></td>
                                            <td><?php  echo $hasilPegawai[2]; ?></td>



                                        </tr>
                                        <?php
                                            $no++;
                                            $a++;
                                        }
                                        // var_dump($listNilai)
                                        ?>

                                    </tbody>
                                </table>
                            </div>
                            <hr>
                             <div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>NO1</th>
                                            <th>NAMA</th>
                                            <th>C1<br>Produktivitas</th>
                                            <th>C2<br>KOMPETENSI</th>
                                            <th>C3<br>BUDAYA</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no=1;
                                            unset($index);
                                            $index = array();
                                            $sql="select * from tbl_user tu inner join tbl_penilaian tp on tu.id=tp.id_user where jabatan='pegawai'  order by id_user asc";
                                            $result=mysqli_query($conn,$sql);
                                            $a=0;
                                            $Nil=array();
                                            $Nama=array();
                                            while($row=mysqli_fetch_array($result,MYSQLI_NUM))
                                            {
                                              $ix=$no-1;
                                              $index[$ix]=$row['0'];
                                              echo "<tr><td>".$no."</td>";
                                              echo "<td>".$row['1']."</td>";
                                              $Nama[]=$row['1'];
                                              $d=0;
                                               $hasilNilai = json_decode($row[11]);
                                              $nilai =array(
                                                $hasilNilai[1],
                                                $hasilNilai[3],
                                                $hasilNilai[5]
                                              );
                                              $Nil[] = $nilai;
                                              for($i=0; $i<3; $i++){
                                                $d=$i+4;
                                                if($i==0){
                                                  $Produktivitas=$listNilai[$no-1][$i];
                                                  if(($Produktivitas<0)&&($Produktivitas<=1)){
                                                    $nilai[$i]=1;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($Produktivitas<1)&&($Produktivitas<=2)){
                                                    $nilai[$i]=2;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($Produktivitas>2)&&($Produktivitas<=3)){
                                                    $nilai[$i]=3;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($Produktivitas>3)&&($Produktivitas<=4)){
                                                    $nilai[$i]=4;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($Produktivitas>4)&&($Produktivitas<=5)){
                                                    $nilai[$i]=5;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($Produktivitas>5)&&($Produktivitas<=6)){
                                                    $nilai[$i]=6;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }

                                                }elseif($i==1){
                                                  $KOMPETENSI=$listNilai[$no-1][$i];
                                                  if(($KOMPETENSI>0)&&($KOMPETENSI<=1)){
                                                    $nilai[$i]=1;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($KOMPETENSI>1)&&($KOMPETENSI<=2)){
                                                    $nilai[$i]=2;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($KOMPETENSI>2)&&($KOMPETENSI<=3)){
                                                    $nilai[$i]=3;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($KOMPETENSI>3)&&($KOMPETENSI<=4)){
                                                    $nilai[$i]=4;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($KOMPETENSI>4)&&($KOMPETENSI<=5)){
                                                    $nilai[$i]=5;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($KOMPETENSI>5)&&($KOMPETENSI<=6)){
                                                    $nilai[$i]=6;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }

                                                }elseif($i==2){
                                                  $BUDAYA=$listNilai[$no-1][$i];
                                                  if(($KOMPETENSI>0)&&($BUDAYA<=1)){
                                                    $nilai[$i]=1;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($BUDAYA>1)&&($BUDAYA<=2)){
                                                    $nilai[$i]=2;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($BUDAYA>2)&&($BUDAYA<=3)){
                                                    $nilai[$i]=3;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($BUDAYA>3)&&($BUDAYA<=4)){
                                                    $nilai[$i]=4;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($BUDAYA>4)&&($BUDAYA<=5)){
                                                    $nilai[$i]=5;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($BUDAYA>5)&&($BUDAYA<=6)){
                                                    $nilai[$i]=6;
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }
                                                }
                                                // elseif($i==3){
                                                //   $kehadiran=$row[$d];

                                                //   if($kehadiran<=10){
                                                //     $nilai[$a][$i]=1;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($kehadiran>10)&&($kehadiran<=11)){
                                                //     $nilai[$a][$i]=2;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($kehadiran>11)&&($kehadiran<=13)){
                                                //     $nilai[$a][$i]=3;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($kehadiran>13)&&($kehadiran<=14)){
                                                //     $nilai[$a][$i]=4;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }

                                                // }elseif($i==4){
                                                //   $sertifikat=$row[$d];
                                                //   if($sertifikat<=1){
                                                //     $nilai[$a][$i]=1;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($sertifikat==2)){
                                                //     $nilai[$a][$i]=2;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($sertifikat==3)){
                                                //     $nilai[$a][$i]=3;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($sertifikat>=4)){
                                                //     $nilai[$a][$i]=4;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }

                                                // }elseif($i==5){
                                                //   $umum=$row[$d];
                                                //   if($umum<=70){
                                                //     $nilai[$a][$i]=1;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($umum>70)&&($umum<=79)){
                                                //     $nilai[$a][$i]=2;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($umum>79)&&($umum<=89)){
                                                //     $nilai[$a][$i]=3;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($umum>89)&&($umum<=100)){
                                                //     $nilai[$a][$i]=4;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }
                                                // }elseif($i==6){
                                                //   $khusus=$row[$d];
                                                //   if($khusus<=70){
                                                //     $nilai[$a][$i]=1;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($khusus>70)&&($khusus<=79)){
                                                //     $nilai[$a][$i]=2;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($khusus>79)&&($khusus<=89)){
                                                //     $nilai[$a][$i]=3;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($khusus>89)&&($khusus<=100)){
                                                //     $nilai[$a][$i]=4;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }
                                                // }elseif($i==7){
                                                //   $mk=$row[$d];
                                                //   if($mk<=70){
                                                //     $nilai[$a][$i]=1;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($mk>70)&&($mk<=79)){
                                                //     $nilai[$a][$i]=2;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($mk>79)&&($mk<=89)){
                                                //     $nilai[$a][$i]=3;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($mk>89)&&($mk<=100)){
                                                //     $nilai[$a][$i]=4;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }
                                                // }
                                                //$nilai[$a][$i]=$row[$d];
                                               // echo ' index ['.$a.'-'.$i.'] = '.$nilai[$a][$i].' ';
                                              }
                                              //echo "<br>";

                                        ?>
                                        </tr>
                                        <?php
                                            $no++;
                                            $a++;
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            </div>

                            <?php
                            unset($Nil[0][3]);
                            // var_dump($nilai);
                             $baris=count($Nil);
                             $kolom=count($Nil[0]);
                             $nilai = $Nil;
                              $jum=0;
                            for($a=0; $a<$kolom; $a++){
                              $c=$a+1;
                                 $jum=0;

                              for($b=0; $b<$baris; $b++){
                                 $d=$b+1;
                              //  echo 'R ['.$d.' '.$c.']';
                               // echo ' ';
                                $nilai[$b][$a];
                                 $kuadrat[$a]=$nilai[$b][$a]*$nilai[$b][$a];
                                 $jum+=$kuadrat[$a];
                               ?>
                               <?php
                              }
                              // $jum.' '.' akar^2 ( '.$jum.' ) = ';
                              $jj[$a]=$jum;
                             $jumm[$a]=number_format(sqrt($jum),3);
                              ?>


                               <?php
                            }
                            ?>

                             <!--
                            Matrik Keputusan R -->
                          <hr>
                          <div style="text-align:center;">
                           <b >
                       Matrik Keputusan R
                           
                           </b> 
                          </div>
                            <hr>

                           <div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $nog=1;
                                       unset($Nil[0][3]);
                                      // var_dump($nilai);
                                      $baris=count($Nil);
                                      $kolom=count($Nil[0]);
                                       $nilai = $Nil;
                                      for($a=0; $a<$baris; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';
                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          echo round($nilai[$a][$b],2);
                                          echo '</td>';
                                        }
                                        echo " </tr>";
                                        $nog++;
                                      }
                                    ?>
                                    <tr>

                                    </tr>
                                    </tbody>
                                </table>
                            </div>

                            <!--
                           hasil normalisasi rij dari matrik r
                         -->
                               <hr>
                                <div style="text-align:center;">
                           <b>
                       hasil normalisasi rij dari matrik r
                           
                           </b> 
                           </div>
                            <hr>

                            <div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $nog=1;
                                      $baris=count($nilai);
                                      $kolom=count($nilai[1]);
                                      for($a=0; $a<$baris; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';
                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          $kuadrat[$a]=$nilai[$a][$b]*$nilai[$a][$b];
                                          echo round($kuadrat[$a],2);
                                          echo '</td>';
                                          //$jum+=$kuadrat[$a];
                                         // $jumlah[$a]=$jum;
                                        }

                                        echo " </tr>";
                                        $nog++;
                                      }
                                    ?>
                                    <tr>
                                    <td>Jumlah</td>
                                        <?php
                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          echo round($jj[$b],2);
                                          echo '</td>';
                                          //$jum+=$kuadrat[$b];
                                        }
                                        ?>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                          <!--
                            Normalisai Rij
                          -->
                             <hr>
                              <div style="text-align:center;">
                           <b>
                        Normalisai Rij
                           
                           </b> 
                           </div>
                            <hr>
                            <div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <tr>
                                    <td>Jumlah</td>
                                        <?php
                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          //echo $jj[$b];
                                          echo ' '.' akar^2 ( '.$jj[$b].' ) = ';

                                         echo $jumm[$a]=number_format(sqrt($jj[$b]),3);
                                         echo '</td>';
                                        }
                                        ?>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>




                            <!--Matrik X1-->
                            <hr>
                             <div style="text-align:center;">
                           <b>
                         Matrik X1
                           
                           </b> 
                           </div>
                            <hr>

                            <div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>]
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $nog=1;
                                       unset($Nil[0][3]);
                                      // var_dump($nilai);
                                      $baris=count($Nil);
                                     $kolom=count($Nil[0]);
                                      $nilai = $Nil;
                                      $tmp=0;
                                      $r=[];
                                      for($a=0; $a<$baris; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';

                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          echo round($nilai[$a][$b],2).' / '.round($jumm[$b],2).' = ';
                                          $tmp= number_format($nilai[$a][$b]/$jumm[$b],2);
                                          $r[$a][$b]=$tmp;
                                          echo $tmp;
                                          echo '</td>';
                                        }
                                        echo " </tr>";
                                        $nog++;
                                      }
                                    ?>
                                    <tr>

                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                          <!--  Hasil Normalisi -->
                            <hr>
                             <div style="text-align:center;">
                           <b>
                          Hasil Normalisi
                           
                           </b> 
                           </div>
                            <hr>
                            <div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $nog=1;
                                       unset($Nil[0][3]);
                                      // var_dump($nilai);
                                      $baris=count($Nil);
                                     $kolom=count($Nil[0]);
                                      $nilai = $Nil;
                                      for($a=0; $a<$baris; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';
                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          echo $r[$a][$b];
                                          echo '</td>';
                                        }
                                        echo " </tr>";
                                        $nog++;
                                      }
                                    ?>
                                    <tr>

                                    </tr>
                                    </tbody>
                                </table>
                            </div>

                        <!--    Matrik Normalisai Terbobot -->
                           <hr>
                            <div style="text-align:center;">
                           <b>
                           Matrik Normalisai Terbobot
                           
                           </b> 
                           </div>
                            <hr>
                            <div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    // $sql="select * from tbl_kriteria";
                                    // $result=mysqli_query($conn,$sql);
                                    //          $a=0;
                                    //          while($row=mysqli_fetch_array($result,MYSQLI_NUM))
                                    //          {
                                    //             $bobot[$a]=$row['2'];
                                    //             $a++;
                                    //          }
                                      $bobot= array(
                                         0.70 , 0.15 , 0.15
                                      );
                                      $nog=1;
                                       unset($Nil[0][3]);
                                      // var_dump($nilai);
                                      $baris=count($Nil);
                                     $kolom=count($Nil[0]);
                                        $nilai = $Nil;
                                      for($a=0; $a<$baris; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';
                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          echo $bobot[$b].' * '.$r[$a][$b].' = ';
                                          echo round($n[$a][$b]=$bobot[$b]*$r[$a][$b],2);
                                         // echo $r[$a][$b];
                                          echo '</td>';
                                        }
                                        echo " </tr>";
                                        $nog++;
                                      }
                                    ?>
                                    <tr>

                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                          <!--  Matrik Solusi Ideal Positif A + -->
                             <hr>
                              <div style="text-align:center;">
                           <b>
                           Matrik Solusi Ideal Negatif A +
                           
                           </b> 
                           </div>
                            <hr>
                            <div class="table-responsive table-bordered">
                                <table class="table">

                                    <tbody>
                                    <?php
                                      $nog=1;
                                       unset($Nil[0][3]);
                                      // var_dump($nilai);
                                      $baris=count($Nil);
                                     $kolom=count($Nil[0]);
                                      $nilai = $Nil;
                                      for($a=0; $a<1; $a++){
                                        echo "<tr>";
                                        for($b=0; $b<=$baris; $b++){

                                          echo "<td>";
                                          echo $b;
                                          echo "</td>";

                                        }
                                        echo "<td>MAX</td>";
                                        echo "</tr>";
                                      }
                                      for($a=0; $a<$kolom; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';
                                        for($b=0; $b<$baris; $b++){
                                          echo '<td>';
                                          echo round($n[$b][$a],2);
                                          $nill[$a][$b]=$n[$b][$a];
                                         // echo $r[$a][$b];
                                          echo '</td>';
                                        }
                                        echo "<td>".round($max=max($nill[$a]),2)."</td>";
                                        $nilaii[$a]=$max;
                                        echo " </tr>";
                                        $nog++;
                                      }
                                    ?>
                                    <tr>

                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            <?php // print_r($nilaii);  ?>

                            <!--
                            Matrik Solusi Ideal Negatif A -
                          -->
                            <hr>
                             <div style="text-align:center;">
                           <b>
                           Matrik Solusi Ideal Negatif A -
                           
                           </b> 
                           </div>
                            <hr>
                            <div class="table-responsive table-bordered">
                                <table class="table">

                                    <tbody>
                                    <?php
                                      $nog=1;
                                      unset($Nil[0][3]);
                                      // var_dump($nilai);
                                      $baris=count($Nil);
                                     $kolom=count($Nil[0]);
                                      $nilai = $Nil;
                                      for($a=0; $a<1; $a++){
                                        echo "<tr>";
                                        for($b=0; $b<=$baris; $b++){

                                          echo "<td>";
                                          echo round($b,2);
                                          echo "</td>";

                                        }
                                        echo "<td>MIN</td>";
                                        echo "</tr>";
                                      }
                                      for($a=0; $a<$kolom; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';
                                        for($b=0; $b<$baris; $b++){
                                          echo '<td>';
                                          echo round($n[$b][$a],2);
                                          $nill[$a][$b]=$n[$b][$a];
                                         // echo $r[$a][$b];
                                          echo '</td>';
                                        }
                                        echo "<td>".round($min=min($nill[$a]),2)."</td>";
                                       $nilaiii[$a]=$min;
                                        echo " </tr>";
                                        $nog++;
                                      }
                                    ?>
                                    <tr>

                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            <?php // print_r($nilaiii);  ?>

                            <?php
                              unset($Nil[0][3]);
                              // var_dump($nilai);
                              $baris=count($Nil);
                             $kolom=count($Nil[0]);
                              $nilai = $Nil;
                              $jum=0;
                              $max=0;
                          //    echo 'Y +';
                         //     echo '<br>';
                            for($a=0; $a<$kolom; $a++){
                              $e=$a+1;
                           ///   echo 'Y '.$e.'+ ';
                               for($b=0; $b<$baris; $b++){

                              $c=$a+1;
                                 $jum=0;


                                 $nill[$a][$b]=$n[$b][$a];
                                  $ba=$baris-1;
                                if($b==$ba){

                                }else{
                           //       echo ', ';
                                }


                              ?>

                               <?php
                              }
                           $max=max($nill[$a]);
                           $nilaii[$a]=$max;
                              ?>


                               <?php
                            }
                          //   print_r($nilaii);

                            ?>

                              <?php
                              unset($Nil[0][3]);
                              // var_dump($nilai);
                              $baris=count($Nil);
                             $kolom=count($Nil[0]);
                              $nilai = $Nil;
                              $jum=0;
                           //   echo 'Y -';
                           //   echo '<br>';
                            for($a=0; $a<$kolom; $a++){
                              $e=$a+1;
                          //    echo 'Y '.$e.'- ';
                               for($b=0; $b<$baris; $b++){

                              $c=$a+1;
                                 $jum=0;


                                $nill[$a][$b]=$n[$b][$a];
                                  $ba=$baris-1;
                                if($b==$ba){

                                }else{
                               //   echo ', ';
                                }


                              ?>

                               <?php
                              }
                            $max=min($nill[$a]);
                            $nilaiii[$a]=$max;
                              ?>


                               <?php
                            }

                           // print_r($nilaiii);
                            ?>

                            <hr>
                             <div style="text-align:center;">
                           <b>
                           Distance nilai terbobot solusi ideal Positif
                           
                           </b> 
                           </div>
                            <hr>
                            <div class="table-responsive table-bordered">
                                <table class="table">
                             <?php
                             unset($Nil[0][3]);
                              // var_dump($nilai);
                              $baris=count($Nil);
                             $kolom=count($Nil[0]);
                              $nilai = $Nil;
                              $jum=0;
                              $dpf=0;

                               for($b=0; $b<$baris; $b++){

                              $d=$b+1;
                              echo '<tr>';

                              $dpf=0;
                              for($a=0; $a<$kolom; $a++){
                              $c=$a+1;
                                 $jum=0;

                                echo '<td> D+ ['.round($c,2).' - '.round($d,2).'] <br>Akar^2(('.round($n[$b][$a],2).' - '.round($nilaii[$a],2).')^2)';
                                $dp=$n[$b][$a]-$nilaii[$a];
                                $dpdp=$dp*$dp;
                                echo ' = '.round($dpdp,2).'</td> ';
                                $dpf+=$dpdp;
                                //echo $kuadrat[$a]=$nilai[$b][$a]*$nilai[$b][$a];
                                //echo '='.$jum+=$kuadrat[$a];
                               ?>

                               <?php
                              }
                              $dpff=sqrt($dpf);
                              $dppf[$b]=number_format($dpff,4);

                              echo   '<td>D+ '.round($d,2).'  = akar^2('.round($dpf,2).')'.' = '.round($dppf[$b],2).'</td>';
                            // echo $jumm[$a]=number_format(sqrt($jum),3);
                              ?>

                               <?php
                                echo '<tr>';
                            }

                            ?>

                            </table>
                            </div>

                            <hr>
                             <div style="text-align:center;">
                           <b>
                           Distance nilai terbobot solusi ideal Negatif
                           
                           </b> 
                           </div>
                            <hr>

                            <div class="table-responsive table-bordered" >
                                <table class="table">
                             <?php
                              unset($Nil[0][3]);
                            // var_dump($nilai);
                             $baris=count($Nil);
                            $kolom=count($Nil[0]);
                              $nilai = $Nil;
                              $jum=0;
                              $dmf=0;

                               for($b=0; $b<$baris; $b++){

                              $d=$b+1;
                              echo '<tr>';

                              $dmf=0;
                              for($a=0; $a<$kolom; $a++){
                              $c=$a+1;
                                 $jum=0;

                                echo '<td> D - ['.round($c,2).' - '.round($d,2).'] <br> Akar^2(('.round($n[$b][$a],2).' - '.round($nilaiii[$a],2).')^2)';
                                $dm=$n[$b][$a]-$nilaiii[$a];
                                $dmdm=$dm*$dm;
                                echo ' = '.round($dmdm,2);
                                $dmf+=$dmdm;
                                //echo $kuadrat[$a]=$nilai[$b][$a]*$nilai[$b][$a];
                                //echo '='.$jum+=$kuadrat[$a];
                               ?>

                               <?php
                              }
                              $dmff=sqrt($dmf);
                              $dmmf[$b]=number_format($dmff,4);

                              echo   '<td>D- '.round($d,2).'  = akar^2('.round($dmf,2).')'.' = '.round($dmmf[$b],2).'</td>';
                            // echo $jumm[$a]=number_format(sqrt($jum),3);
                              ?>

                               <?php
                                echo '<tr>';
                            }

                            ?>

                            </table>
                            </div>
                            <hr>
                            <div class="table-responsive table-bordered" >
                                <table class="table">
                                <thead>
                                      <tr>
                                              <th>Alternatif</th>
                                              <th>NAMA</th>
                                              <th>Perhitungan</th>
                                              <th>Nilai</th>
                                        </tr>
                                    </thead>
                                     <tbody>

                            <?php
                            for($r=0;$r<$baris;$r++){
                              $rr=$r+1;
                              echo ' <tr><td>V-'.$rr.'</td>';
                              echo '<td>'.$Nama[$r].'</td><td>';
                             echo $dmmf[$r].' /  ('.$dppf[$r].' + '.$dmmf[$r].') = ';
                            // echo '<br>';
                             echo $rr;

                             $v=$dppf[$r]+$dmmf[$r];
                             $vv=number_format($dmmf[$r]/$v,3);
                             echo $vv.'</td><td>'.$vv.'</td>';
                           //  echo '<br>';
                            $ind=$index[$r];
                            echo ' </td></tr>';
                            //  $sql="update tbl_mahasiswa set nilai='$vv' where nim='$ind'";
                            //  mysqli_query($conn, $sql);
                            $rangking[$Nama[$r]]=$vv;
                           
                           }
                           arsort($rangking);
                          
                            ?>
                                  </tbody>
                                </table>
                                <hr>
                                <div class="table-responsive table-bordered">
                                <table class="table">
                                    <thead>
                                      <tr>
                                              <th>NAMA</th>
                                              <th><b>Rangking</b></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 
                                    $no=1;
                                      foreach($rangking as $key =>$val){ ?>
                                      <tr>
                                        <td><?= $key ?></td>
                                        <td><?= $no ?></td>
                                      </tr>
                                    <?php $no++;
                                  } ?>
                                    </tbody>
                                </table>
                            
                            </div>
                            <hr>
                                <?php
                           $end_time = microtime(true); 
                       
                           // Calculate script execution time 
                           $execution_time = ($end_time - $start_time); 
                          //  var_dump($rangking);
                           echo " Execution time of script = ".$execution_time." sec";
                           ?>
                            </div>
                            <hr>
                            <div class="table-responsive table-bordered" style="display:none;">
                                <table class="table">
                                    <thead>
                                      <tr>
                                              <th>NIM</th>
                                              <th>NAMA</th>

                                              <th>Hasil<br>Nilai</th>
                                              <th><b>Rangking</b></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no=1;

                                            $sql="select * from tbl_mahasiswa where id_m='".$rowmat['0']."' order by nilai desc";
                                            $result=mysqli_query($conn,$sql);
                                            $a=0;
                                            while($row=mysqli_fetch_array($result,MYSQLI_NUM))
                                            {

                                        ?>
                                        <tr>
                                            <td><?php  echo $row['0']; ?></td>
                                            <td><?php  echo $row['1']; ?></td>
                                            <td><?php  echo $row['11']; ?></td>

                                            <td><?php echo $no; ?></td>
                                        </tr>
                                        <?php
                                            $no++;
                                            $a++;
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            
                            </div>
                        </div>
                      <?php 
                    
                       ?>
                    </div>
                </div>
             </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <?php 
            include "template/footer/index.php";
        ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php 
    include "template/footer/footer.php";
?>
</body>

</html>

