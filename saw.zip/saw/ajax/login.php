<?php
include '../koneksi/koneksi.php';
function objectToArray($dd)
{
    if (is_object($dd)) {
        $dd = get_object_vars($dd);
    }

    if (is_array($dd)) {
        return array_map(__FUNCTION__, $dd);
    } else {
        // Return array
        return $dd;
    }
}

class Main {
    private $connection = "";

    public function __construct($reason, $dbparse){
        $this->connection = $dbparse;
        switch ($reason) {
            case 'login':
                $this->login();
                break;
            case 'logout':
                $this->logout();
                break;
            case 'maintainstockgroupdata':
                $this->maintainstockgroupdata();
                break;
            case 'save':
                $this->save();
                break;
            case 'edit':
                $this->edit();
                break;
            case 'saveedit':
                $this->saveedit();
                break;
            case 'delete':
                $this->delete();
                break;
            default:
                # code...
                break;
        }
    }

    private function maintainstockgroupdata() {
        $sql = "SELECT 
                    stockid,
                    stockdescription,
                    stocksales,
                    stockcashsales,
                    stockreturnsales,
                    stockpurchases,
                    stockcashpurchases,
                    stockreturnpurchases,
                    active 
                FROM stockgroup";
        $query = mysqli_query($this->connection, $sql);

        while($row = mysqli_fetch_row($query)){
            $result[] = $row;
        }

        $send = array(
            'code' => 200,
            'message' => 'success',
            'result' => $result,
        );

        echo json_encode($send);
    }

    private function save(){
        $data=json_decode($_POST['data']);
        $sql = "INSERT INTO 
                    stockgroup(
                        stockid,
                        stockdescription,
                        stocktype,
                        stocksales,
                        stockcashsales,
                        stockreturnsales,
                        stockpurchases,
                        stockcashpurchases,
                        stockreturnpurchases,
                        active 
                    ) 
                VALUES
                    ($data->code,'$data->desc',$data->costMethod,'$data->sales','$data->cashsales','$data->returnsales','$data->purchase','$data->cashpurchase','$data->returnpurchase',$data->active)";
        $query = mysqli_query($this->connection, $sql);
        if($query){
             $this->maintainstockgroupdata();
        }
    }
    
    private function login(){
        $data=json_decode($_POST['data']);
        $result = array();
        $sql = "SELECT 
                   *
                FROM tbl_user
                WHERE username ='$data->username' and password='$data->password' and jabatan = '$data->jabatan' ";
        $query = mysqli_query($this->connection, $sql);
        while($row = mysqli_fetch_row($query)){
            $result[] = $row;
            $_SESSION['id']=$row[0];
            $_SESSION['username']=$row[1];
            $_SESSION['nama_depan']=$row[3];
            $_SESSION['nama_belakang']=$row[4];
            $_SESSION['jabatan']=$row[5];
        }
        if($query){
            if($result==null){
                $send = array(
                    'code' => 204,
                    'message' => 'Username tidak dapat ditemukan'
                );
            }else{
                
                $send = array(
                    'code' => 200,
                    'message' => 'success',
                    'result' => $result,
                );
            }
             echo json_encode($send);
        }
    }
    private function logout(){
        session_destroy();
        $send = array(
            'code' => 200,
            'message' => 'success'
        );
        echo json_encode($send);
    }
    private function saveedit(){
        $data=json_decode($_POST['data']);
        $sql = "UPDATE 
                    stockgroup 
                SET
                    stockid = '$data->code',
                    stockdescription = '$data->desc',
                    stocktype = '$data->costMethod',
                    stocksales = '$data->sales',
                    stockcashsales = '$data->cashsales',
                    stockreturnsales = '$data->returnsales',
                    stockpurchases = '$data->purchase',
                    stockcashpurchases = '$data->cashpurchase',
                    stockreturnpurchases = '$data->returnpurchase',
                    active = '$data->active' 
                WHERE stockid = '$data->codeTmp'" ;
        $query = mysqli_query($this->connection, $sql);
        if($query){
            $this->maintainstockgroupdata();
        }
    }
    private function edit(){
        $data=json_decode($_POST['data']);
        $sql = "SELECT
                        stockid,
                        stockdescription,
                        stocktype,
                        stocksales,
                        stockcashsales,
                        stockreturnsales,
                        stockpurchases,
                        stockcashpurchases,
                        stockreturnpurchases,
                        active,
                        stockid as idtmp
                   FROM
                        stockgroup
                    WHERE
                        stockid='$data->id'";
        $query = mysqli_query($this->connection, $sql);
        if($query){
            while($row = mysqli_fetch_assoc($query)){
                $result[]=$row;
            }
            $send = array(
                'code' => 200,
                'message' => 'success',
                'result' => $result
            );
            echo json_encode($send);
        }
    }

    private function delete() {
        $data=json_decode($_POST['data']);
        $sql = "DELETE
                FROM
                    stockgroup
                WHERE
                    stockid='$data->id'";
        $query = mysqli_query($this->connection, $sql);
        if($query){
            $this->maintainstockgroupdata();
        }
    }

}

new Main($_POST['reason'], $conn);
