<?php
include '../koneksi/koneksi.php';
function objectToArray($dd)
{
    if (is_object($dd)) {
        $dd = get_object_vars($dd);
    }

    if (is_array($dd)) {
        return array_map(__FUNCTION__, $dd);
    } else {
        // Return array
        return $dd;
    }
}

class Main {
    private $connection = "";

    public function __construct($reason, $dbparse){
        $this->connection = $dbparse;
        switch ($reason) {
            case 'get':
                $this->get();
                break;
            case 'logout':
                $this->logout();
                break;
            case 'penilaian':
                $this->penilaian();
                break;
            case 'save':
                $this->save();
                break;
            case 'edit':
                $this->edit();
                break;
            case 'saveedit':
                $this->saveedit();
                break;
            case 'delete':
                $this->delete();
                break;
            default:
                # code...
                break;
        }
    }
    private function subArraysToString($ar, $sep = ', ') {
            $str = '';
            foreach ($ar as $val) {
                $str .= implode($sep, $val);
                $str .= $sep; // add separator between sub-arrays
            }
            $str = rtrim($str, $sep); // remove last separator
            return $str;
        }
    private function penilaian() {
        
        $data=json_decode($_POST['data']);
        $session=json_decode($_POST['session']);
        $produktivitas = json_encode($data->produktivitas);
        $budaya = json_encode($data->budaya);
        $kompetensi = json_encode($data->kompetensi);
        $hasil = json_encode($data->hasil);
        $penunjang = $data->penunjang;
        $penghambat = $data->penghambat;
        $komentar = $data->komentar;
        $kpi = json_encode($data->kpi);
        $pencapaian =json_encode($data->pencapaian);
        $bobot = json_encode($data->bobot);
       

        // $food array from example above
        
        foreach ($data->kebutuhan as $key => $value) {
            if($key==0){
                $job_enrichment = $value;
            }else if($key==1){
                $job_rotation = $value;
            }else if($key==2){
                $penugasan = $value;
            }else if($key==3){
                $training = $value;
            }
        }
        if($session->jabatan == "kepala divisi"){
             $sql = "SELECT id_user from tbl_penilaian where id_user='$data->id_user'";
             $id = $data->id_user;
        }else{
            $sql = "SELECT id_user from tbl_penilaian where id_user='$session->id'";
             $id = $session->id;

        }
        $query = mysqli_query($this->connection, $sql);
        $row = mysqli_fetch_assoc($query);
        if($row==NULL){
            $row = array();
            // echo count( $row);
        }
        if(count($row)>0){
            $sql = "UPDATE 
                        `saw_topsis`.`tbl_penilaian` 
                    SET
                        `produktivitas` = '$produktivitas',
                        `budaya` = '$budaya',
                        `kompetensi` = '$kompetensi',
                        `hasil` = '$hasil',
                        `datetime` = NOW() 
                    WHERE `id_user` = '$id'";
            $query = mysqli_query($this->connection, $sql);

            $sql = "UPDATE 
                        `saw_topsis`.`tbl_saran` 
                    SET
                        `penunjang` = '$penunjang',
                        `penghambat` = '$penghambat',
                        `job_enrichment` = '$job_enrichment',
                        `job_rotation` = '$job_rotation',
                        `penugasan` = '$penugasan',
                        `training` = '$training',
                        `komentar` = '$komentar',
                        `datetime` = NOW() 
                    WHERE `id_user` = $id' ";
            $query = mysqli_query($this->connection, $sql);

            $sql = "UPDATE 
                        `saw_topsis`.`tbl_pertanyaan` 
                    SET
                        `kpi` = '".addslashes($kpi)."',
                        `pencapaian` = '".addslashes($pencapaian)."',
                        `bobot` = '".addslashes($bobot)."',
                        `datetime` = NOW()  
                    WHERE `id_user` = '$id' ";
            
            $query = mysqli_query($this->connection, $sql);
            if(mysqli_affected_rows($this->connection)==0){
                 $sql = "INSERT INTO `saw_topsis`.`tbl_pertanyaan` (
                        `id`,
                        `id_user`,
                        `kpi`,
                        `pencapaian`,
                        `bobot`,
                        `datetime`
                        ) 
                        VALUES
                        (
                            null,
                            '$id',
                            '".addslashes($kpi)."',
                            '".addslashes($pencapaian)."',
                            '".addslashes($bobot)."',
                            NOW() 
                        ) ";
                $query = mysqli_query($this->connection, $sql);
            }
        }else{
        // exit;
            $sql = "INSERT INTO `saw_topsis`.`tbl_penilaian` (
                        `id`,
                        `id_user`,
                        `produktivitas`,
                        `budaya`,
                        `kompetensi`,
                        `hasil`,
                        `datetime`
                        ) 
                        VALUES
                        (
                            null,
                            '$id',
                            '$produktivitas',
                            '$budaya',
                            '$kompetensi',
                            '$hasil',
                            NOW()
                        )";
            // echo $sql;
            $query = mysqli_query($this->connection, $sql);
            $sql = "INSERT INTO `saw_topsis`.`tbl_saran` (
                    `id`,
                    `id_user`,
                    `penunjang`,
                    `penghambat`,
                    `job_enrichment`,
                    `job_rotation`,
                    `penugasan`,
                    `training`,
                    `komentar`,
                    `datetime`
                    ) 
                    VALUES
                    (
                        null,
                        '$id',
                        '$penunjang',
                        '$penghambat',
                        '$job_enrichment',
                        '$job_rotation',
                        '$penugasan',
                        '$training',
                        '$komentar',
                        NOW()
                    )";
            // echo $sql;
            $query = mysqli_query($this->connection, $sql);
            $sql = "INSERT INTO `saw_topsis`.`tbl_pertanyaan` (
                        `id`,
                        `id_user`,
                        `kpi`,
                        `pencapaian`,
                        `bobot`,
                        `datetime`
                        ) 
                        VALUES
                        (
                            'id',
                            '$id'',
                            '".addslashes($kpi)."',
                            '".addslashes($pencapaian)."',
                            '".addslashes($bobot)."',
                            NOW() 
                        ) ";
            $query = mysqli_query($this->connection, $sql);
        }
        $send = array(
            'code' => 200,
            'message' => 'success'
        );

        echo json_encode($send);
    }
    
    private function get(){
        $session=json_decode($_POST['session']);
        $result = array();
        if($session->jabatan=="kepala divisi"){
            $sql = "SELECT 
                    tp.id,
                    tp.id_user,
                    tp.produktivitas,
                    tp.budaya,
                    tp.kompetensi,
                    tp.hasil,
                    tp.datetime,
                    ts.penunjang,
                    ts.penghambat,
                    ts.job_enrichment,
                    ts.job_rotation,
                    ts.penugasan,
                    ts.training,
                    ts.komentar,
                    tpr.kpi,
                    tpr.pencapaian,
                    tpr.bobot,
                    tu.username,
                    tu.nama_depan,
                    tu.nama_belakang
                    FROM tbl_penilaian tp INNER JOIN tbl_saran ts ON tp.id_user = ts.id_user
                    LEFT JOIN tbl_user tu ON tp.id_user = tu.id LEFT JOIN tbl_pertanyaan tpr ON tp.id_user = tpr.id_user";
        }else{
            $sql = "SELECT 
                    tp.id,
                    tp.id_user,
                    tp.produktivitas,
                    tp.budaya,
                    tp.kompetensi,
                    tp.hasil,
                    tp.datetime,
                    ts.penunjang,
                    ts.penghambat,
                    ts.job_enrichment,
                    ts.job_rotation,
                    ts.penugasan,
                    ts.training,
                    ts.komentar,
                    tpr.kpi,
                    tpr.pencapaian,
                    tpr.bobot
                    FROM tbl_penilaian tp inner join tbl_saran ts on tp.id_user = ts.id_user LEFT JOIN tbl_pertanyaan tpr ON tp.id_user = tpr.id_user
                    WHERE tp.id_user ='$session->id'";
        }
        $query = mysqli_query($this->connection, $sql);
        while($row = mysqli_fetch_assoc($query)){
            $result[] = $row;
        }
        if($query){
            if($result==null){
                $send = array(
                    'code' => 204,
                    'message' => 'success'
                );
            }else{
                
                $send = array(
                    'code' => 200,
                    'message' => 'success',
                    'result' => $result,
                );
            }
             echo json_encode($send);
        }
    }
    private function logout(){
        unset($_SESSION['username']);
        unset($_SESSION['jabatan']);
        $send = array(
            'code' => 200,
            'message' => 'success'
        );
        echo json_encode($send);
    }
    private function saveedit(){
        $data=json_decode($_POST['data']);
        $sql = "UPDATE 
                    stockgroup 
                SET
                    stockid = '$data->code',
                    stockdescription = '$data->desc',
                    stocktype = '$data->costMethod',
                    stocksales = '$data->sales',
                    stockcashsales = '$data->cashsales',
                    stockreturnsales = '$data->returnsales',
                    stockpurchases = '$data->purchase',
                    stockcashpurchases = '$data->cashpurchase',
                    stockreturnpurchases = '$data->returnpurchase',
                    active = '$data->active' 
                WHERE stockid = '$data->codeTmp'" ;
        $query = mysqli_query($this->connection, $sql);
        if($query){
            $this->maintainstockgroupdata();
        }
    }
    private function edit(){
        $data=json_decode($_POST['data']);
        $sql = "SELECT
                        stockid,
                        stockdescription,
                        stocktype,
                        stocksales,
                        stockcashsales,
                        stockreturnsales,
                        stockpurchases,
                        stockcashpurchases,
                        stockreturnpurchases,
                        active,
                        stockid as idtmp
                   FROM
                        stockgroup
                    WHERE
                        stockid='$data->id'";
        $query = mysqli_query($this->connection, $sql);
        if($query){
            while($row = mysqli_fetch_assoc($query)){
                $result[]=$row;
            }
            $send = array(
                'code' => 200,
                'message' => 'success',
                'result' => $result
            );
            echo json_encode($send);
        }
    }

    private function delete() {
        $data=json_decode($_POST['data']);
        $sql = "DELETE
                FROM
                    stockgroup
                WHERE
                    stockid='$data->id'";
        $query = mysqli_query($this->connection, $sql);
        if($query){
            $this->maintainstockgroupdata();
        }
    }

}

new Main($_POST['reason'], $conn);
