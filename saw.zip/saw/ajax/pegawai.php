<?php
include '../koneksi/koneksi.php';
function objectToArray($dd)
{
    if (is_object($dd)) {
        $dd = get_object_vars($dd);
    }

    if (is_array($dd)) {
        return array_map(__FUNCTION__, $dd);
    } else {
        // Return array
        return $dd;
    }
}

class Main {
    private $connection = "";

    public function __construct($reason, $dbparse){
        $this->connection = $dbparse;
        switch ($reason) {
            case 'dataPegawai':
                $this->data();
                break;
            case 'save':
                $this->save();
                break;
            case 'edit':
                $this->edit();
                break;
            case 'saveedit':
                $this->saveedit();
                break;
            case 'delete':
                $this->delete();
                break;
            default:
                # code...
                break;
        }
    }

    private function data() {
        $sql = "SELECT 
                    id, username, nama_depan, nama_belakang, jabatan
                FROM tbl_user";
        $query = mysqli_query($this->connection, $sql);

        while($row = mysqli_fetch_row($query)){
            $result[] = $row;
        }

        $send = array(
            'code' => 200,
            'message' => 'success',
            'result' => $result,
        );

        echo json_encode($send);
    }

    private function save(){
        $data=json_decode($_POST['data']);
        $sql = "INSERT INTO 
                    tbl_user(
                        id, username,password, nama_depan, nama_belakang, jabatan
                    ) 
                VALUES
                    (null,'$data->username','$data->password','$data->firstname','$data->lastname','$data->jabatan')";
        $query = mysqli_query($this->connection, $sql);
        if($query){
             $this->data();
        }
    }
    
    private function saveedit(){
        $data=json_decode($_POST['data']);
        $sql = "UPDATE 
                    tbl_user 
                SET
                    username = '$data->username',
                    password = '$data->password',
                    nama_depan = '$data->firstname',
                    nama_belakang = '$data->lastname',
                    jabatan = '$data->jabatan'
                WHERE id = '$data->id'" ;
        $query = mysqli_query($this->connection, $sql);
        if($query){
            $this->data();
        }
    }
    private function edit(){
        $data=json_decode($_POST['data']);
        $sql = "SELECT
                        username,
                        nama_depan,
                        nama_belakang,
                        jabatan
                   FROM
                        tbl_user
                    WHERE
                        id='$data->id'";
        $query = mysqli_query($this->connection, $sql);
        if($query){
            while($row = mysqli_fetch_assoc($query)){
                $result[]=$row;
            }
            $send = array(
                'code' => 200,
                'message' => 'success',
                'result' => $result
            );
            echo json_encode($send);
        }
    }

    private function delete() {
        $data=json_decode($_POST['data']);
        $sql = "DELETE
                FROM
                    tbl_user
                WHERE
                    id='$data->id'";
        $query = mysqli_query($this->connection, $sql);
        if($query){
            $this->data();
        }
    }

}

new Main($_POST['reason'], $conn);
