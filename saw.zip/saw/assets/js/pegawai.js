varButton = {
    login: document.getElementById('signin'),
    logout: document.getElementById('logout'),
}
varId = {
    user: document.getElementById('username'),
    password: document.getElementById('password'),
    job: document.getElementById('pekerjaan')

}
data = {
    username: '',
    password: '',
    jabatan: '',


}
if (varButton.login != null) {

    varButton.login.onclick = function () {
        var user = false,
            pass = false,
            pekerjaan = true;
        if (varId.user.value == '') {
            alert('Isi username!');
            varId.user.focus();
        } else {
            user = true;
        }
        if (varId.password.value == '') {
            alert('Isi password!');
            varId.password.focus();
        } else {
            pass = true;
        }
        if (varId.job.value == '') {
            alert('Pilih salah satu pekerjaan!');
            varId.job.focus();
        } else {
            pekerjaan = true;
        }
        if (user == true && pass == true && pekerjaan == true) {
            data.username = varId.user.value;
            data.password = varId.password.value;
            data.jabatan = varId.job.value;
            request(JSON.stringify(data), 'login', '/ajax/login.php');
        }
        console.log(varId.user.value,
            varId.password.value,
            varId.job.value, window.location);
    }
}
if (varButton.logout != null) {
    varButton.logout.onclick = function () {
        request(JSON.stringify(data), 'logout', '/ajax/login.php');
        window.location.replace("index.php");
    }
}
dataPegawai();
function dataPegawai (){
    request(data,'dataPegawai','/ajax/pegawai.php');
}

function getPegawai (x){
    console.log(x);
    var pegawai = document.getElementById('pegawai');
    console.log(pegawai.getElementsByTagName('tbody')[0].getElementsByTagName('tr')[0]);
    var e = pegawai.getElementsByTagName('tbody')[0];
    var child = e.lastElementChild;
    while (child) {
        e.removeChild(child);
        child = e.lastElementChild;
    }
    for (var i=0; i<x.length; i++){
        var tr = document.createElement("TR");
        for(var j=0;j<x[i].length;j++){
            var td = document.createElement("TD");
            td.innerText = x[i][j];
            tr.appendChild(td);
            // console.log(td);
        }
        // < button type = "button"
        // class = "btn btn-outline-primary btn-fw" > Primary < /button>
        var td = document.createElement("TD");
        var tdOption = document.createElement("button");
        tdOption.setAttribute('type', 'button');
        tdOption.setAttribute('class', 'btn btn-outline-warning btn-sm');
        tdOption.setAttribute('data-toggle', 'modal');
        tdOption.setAttribute('data-target', '#edit');
        tdOption.setAttribute('data-id', x[i][0]);
        tdOption.setAttribute('data-username', x[i][1]);
        tdOption.setAttribute('data-firstname', x[i][2]);
        tdOption.setAttribute('data-lastname', x[i][3]);
        tdOption.setAttribute('data-jabatan', x[i][4]);
        tdOption.innerHTML = 'edit';
        td.appendChild(tdOption);
        // tr.appendChild(td);
        var tdOption1 = document.createElement("button");
        tdOption1.setAttribute('type', 'button');
        tdOption1.setAttribute('class', 'btn btn-outline-danger btn-sm');
        tdOption1.setAttribute('data-toggle', 'modal');
        tdOption1.setAttribute('data-target', '#delete');
        tdOption1.setAttribute('data-id', x[i][0]);
        tdOption1.innerHTML = 'Delete';
        td.appendChild(tdOption1);
        tr.appendChild(td);
        // console.log(tr);
        e.appendChild(tr);
    }
    console.log(e);
    
}

$('#delete').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) 
    var id = button.data('id') 
    document.getElementById('idPegawai').innerText = id;
})
$('#edit').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) 
    var id = button.data('id')
    var username = button.data('username')
    var password = button.data('password')
    var firstname = button.data('firstname')
    var lastname = button.data('lastname')
    var jabatan = button.data('jabatan')
    document.getElementById('idPegawai').innerText = id;
    document.getElementById('username').value = (username == undefined ? "" : username);
    document.getElementById('password').value = "";
    document.getElementById('firstname').value = (firstname == undefined ? "" : firstname);
    document.getElementById('lastname').value = (lastname == undefined ? "" : lastname);
    document.getElementById('jabatan').value = (jabatan == undefined ? "" : jabatan);
    document.getElementById('button').innerHTML = (id == undefined ? "Submit" : "Save Changes");
    document.getElementById('editAdd').innerHTML = (id == undefined ? "Tambah Pegawai" : "Edit Pegawai");
})

document.getElementById('button').onclick = function (){
    var Id = document.getElementById('idPegawai').innerText;
    var id = (Id == 'undefined' ? "" : Id);
    var username = document.getElementById('username').value;
    var password =document.getElementById('password').value;
    var firstname = document.getElementById('firstname').value;
    var lastname = document.getElementById('lastname').value;
    var jabatan = document.getElementById('jabatan').value;
    var check1 = (username == "" ? 1 : 0);
    var check2 = (password == "" ? 1 : 0);
    var check3 = (firstname == "" ? 1 : 0);
    var check4 = (lastname == "" ? 1 : 0);
    var check5 = (jabatan == "" ? 1 : 0);
    var method = (id == "" ? "save" : "saveedit");
    console.log(id,method);
    //  document.getElementById('idrequired').innerHTML=;
    if (check1 == 1) {
        document.getElementById('userrequired').innerHTML = 'Username harus di isi.';
        console.log();
        document.getElementById('userrequired').style.color = 'red';
    }else{
        document.getElementById('userrequired').innerHTML = '';
    }
    if (check2 == 1){
        document.getElementById('passwordrequired').innerHTML = 'password harus di isi.';
        document.getElementById('passwordrequired').style.color = 'red';
    }else{
        document.getElementById('passwordrequired').innerHTML = '';
    }
    if (check3 == 1) {
        document.getElementById('firstnamerequired').innerHTML = 'firstname harus di isi.';
        document.getElementById('firstnamerequired').style.color = 'red';
    }else{
        document.getElementById('firstnamerequired').innerHTML = '';
    }
    if (check4 == 1){
        document.getElementById('lastnamerequired').innerHTML = 'lastname harus di isi.';
        document.getElementById('lastnamerequired').style.color = 'red';
    }else{
        document.getElementById('lastnamerequired').innerHTML = '';
    }
    if (check5 == 1){
        document.getElementById('jabatanrequired').innerHTML = 'jabatan harus di isi.';
        document.getElementById('jabatanrequired').style.color = 'red';
    }else{
        document.getElementById('jabatanrequired').innerHTML = '';
    }
    if (check1 == 0 && check2 == 0 && check3 == 0 &&  check4 == 0 &&  check5 == 0) {
        var data = {
            id          : id,
            username    : username,
            password    : password,
            firstname   : firstname,
            lastname    : lastname,
            jabatan     : jabatan
        }
        request(JSON.stringify(data), method, '/ajax/pegawai.php');
    }else{
        console.log('hai');
    }
}
document.getElementById('buttonDelete').onclick = function () {
    var Id = document.getElementById('idPegawai').innerText;
    var id = (Id == undefined ? "" : Id);
    var data = {
        id: id
    }
    request(JSON.stringify(data), 'delete', '/ajax/pegawai.php');

}
function getReturned(data,method) {
    var notifText;
    var notif = document.getElementById('notification');
    if (method == "save" || method == "saveedit") {
        $('#edit').modal('hide');
        if(method == "save"){
            notif.classList.add("alert-primary");
            notifText = "Data Berhasil Disimpan";
        } else if (method == "saveedit") {
            notif.classList.add("alert-success");
            notifText = "Data Berhasil Diedit";
        }
    }else if(method == "delete"){
        notif.classList.add("alert-danger");
        notifText = "Data Berhasil Dihapus";
        $('#delete').modal('hide');
    }
    notif.textContent = notifText;
    notif.hidden = false;
    setTimeout(() => {
        notif.hidden = true;
        notif.classList.add("alert-primary");
        notif.classList.add("alert-success");
        notif.classList.add("alert-danger");
    }, 3000);
    request(data, 'dataPegawai', '/ajax/pegawai.php');
}
