varButton = {
    login: document.getElementById('signin'),
    logout: document.getElementById('logout'),
}
varId = {
    user: document.getElementById('username'),
    password: document.getElementById('password'),
    job: document.getElementById('pekerjaan')
    
}
data = {
    username: '',
    password: '',
    jabatan: ''

}
if (varButton.login != null){

    varButton.login.onclick = function () {
        var user=false,
        pass=false,
        pekerjaan=true;
        if (varId.user.value =='' ){
            alert('Isi username!');
            varId.user.focus();
        }else{
            user = true;
        }
        if (varId.password.value == '') {
            alert('Isi password!');
            varId.password.focus();
        } else {
            pass = true;
        }
        if (varId.job.value == '') {
            alert('Pilih salah satu pekerjaan!');
            varId.job.focus();
        } else {
            pekerjaan = true;
        }
        if (user == true && pass == true && pekerjaan == true){
            data.username = varId.user.value;
            data.password = varId.password.value;
            data.jabatan = varId.job.value;
            request(JSON.stringify(data), 'login', '/ajax/login.php');
        }
       console.log(varId.user.value,
       varId.password.value,
       varId.job.value, window.location);
    }
}
if (varButton.logout != null) {
    varButton.logout.onclick = function () {
    request(JSON.stringify(data), 'logout', '/ajax/login.php');
    window.location.replace("index.php");
    }
}
function request(data = null, method = null, url = null,session = null) {
    $.ajax({
        url: window.location.origin + url,
        type: 'post',
        data: {
            reason: method,
            data: data,
            session: session
        },
        success: function (hasil) {
            var hasil = JSON.parse(hasil);
            if (method == 'login') {
                if (hasil.code == 200) {
                    alert('Success Login');
                    data.username = hasil.result[0].username;
                    data.jabatan = hasil.result[0].jabatan;
                    setTimeout(function () {
                        window.location.replace("home.php");
                    }, 1000);
                }
                else if (hasil.code == 204) {
                    alert('Username or Password or Jabatan Salah!');
                }

            } else if (method == 'logout') {
                alert('Berhasil Logout');
                setTimeout(function () {
                    window.location.replace("login.php");
                }, 3000);
            } else if (method == 'get') {
                getNilai(hasil.result);
            } else if (method == 'dataPegawai') {
                getPegawai(hasil.result);
            } else if (method == 'save' || method == 'saveedit' || method == 'delete') {
                getReturned(hasil, method);
            }
        }
    });
}
function getReturned(data){

}
