

<!-- Modal -->
<div class="modal fade" id="delete" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="delete">Delete</h5>
        <button type="button" id="closeModaldelete" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <div id="idPegawai" hidden></div> 
        <div>Apakah anda yakin menghapus data pegawai ini? </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" id="buttonDelete">Delete</button>
      </div>
    </div>
  </div>
</div>

<div class="modal fade" id="edit" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="editAdd">Delete</h5>
        <button type="button" id="closeModaledit" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div id="idPegawai" hidden></div>
      <div class="modal-body">
        <div class="form-group">
            <label for="Username">Username <div id="userrequired"></div></label>
            <input type="text" class="form-control" id="username" placeholder="Username">
        </div>
        <div class="form-group">
            <label for="Password">Password <div id="passwordrequired"></div></label>
            <input type="password" class="form-control" id="password" placeholder="Username">
        </div>
        <div class="form-group">
            <label for="Nama Depan">Nama Depan <div id="firstnamerequired"></div></label>
            <input type="text" class="form-control" id="firstname" placeholder="Username">
        </div>
        <div class="form-group">
            <label for="Nama Belakang">Nama Belakang <div id="lastnamerequired"></div></label>
            <input type="text" class="form-control" id="lastname" placeholder="Username">
        </div>
         <div class="form-group">
            <label for="Jabatan">Jabatan <div id="jabatanrequired"></div></label>
            <select class="form-control" id="jabatan">
                <option value="">Pilih Jabatan</option>
                <option value="Admin">Admin</option>
                <option value="kepala divisi">Kepala Divisi</option>
                <option value="pegawai">Pegawai</option>
            </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="button" class="btn btn-primary" id="button">Delete</button>
      </div>
    </div>
  </div>
</div>

<!-- plugins:js -->
<script src="template/royal_ui/vendors/base/vendor.bundle.base.js"></script>
<!-- endinject -->
<!-- Plugin js for this page-->
<script src="template/royal_ui/vendors/chart.js/Chart.min.js"></script>
<!-- End plugin js for this page-->
<!-- inject:js -->
<script src="template/royal_ui/js/off-canvas.js"></script>
<script src="template/royal_ui/js/hoverable-collapse.js"></script>
<script src="template/royal_ui/js/template.js"></script>
<script src="template/royal_ui/js/todolist.js"></script>
<!-- endinject -->
<!-- Custom js for this page-->
<script src="template/royal_ui/js/dashboard.js"></script>

<script src="assets/js/login.js"></script>
<!-- End custom js for this page-->