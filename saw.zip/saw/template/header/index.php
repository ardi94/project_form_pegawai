<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Perkasa Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="template/royal_ui/vendors/ti-icons/css/themify-icons.css">
  <link rel="stylesheet" href="template/royal_ui/vendors/base/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <link rel="stylesheet" href="template/royal_ui/css/style.css">
  <!-- endinject -->
  <link rel="shortcut icon" href="/assets/img/LOGO_.png" />
  <style>
    #judul {
      vertical-align:middle; 
      text-align:center; 
      padding: 5px 5px 5px 5px;
    }
    #text {
      vertical-align:top; 
      padding: 5px 5px 5px 5px;
      font-size: 12px;
      
    }
    #text_end {
      vertical-align:bottom; 
      text-align:center;
      padding: 5px 5px 5px 5px;
      font-size: 12px;
      font-weight: bold;
    }
    #input {
      padding: 0px 0px 0px 40px;
      cursor: auto;
    }
    #input_ {
      padding: 0px 40px 0px 70px;
      cursor: auto;
    }
    #input__ {
      border-width:0px; 
      border:none;
      width:100%;
    }
    #input___ {
      border-width:0px; 
      border:none;
      padding: 0px 210px 0px 330px;
      cursor: auto;
    }
    #input____ {
      border-width:0px; 
      border:none;
      width:30px;
    }
    .width_ {
      width:135px;
    }
    .borderless {
      border: 0px solid #c9ccd7;
    }
    .container {
      display: block;
      position: relative;
      padding-left: 35px;
      margin-bottom: 12px;
      cursor: pointer;
      font-size: 12px;
      -webkit-user-select: none;
      -moz-user-select: none;
      -ms-user-select: none;
      user-select: none;
    }

    /* Hide the browser's default checkbox */
    .container input {
      position: absolute;
      opacity: 0;
      cursor: pointer;
      height: 0;
      width: 0;
    }

    /* Create a custom checkbox */
    .checkmark {
      position: absolute;
      top: 0;
      left: 0;
      height: 25px;
      width: 25px;
      background-color: #eee;
    }

    /* When the checkbox is checked, add a blue background */
    .container input:checked ~ .checkmark {
      background-color: black;
    }

    /* Create the checkmark/indicator (hidden when not checked) */
    .checkmark:after {
      content: "";
      position: absolute;
      display: none;
    }

    /* Show the checkmark when checked */
    .container input:checked ~ .checkmark:after {
      display: block;
    }

    /* Style the checkmark/indicator */
    .container .checkmark:after {
      left: 9px;
      top: 5px;
      width: 5px;
      height: 10px;
      border: solid white;
      border-width: 0 3px 3px 0;
      -webkit-transform: rotate(45deg);
      -ms-transform: rotate(45deg);
      transform: rotate(45deg);
    }
  </style>
</head>