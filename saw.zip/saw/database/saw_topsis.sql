-- phpMyAdmin SQL Dump
-- version 5.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 01, 2020 at 05:23 PM
-- Server version: 10.4.11-MariaDB
-- PHP Version: 7.2.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `saw_topsis`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_penilaian`
--

CREATE TABLE `tbl_penilaian` (
  `id` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `produktivitas` varchar(100) DEFAULT NULL,
  `budaya` varchar(100) DEFAULT NULL,
  `kompetensi` varchar(100) DEFAULT NULL,
  `hasil` varchar(100) DEFAULT NULL,
  `datetime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_penilaian`
--

INSERT INTO `tbl_penilaian` (`id`, `id_user`, `produktivitas`, `budaya`, `kompetensi`, `hasil`, `datetime`) VALUES
(6, 3, '[6,6,6,6,6,6,6,6,6,6,5]', '[6,6,6,6,6]', '[6,6,6,6,6,6]', '[5.91,4.14,6,0.9,6,0.9,\"\",\"\",\"Very Good\",\"Very Good\"]', '2020-07-30 06:15:43'),
(7, 19, '[5,5,5,5,6,5,5,5,5,5,5,6]', '[5,6,5,4,5]', '[5,6,5,5,5,6]', '[5.17,3.62,5,0.75,5.33,0.8,\"\",\"\",\"Very Good\",\"Very Good\"]', '2020-07-30 04:40:16');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_pertanyaan`
--

CREATE TABLE `tbl_pertanyaan` (
  `id` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `kpi` text DEFAULT NULL,
  `pencapaian` text DEFAULT NULL,
  `bobot` text DEFAULT NULL,
  `datetime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_pertanyaan`
--

INSERT INTO `tbl_pertanyaan` (`id`, `id_user`, `kpi`, `pencapaian`, `bobot`, `datetime`) VALUES
(1, 3, '[\"Update data TSAF & LTIF maksimal tanggal 15 setiap bulan\",\"Melaksanakan koordinasi & evaluasi terkait rapat P2K3\\/\\nCSC maksimal tanggal 20 setiap bulan\",\"\'Melaksanakan koordinasi & evaluasi terkait RCA maksimal\\ntanggal 20 setiap bulan\",\"Melaksanakan edukasi kesehatan 2x setahun pada Bulan Juni\\ndan November 2019\",\"Melakukan pelaporan P2K3 setiap 3 Bulan sekali maksimal\\ntanggal 20\",\"Melakukan sosialisasi PO K3\\/ IHT K3 maksimal 3 bulan sekali\",\"Melakukan sosialisasi & internalisasi budaya K3 terhadap\\npekerja baru setiap ada permintaan\",\"Melakukan pemeriksaan kesehatan pekerja & lingkungan\\npekerja maksimal Bulan November (1 tahun sekali)\",\"Melakukan monitoring terhadap pemenuhan peraturan SMK3\\nsetiap 3 bulan sekali\",\"Membuat usulan kebutuhan diklat K3 untuk pekerja internal\\nsesuai kebutuhan\",\"Melakukan penyelesaian perizinan perusahaan maksimal 1 bulan\\nsetelah dokumen lengkap\"]', '[\"Melakukan update menyesuaikan dengan Jadwal Laporan\\nPeriodik (bulanan) Pengendali Kinerja\",\"Melakukan upadate disesuaikan dengan kondisi tertentu\\nPerusahaan (CSMS, Project Surabaya)\",\"Melakukan Audit disesuaikan dengan kondisi Perusahaan\\n(project Surabaya)\",\"Edukasi Kesehatan \\\"STROKE\\\", Edukasi Kesehatan \\\"Stress\\nRelease\\\", Edukasi Kesehatan \\\"Kanker Serviks\\\"\",\"Pelaporan dilakukan pada tanggal 18 Januari 2019, 9 April\\n2019, 25 Juli 2019, 31 Oktober 2019\",\"Melakukan edukasi terhadap pekerja chiller\",\"Ikut serta dalam program sosialisasi terhadap pekerja\\ninternal baru\",\"- Melakukan MCU Pekerja dan melakukan tindak lanjut\\nhasil MCU (vaksin Hepatitis B)\",\"Melakukan review prosedur dan pemenuhan kebutuhan\\nPerusahaan terhadap peraturan K3\",\"Melakukan koordinasi kepada HR untuk pemenuhan Diklat K3\\nberdasarkan kebutuhan Perusahaan (Mengikutsertakan Irpan\\ndalam training K3 Umum)\",\"Perzinan Pusat dan Wilayah telah selesai tepat waktu\"]', '[\"5%\",\"10%\",\"10%\",\"10%\",\"10%\",\"10%\",\"5%\",\"10%\",\"5%\",\"15%\",\"10%\"]', '2020-07-30 06:15:43'),
(2, 19, '[\"Update data TSAF & LTIF maksimal tanggal 15 setiap bulan\",\"Melaksanakan koordinasi & evaluasi terkait rapat P2K3\\/\\nCSC maksimal tanggal 20 setiap bulan\",\"\'Melaksanakan koordinasi & evaluasi terkait RCA maksimal\\ntanggal 20 setiap bulan\",\"Melaksanakan edukasi kesehatan 2x setahun pada Bulan Juni\\ndan November 2019\",\"Melakukan pelaporan P2K3 setiap 3 Bulan sekali maksimal\\ntanggal 20\",\"Melakukan sosialisasi PO K3\\/ IHT K3 maksimal 3 bulan sekali\",\"Melakukan sosialisasi & internalisasi budaya K3 terhadap\\npekerja baru setiap ada permintaan\",\"Melakukan pemeriksaan kesehatan pekerja & lingkungan\\npekerja maksimal Bulan November (1 tahun sekali)\",\"Melakukan monitoring terhadap pemenuhan peraturan SMK3\\nsetiap 3 bulan sekali\",\"Melakukan pemeriksaan terhadap alat kerja setiap 1 bulan sekali\",\"Membuat usulan kebutuhan diklat K3 untuk pekerja internal\\nsesuai kebutuhan\",\"Melakukan monitoring terhadap perizinan perusahaan setiap\\n3 bulan sekali\"]', '[\"Melakukan update menyesuaikan dengan Jadwal Laporan\\nPeriodik (bulanan) Pengendali Kinerja\",\"Melakukan upadate disesuaikan dengan kondisi tertentu\\nPerusahaan (CSMS, Project Surabaya)\",\"Melakukan Audit disesuaikan dengan kondisi Perusahaan\\n(project Surabaya)\",\"Edukasi Kesehatan \\\"STROKE\\\", Edukasi Kesehatan \\\"Stress\\nRelease\\\", Edukasi Kesehatan \\\"Kanker Serviks\\\"\",\"Pelaporan dilakukan pada tanggal 18 Januari 2019, 9 April\\n2019, 25 Juli 2019, 31 Oktober 2019\",\"Melakukan edukasi terhadap pekerja chiller\",\"Ikut serta dalam program sosialisasi terhadap pekerja\\ninternal baru\",\"- Melakukan MCU Pekerja dan melakukan tindak lanjut\\nhasil MCU (vaksin Hepatitis B)\",\"Melakukan review prosedur dan pemenuhan kebutuhan\\nPerusahaan terhadap peraturan K3\",\"Melakukan koordinasi kepada Teknisi terhadap pemenuhan\\nAPD\",\"Melakukan koordinasi kepada HR untuk pemenuhan Diklat K3\\nberdasarkan kebutuhan Perusahaan (Mengikutsertakan Irpan\\ndalam training K3 Umum)\",\"Melakukan update Perizinan Pusat dan Wilayah (Pelaporan\\nKetenagakerjaan, OSS, MICE, SBU, IUJK)\"]', '[\"5%\",\"10%\",\"10%\",\"10%\",\"10%\",\"10%\",\"5%\",\"10%\",\"5%\",\"5%\",\"5%\",\"15%\"]', '2020-07-30 04:40:16'),
(4, 0, '[\"Update data TSAF & LTIF maksimal tanggal 15 setiap bulan\",\"Melaksanakan koordinasi & evaluasi terkait rapat P2K3\\/\\nCSC maksimal tanggal 20 setiap bulan\",\"\'Melaksanakan koordinasi & evaluasi terkait RCA maksimal\\ntanggal 20 setiap bulan\",\"Melaksanakan edukasi kesehatan 2x setahun pada Bulan Juni\\ndan November 2019\",\"Melakukan pelaporan P2K3 setiap 3 Bulan sekali maksimal\\ntanggal 20\",\"Melakukan sosialisasi PO K3\\/ IHT K3 maksimal 3 bulan sekali\",\"Melakukan sosialisasi & internalisasi budaya K3 terhadap\\npekerja baru setiap ada permintaan\",\"Melakukan pemeriksaan kesehatan pekerja & lingkungan\\npekerja maksimal Bulan November (1 tahun sekali)\",\"Melakukan monitoring terhadap pemenuhan peraturan SMK3\\nsetiap 3 bulan sekali\",\"Membuat usulan kebutuhan diklat K3 untuk pekerja internal\\nsesuai kebutuhan\",\"Melakukan penyelesaian perizinan perusahaan maksimal 1 bulan\\nsetelah dokumen lengkap\"]', '[\"Melakukan update menyesuaikan dengan Jadwal Laporan\\nPeriodik (bulanan) Pengendali Kinerja\",\"Melakukan upadate disesuaikan dengan kondisi tertentu\\nPerusahaan (CSMS, Project Surabaya)\",\"Melakukan Audit disesuaikan dengan kondisi Perusahaan\\n(project Surabaya)\",\"Edukasi Kesehatan \\\"STROKE\\\", Edukasi Kesehatan \\\"Stress\\nRelease\\\", Edukasi Kesehatan \\\"Kanker Serviks\\\"\",\"Pelaporan dilakukan pada tanggal 18 Januari 2019, 9 April\\n2019, 25 Juli 2019, 31 Oktober 2019\",\"Melakukan edukasi terhadap pekerja chiller\",\"Ikut serta dalam program sosialisasi terhadap pekerja\\ninternal baru\",\"- Melakukan MCU Pekerja dan melakukan tindak lanjut\\nhasil MCU (vaksin Hepatitis B)\",\"Melakukan review prosedur dan pemenuhan kebutuhan\\nPerusahaan terhadap peraturan K3\",\"Melakukan koordinasi kepada HR untuk pemenuhan Diklat K3\\nberdasarkan kebutuhan Perusahaan (Mengikutsertakan Irpan\\ndalam training K3 Umum)\",\"Perzinan Pusat dan Wilayah telah selesai tepat waktu\"]', '[\"5%\",\"10%\",\"10%\",\"10%\",\"10%\",\"10%\",\"5%\",\"10%\",\"5%\",\"15%\",\"10%\"]', '2020-07-30 06:06:05');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_saran`
--

CREATE TABLE `tbl_saran` (
  `id` int(11) NOT NULL,
  `id_user` int(11) DEFAULT NULL,
  `penunjang` varchar(50) DEFAULT NULL,
  `penghambat` varchar(50) DEFAULT NULL,
  `job_enrichment` varchar(10) DEFAULT NULL,
  `job_rotation` varchar(10) DEFAULT NULL,
  `penugasan` varchar(10) DEFAULT NULL,
  `training` varchar(10) DEFAULT NULL,
  `komentar` text DEFAULT NULL,
  `datetime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_saran`
--

INSERT INTO `tbl_saran` (`id`, `id_user`, `penunjang`, `penghambat`, `job_enrichment`, `job_rotation`, `penugasan`, `training`, `komentar`, `datetime`) VALUES
(1, 3, 'Makanan siang di tingkatkan', 'Sayurnya kurang enak', '1', '1', '1', '1', 'Komentar tersembunyi', '2020-07-30 01:36:10'),
(2, 19, 'Mobil Kantor', 'Kurangnya tunjangan', '1', '1', '1', '1', 'Sebenernya denga keadan sekarang sudah nyaman', '2020-07-30 03:38:28');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(30) NOT NULL,
  `nama_depan` varchar(50) NOT NULL,
  `nama_belakang` varchar(50) NOT NULL,
  `jabatan` varchar(25) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `username`, `password`, `nama_depan`, `nama_belakang`, `jabatan`) VALUES
(1, 'admin', 'admin', 'Super', 'Admin', 'Admin'),
(2, 'head', '12345678', 'Kepala', 'Divisi', 'kepala divisi'),
(3, 'nita', '12345678', 'Nita', 'Candra Mulya', 'pegawai'),
(19, 'paramita', '12345678', 'para', 'mita', 'pegawai');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_penilaian`
--
ALTER TABLE `tbl_penilaian`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_pertanyaan`
--
ALTER TABLE `tbl_pertanyaan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_saran`
--
ALTER TABLE `tbl_saran`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_penilaian`
--
ALTER TABLE `tbl_penilaian`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `tbl_pertanyaan`
--
ALTER TABLE `tbl_pertanyaan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `tbl_saran`
--
ALTER TABLE `tbl_saran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
