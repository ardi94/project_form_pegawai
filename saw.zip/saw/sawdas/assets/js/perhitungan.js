var select = document.querySelectorAll('#input____');
var select2 = document.querySelectorAll('#input__');
var select3 = document.querySelectorAll('#input__');
var check = document.querySelectorAll('.checkmark');
var btnSave = document.getElementById('save');
let nilai = {
    nil1: 0,
    nil2: 0,
    nil3: 0,
    nil4: 0,
    nil5: 0,
    nil6: 0
}
let hasil = {};
let penilaian = {
    produktivitas: [],
    budaya:[],
    kompetensi: [], penghambat:"",
    penunjang:"",
    kebutuhan:[],
    komentar:"",
    hasil: [],
    kpi: [],
    pencapaian: [],
    bobot: [],
    id_user:""
};
var i;
var summary;
var kelebihan;
var kekurangan;
i=0;
select.forEach(element =>{
    element.onkeyup = function () {
        getData(element.dataset.x, element.dataset.y);
    };
    element.value = 0;
});
select2.forEach(element => {
    element.onkeyup = function () {
        getData(element.dataset.x, element.dataset.y);
    };
    if (element.dataset.x<30){
        element.value = 0;
    }
});
function getData(x, y,z=null) {
    select = document.querySelectorAll('#input____');
    select2 = document.querySelectorAll('#input__');
    select3 = document.querySelectorAll('#input__');
    console.log(x, y, z, baris.length, select);
    if (x < baris.length) {
        count(select, 0, (baris.length+1), x, y);
    } else if (x > 34 && x < 41) {
        count(select2, 35, 41, x, y);
    } else if (x > 41 && x < 49) {
        count(select2, 42, 49, x, y);
    } 
    
    summary_(select, select3, check);
    if(z!=null){
        select = document.querySelectorAll('#input____');
        var length = ((select.length - 7)/6);
        select.forEach(element => {
            element.onkeyup = function () {
                getData(element.dataset.x, element.dataset.y);
            };
        });
        if (x < baris.length) {
            count(select, 0, (baris.length+1), x, y, length);
        } 
        summary_(select, select3, check);
    }
}
var rows1 = [];
var rows2 = [];
var rows3 = [];
function count(obj, iMin, iMax,x, y,z=null) {
    nilai.nil1 = 0;
    nilai.nil2 = 0;
    nilai.nil3 = 0;
    nilai.nil4 = 0;
    nilai.nil5 = 0;
    nilai.nil6 = 0;
    summary = 0;
    obj.forEach(element => {
        if (element.dataset.x == iMax) {
            
            if (element.dataset.y == 0) {
                element.value = nilai.nil1;
            } else if (element.dataset.y == 1) {
                element.value = nilai.nil2;
            } else if (element.dataset.y == 2) {
                element.value = nilai.nil3;
            } else if (element.dataset.y == 3) {
                element.value = nilai.nil4;
            } else if (element.dataset.y == 4) {
                element.value = nilai.nil5;
            } else if (element.dataset.y == 5) {
                element.value = nilai.nil6;
                Object.values(nilai).forEach(element => {
                    summary += element;
                })
            }
            if (x < 35) {
                if (z != null) {
                    element.value = (summary / z).toFixed(2);
                } else {
                    element.value = (summary / iMax).toFixed(2);
                }

                hasil.nil1 = element.value;
            } else if (x > 34 && x < 41) {
                element.value = (summary / 5).toFixed(2);
                hasil.nil2 = element.value;
            } else if (x > 41 && x < 49) {
                element.value = (summary / 6).toFixed(2);
                hasil.nil3 = element.value;
            }
        } else if (element.dataset.x == 33) {
            if (element.dataset.y == 0) {
                element.value = nilai.nil1;
            } else if (element.dataset.y == 1) {
                element.value = nilai.nil2;
            } else if (element.dataset.y == 2) {
                element.value = nilai.nil3;
            } else if (element.dataset.y == 3) {
                element.value = nilai.nil4;
            } else if (element.dataset.y == 4) {
                element.value = nilai.nil5;
            } else if (element.dataset.y == 5) {
                element.value = nilai.nil6;
                Object.values(nilai).forEach(element => {
                    summary += element;
                })
            }
        } else if (element.dataset.x == 34) {
            
            if (x < 35) {
                if (z != null) {
                    element.value = (summary / z).toFixed(2);
                } else {
                    element.value = (summary / (iMax-1)).toFixed(2);
                }

                hasil.nil1 = element.value;
            } else if (x > 34 && x < 41) {
                element.value = (summary / 5).toFixed(2);
                hasil.nil2 = element.value;
            } else if (x > 41 && x < 49) {
                element.value = (summary / 6).toFixed(2);
                hasil.nil3 = element.value;
            }
        } else if (element.dataset.x >= iMin && element.dataset.x < iMax - 1) {
            if (element.dataset.x == x) {
                if (element.dataset.y != y) {
                    if (element.value >= 0) {
                        if (element.dataset.x==0) {
                            rows1[element.dataset.y] = element.value;
                        }
                        if (element.dataset.x == 15) {
                            rows2[element.dataset.y] = element.value;
                        }
                        if (element.dataset.x == 22) {
                            rows3[element.dataset.y] = element.value;
                        }
                        element.value = 0;
                    }
                } else {
                    if (element.value == 0) {
                        element.value = 0;
                    } else {
                        // console.log(Number(y) + 1);
                        element.value = Number(y) + 1;
                    }
                }
            }
            if (element.dataset.y == 0) {
                nilai.nil1 += Number(element.value);
            } else if (element.dataset.y == 1) {
                nilai.nil2 += Number(element.value);
            } else if (element.dataset.y == 2) {
                nilai.nil3 += Number(element.value);
            } else if (element.dataset.y == 3) {
                nilai.nil4 += Number(element.value);
            } else if (element.dataset.y == 4) {
                nilai.nil5 += Number(element.value);
            } else if (element.dataset.y == 5) {
                nilai.nil6 += Number(element.value);
            }
            
        }
       
    });
}

function summary_(obj,obj2,obj3) {
    var x, y, z, total;
    x = 0;
    y = 0;
    z = 0; 
    total = 0;
    penilaian.produktivitas = [];
    penilaian.budaya = [];
    penilaian.kompetensi = [];
    penilaian.kebutuhan = [];
    console.log(penilaian.hasil);
    var penilaiansementara = penilaian.hasil[8];
    penilaian.hasil = [];
    var get = [];
    obj.forEach(element => {
        if (element.dataset.x < baris.length) {
            // penilaian.produktivitas.push((Number(element.value) == 0 ? "" : Number(element.value)));
            
            if (element.dataset.y == 0) {
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
            } else if (element.dataset.y == 1) {
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
            } else if (element.dataset.y == 2) {
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
            } else if (element.dataset.y == 3) {
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
            } else if (element.dataset.y == 4) {
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
            } else if (element.dataset.y == 5) {
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
                penilaian.produktivitas.push((Math.max(...get) == 0 ? "" : Math.max(...get)));
                get = [];
            }
        }
    });
    
    obj2.forEach(element => {
        
        if (element.dataset.x > 34 && element.dataset.x < 40) {
            if (element.dataset.y == 0){
               get.push(Number(element.value) == 0 ? 0 : Number(element.value));
            } else if (element.dataset.y == 1){
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
            } else if (element.dataset.y == 2) {
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
            } else if (element.dataset.y == 3) {
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
            } else if (element.dataset.y == 4) {
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
            } else if (element.dataset.y == 5) {
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
                // console.log(get);
                penilaian.budaya.push((Math.max(...get) == 0 ? "" : Math.max(...get)));
                get = [];
            }
        } else if (element.dataset.x > 41 && element.dataset.x < 48) {
            if (element.dataset.y == 0) {
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
            } else if (element.dataset.y == 1) {
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
            } else if (element.dataset.y == 2) {
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
            } else if (element.dataset.y == 3) {
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
            } else if (element.dataset.y == 4) {
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
            } else if (element.dataset.y == 5) {
                get.push(Number(element.value) == 0 ? 0 : Number(element.value));
                penilaian.kompetensi.push((Math.max(...get) == 0 ? "" : Math.max(...get)));
                get = [];
            }
            // penilaian.kompetensi.push((Number(element.value) == 0 ? "" : Number(element.value)));
        } else if (element.dataset.x == 50) {
             if (element.dataset.y == 0) {
                penilaian.penunjang = element.value;
             } else if (element.dataset.y == 1) {
                penilaian.penghambat = element.value;
             }
        } else if (element.dataset.x == 51) {
            if (element.dataset.y == 4) {
                penilaian.komentar = element.value;
            } 
        }
        
        if (element.dataset.x == 52) {
            if (element.dataset.y == 0) {
                element.value = (hasil.nil1 == undefined ? (element.value != "" ? element.value : 0) : hasil.nil1);
                penilaian.hasil.push(parseFloat(element.value));

                x = (hasil.nil1 == undefined ? (element.value != "" ? element.value : 0) : hasil.nil1);
            }
            if (element.dataset.y == 1) {
                y = element.value.replace("%", "");
            }
            if (element.dataset.y == 2) {
                z = (x * y)/100;
                total += z;
                element.value = z.toFixed(2);
                penilaian.hasil.push(parseFloat(element.value));
            }
            if (element.dataset.y == 3) {
                kelebihan = element.value;
            }
            if (element.dataset.y == 4) {
                console.log(element.value);
                element.value = (hasil.nil2 == undefined ? (element.value != "" ? element.value : 0) : hasil.nil2);
                x = (hasil.nil2 == undefined ? (element.value != "" ? element.value : 0) : hasil.nil2);
                penilaian.hasil.push(parseFloat(element.value));

            }
            if (element.dataset.y == 5) {
                y = element.value.replace("%", "");
            }
            if (element.dataset.y == 6) {
                z = (x * y) / 100;
                total += z;
                element.value = z.toFixed(2);
                penilaian.hasil.push(parseFloat(element.value));
            }
            if (element.dataset.y == 7) {
                element.value = (hasil.nil3 == undefined ? (element.value != "" ? element.value : 0) : hasil.nil3);
                x = (hasil.nil3 == undefined ? (element.value != "" ? element.value : 0) : hasil.nil3);
                penilaian.hasil.push(parseFloat(element.value));

            }
            if (element.dataset.y == 8) {
                y = element.value.replace("%", "");
            }
            if (element.dataset.y == 9) {
                z = (x * y) / 100;
                total += z;
                element.value = z.toFixed(2);
                penilaian.hasil.push(parseFloat(element.value));
            }
        }
        if (element.dataset.x == 53) {
            if (element.dataset.y == 0) {
                element.value = total.toFixed(2);
            }
            if (session.jabatan != "kepala divisi") {
                if (element.dataset.y == 1) {
                    if(total>=5){
                        element.value = "Very Good";
                    } else if (total >= 4 && total < 5) {
                        element.value = "Good Plus";
                    } else if (total >= 3 && total < 4) {
                        element.value = "Good";
                    } else if (total >= 2 && total < 3) {
                        element.value = "Reasonable";
                    } else if (total < 2) {
                        element.value = "Unsatisfaction";
                    }
                }
                
            }else{
                if (element.dataset.y == 1) {
                   
                    element.value = penilaiansementara;
                    
                }
                if (element.dataset.y == 2) {

                    kekurangan = element.value;

                }
                if (element.dataset.y == 3) {
                    if (total >= 5) {
                        element.value = "Very Good";
                    } else if (total >= 4 && total < 5) {
                        element.value = "Good Plus";
                    } else if (total >= 3 && total < 4) {
                        element.value = "Good";
                    } else if (total >= 2 && total < 3) {
                        element.value = "Reasonable";
                    } else if (total < 2) {
                        element.value = "Unsatisfaction";
                    }
                    penilaian.hasil.push(kelebihan);
                    penilaian.hasil.push(kekurangan);
                    penilaian.hasil.push(penilaiansementara);
                    penilaian.hasil.push(element.value);
                }

            }
        }
    });
    console.log(penilaian.hasil);
}

btnSave.onclick = function (){
    // console.log(penilaian);
    penilaian.kpi = [];
    penilaian.pencapaian = [];
    penilaian.bobot = [];
    var kpis = document.getElementsByClassName('kpi');
    for (let kpi of kpis) {
        // console.log(kpi.innerText);
        penilaian.kpi.push(kpi.innerText);
    }
    var pencapaians = document.getElementsByClassName('pencapaian');
    for (let pencapaian of pencapaians) {
        penilaian.pencapaian.push(pencapaian.innerText);

        // console.log(pencapaian.innerText);
    }
    var bobots = document.getElementsByClassName('bobot');
    for (let bobot of bobots) {
        penilaian.bobot.push(bobot.innerText);
        //  console.log(bobot.innerText);
    }
    console.log(penilaian, data);
    // penilaian.id_user = data.id_user;
    var x,y,z,no,caution,jenis;
    x = 0, y = 0,z = 0, no = 0, caution="",jenis="";
    Object.values(penilaian).forEach(element => {
        if(x==0){
            jenis = "Produktivitas";
        } else if (x == 1) {
            jenis = "Budaya";
        } else if (x == 2) {
            jenis = "Kompetensi";
        } else if (x == 3) {
            jenis = "Penunjang";
        } else if (x == 4) {
            jenis = "Penghambat";
        }
        y = 0;
        if(z!=7){
            Object.values(element).forEach(element => {
                no = y + 1;
                if (x == 1 || x == 2) {
                    if (y==0) {
                        var_ = "A";
                    } else if (y == 1) {
                        var_ = "B";
                    } else if (y == 2) {
                        var_ = "C";
                    } else if (y == 3) {
                        var_ = "D";
                    } else if (y == 4) {
                        var_ = "E";
                    } else if (y == 5) {
                        var_ = "F";
                    }
                    no = no + var_;
                } 
                if (element == ""){
                    
                    caution += "Pertanyaan atau Penilaian no " + no + ", " + jenis + " wajib diisi dengan benar.\n";
                }
                y++;
            });
        }
        z++;
    });
    penilaian.kebutuhan = [];
    check.forEach(element => {
        penilaian.kebutuhan.push((element.parentNode.childNodes[3].checked==true ? 1 : 0 ));
    });
    if (caution == "") {
        if(penilaian.budaya.length == 0 && 
            penilaian.kompetensi.length == 0 &&
            penilaian.produktivitas.length == 0 &&
            penilaian.penghambat == "" &&
            penilaian.penunjang == ""){
            caution = "Harap isi penilaian pekerja dengan benar";
            alert(caution);
        }else{
            if(Jumlahbobot.innerText=="100%"){
                if (session.jabatan == "kepala divisi") {
                    // console.log(data,penilaian);
                    request(JSON.stringify(penilaian), 'penilaian', '/ajax/penilaian.php', JSON.stringify(session));
                }else{
                    request(JSON.stringify(penilaian), 'penilaian', '/ajax/penilaian.php', JSON.stringify(session));
                }
            }else{
                caution = "Harap isi bobot produktivitas sampai 100%";
                alert(caution);
            }
        }
    }else{
        alert(caution);
    }
}
getPenilaian();
function getPenilaian(){
    request(null, 'get', '/ajax/penilaian.php', JSON.stringify(session));
}
function getNilai(result,method=null){
    console.log(result);
    if (session.jabatan != "kepala divisi"){
        pegawai.style.display = "none";

    }
    var data;
    if(method==null){
        data = result[0];
        penilaian.id_user = data.id_user;
    }else{
        data = result[method];
        penilaian.id_user = data.id_user;
        console.log(data.id_user);
    }
    var jenisData = [];
    var no = 0;
    var ii;
    var hasilakhir = penilaian.hasil[0];
    console.log(penilaian,hasilakhir);
    // var hasilsementara = JSON.parse(penilaian.hasil[0])[9];
    Object.keys(data).forEach(element => {
        // console.log(element);
        jenisData.push(element);
    });
    var nilai = [0, 0, 0, 0, 0, 0];
    var hasilAkhir = [0, 0, 0];
    Object.values(data).forEach(element => {
        if (jenisData[no] == "produktivitas"){
            penilaian.produktivitas = JSON.parse(element);
            var nomer =0;
            var xx = 0;
            Object.values(select).forEach(element => {
                if (element.dataset.x < penilaian.produktivitas.length) {
                   if (xx != element.dataset.x){
                       xx++;
                   }
                    if (element.dataset.x == xx){
                        if ((element.dataset.y) == penilaian.produktivitas[xx]-1){
                            element.value = penilaian.produktivitas[xx];
                            nilai[penilaian.produktivitas[xx] - 1] = nilai[penilaian.produktivitas[xx] - 1] + penilaian.produktivitas[xx];
                        }else{
                            element.value =0;
                        }
                    }
                } else if (element.dataset.x == 33) {
                    
                    element.value = nilai[element.dataset.y];
                } else if (element.dataset.x == 34) {
                    var summary = 0
                    Object.values(nilai).forEach(element => {
                        summary += element;
                    })
                    element.value = (summary / penilaian.produktivitas.length).toFixed(2);
                    hasilAkhir[0] = element.value;
                }
               
            });
        } else if (jenisData[no] == "budaya") {
            penilaian.budaya = JSON.parse(element);
        } else if (jenisData[no] == "kompetensi") {
            penilaian.kompetensi = JSON.parse(element);
        } else if (jenisData[no] == "penunjang") {
            penilaian.penunjang = element;
        } else if (jenisData[no] == "penghambat") {
            penilaian.penghambat = element;
        } else if (jenisData[no] == "komentar") {
            penilaian.komentar = element;
        } else if (jenisData[no] == "job_enrichment") {
            penilaian.kebutuhan.push(Number(element));
        } else if (jenisData[no] == "penugasan") {
            penilaian.kebutuhan.push(Number(element));
        } else if (jenisData[no] == "job_rotation") {
            penilaian.kebutuhan.push(Number(element));
        } else if (jenisData[no] == "training") {
            penilaian.kebutuhan.push(Number(element));
        }else if (jenisData[no] == "hasil"){
            penilaian.hasil= JSON.parse(element);
        } else if (jenisData[no] == "kpi") {
            penilaian.kpi = JSON.parse(element);
        } else if (jenisData[no] == "pencapaian") {
            penilaian.pencapaian = JSON.parse(element);
        } else if (jenisData[no] == "bobot") {
            penilaian.bobot = JSON.parse(element);
        }
        
        no++;
    });
    console.log(penilaian.hasil);

    if (penilaian.kpi.length != 0) {
        var kpis = document.getElementsByClassName('kpi');
        var i =0;
        var count = 0;
        if(kpis.length< penilaian.kpi.length){
            counts = penilaian.kpi.length - kpis.length;
            for(let ii=0; ii<counts; ii++) {
                buttonAdd.click();
            }
        }
        for (let kpi of kpis) {
            kpi.innerText = penilaian.kpi[i];
            if (penilaian.kpi[i]==undefined){
                hapusBaris.push(i);
            }
            i++;
        }
        i = 0;
        var index=0;
        hapusBaris.forEach(element => {
            if(i==0){
                index = element;
                baris[element].remove();
            }else{
                baris[index].remove();
            }
            i++;
        });
        var pencapaians = document.getElementsByClassName('pencapaian');
        i = 0;
        for (let pencapaian of pencapaians) {
            pencapaian.innerText = penilaian.pencapaian[i];
            
            i++;
        }
        var bobots = document.getElementsByClassName('bobot');
        i = 0;
        for (let bobot of bobots) {
            bobot.innerText = penilaian.bobot[i];
            i++;
        }
        update();
    }
    nilai = [0, 0, 0, 0, 0, 0];
    nilai1 = [0, 0, 0, 0, 0, 0];
    var xx=35;
    var prosentase;
    var hasil1;
    var hasil2;
    var hasil3;
    var kelebihan;
    var kekurangan;
    var predikat;
    var hasilsementara = penilaian.hasil[8];
    var hasilakhir = penilaian.hasil[9];
    console.log(penilaian, hasilakhir, hasilsementara);
    penilaian.hasil =[];
    Object.values(select2).forEach(element => {
        // console.log(element.dataset.x);
        if (xx != element.dataset.x){
            xx++;
        }
        if (element.dataset.x == xx) {
            if (element.dataset.y == penilaian.budaya[xx-35] - 1) {
                element.value = penilaian.budaya[xx - 35];
                nilai1[penilaian.budaya[xx - 35] - 1] = nilai1[penilaian.budaya[xx - 35] - 1] + penilaian.budaya[xx - 35];
            }else if(xx<40){
                element.value = 0;
            }
            if(xx==40){
                element.value = nilai1[element.dataset.y];
            }
            if(xx==41){
                summary = 0
                Object.values(nilai1).forEach(element => {
                     summary += element;
                 })
                element.value = (summary / 5).toFixed(2);
               hasilAkhir[1] = element.value;
            }
            if (element.dataset.y == penilaian.kompetensi[xx - 42] - 1) {
                // console.log(element);
                element.value = penilaian.kompetensi[xx - 42];
                nilai[penilaian.kompetensi[xx - 42] - 1] = nilai[penilaian.kompetensi[xx - 42] - 1] + penilaian.kompetensi[xx - 42];
            } else if (xx>41 && xx < 48) {
                element.value = 0;
            }
             if (xx == 48) {
                 element.value = nilai[element.dataset.y];
             }
             if (xx == 49) {
                 summary = 0
                 Object.values(nilai).forEach(element => {
                     summary += element;
                 })
                 element.value = (summary / 6).toFixed(2);
                 hasilAkhir[2] = element.value;
             }
             if (xx == 50) {
                 if (element.dataset.y == 0) {
                     element.value = penilaian.penunjang;
                 }
                 if (element.dataset.y == 1) {
                     element.value = penilaian.penghambat;
                 }
             }
             if (xx == 51) {
                element.value = penilaian.komentar;
             }
             if (xx == 52) {
                 
                 if(element.dataset.y==0){
                     element.value = hasilAkhir[0];
                     penilaian.hasil.push(parseFloat(hasilAkhir[0]));
                 }
                 if (element.dataset.y == 1) {
                     prosentase = element.value.replace("%", "");
                     hasil1 = (hasilAkhir[0] * prosentase) / 100;
                     penilaian.hasil.push(hasil1);

                     hasilAkhir[0] = hasil1;
                 }
                 if (element.dataset.y == 2) {
                     element.value = hasil1.toFixed(2);
                 }
                 if (element.dataset.y == 3) {
                     //kelebihan
                    //  console.log(element.innerText);
                     kelebihan = element.innerText;
                 }
                 if (element.dataset.y == 4) {
                     element.value = hasilAkhir[1];
                     penilaian.hasil.push(parseFloat(hasilAkhir[1]));
                 }
                 if (element.dataset.y == 5) {
                     prosentase = element.value.replace("%", "");
                     hasil2 = (hasilAkhir[1] * prosentase) / 100;
                     penilaian.hasil.push(hasil2);
                     hasilAkhir[1] = hasil2;
                 }
                 if (element.dataset.y == 6) {
                     element.value = hasil2.toFixed(2);
                 }
                 if (element.dataset.y == 7) {
                     element.value = hasilAkhir[2];
                      penilaian.hasil.push(parseFloat(hasilAkhir[2]));
                 }
                 if (element.dataset.y == 8) {
                    prosentase = element.value.replace("%", "");
                    hasil3 = (hasilAkhir[2] * prosentase) / 100;
                    penilaian.hasil.push(hasil3);
                    penilaian.hasil.push(kelebihan);
                    hasilAkhir[2] = hasil3;
                 }
                if (element.dataset.y == 9) {
                    element.value = hasil3.toFixed(2);
                }
             }
            if (xx == 53) {
                
                 if (element.dataset.y == 0) {
                     summary = 0;
                    Object.values(hasilAkhir).forEach(element => {
                        
                        summary += element;
                    })
                    element.value = summary.toFixed(2);
                }
                 if (session.jabatan != "kepala divisi") {
                    if (element.dataset.y == 1) {
                        if (summary >= 5) {
                            element.value = "Very Good";
                        } else if (summary >= 4 && summary < 5) {
                            element.value = "Good Plus";
                        } else if (summary >= 3 && summary < 4) {
                            element.value = "Good";
                        } else if (summary >= 2 && summary < 3) {
                            element.value = "Reasonable";
                        } else if (summary < 2) {
                            element.value = "Unsatisfaction";
                        }
                        predikat = element.value;
                        console.log(predikat);
                    }
                 }else{
                     console.log(penilaian.hasil);
                     if (element.dataset.y == 1) {
                        element.value = hasilsementara;
                          predikat = element.value;
                         
                     }
                     if (element.dataset.y == 3) {
                        if (hasilakhir != undefined){
                            element.value = hasilakhir;
                            predikat = element.value;
                        }else{
                            element.value = "";
                        }

                     }
                    //  if (element.dataset.y == 3) {
                    //      if (summary >= 5) {
                    //          element.value = "Very Good";
                    //      } else if (summary >= 4 && summary < 5) {
                    //          element.value = "Good Plus";
                    //      } else if (summary >= 3 && summary < 4) {
                    //          element.value = "Good";
                    //      } else if (summary >= 2 && summary < 3) {
                    //          element.value = "Reasonable";
                    //      } else if (summary < 2) {
                    //          element.value = "Unsatisfaction";
                    //      }
                    //      penilaian.hasil.push(element.value);
                    //  }
                 }
                if(element.dataset.y == 2){
                    //kekurangan
                    // console.log(element.innerText);
                    kekurangan = element.innerText;
                    penilaian.hasil.push(kekurangan);
                    penilaian.hasil.push(hasilsementara);
                    penilaian.hasil.push(hasilakhir);
                }
                
            }
        }
    });
    // penilaian.hasil.push(hasilsementara);
    // penilaian.hasil.push(hasilakhir);

    ii = 0;
    Object.values(check).forEach(element => {
        element.parentNode.childNodes[3].checked = (penilaian.kebutuhan[ii] == 1 ? true: false);
        ii++;
    });
    var hasil = document.getElementsByClassName('hasil');
    // console.log(hasil[0].value);
    Object.values(select2).forEach(element =>{
        if (element.dataset.x > 31 && element.dataset.x < 33) {
            if (element.dataset.y == 0) {
                element.value = hasil[0].value;
            }
            if (element.dataset.y == 2) {
                // element.value=getElementById('input__');
            }
            if (element.dataset.y == 4) {
                element.value = hasil[1].value;
            }
            if (element.dataset.y == 6) {
                // element.value=getElementById('input__');
            }
            if (element.dataset.y == 7) {
                element.value=hasil[2].value;
            }
            if (element.dataset.y == 9) {
                // element.value=getElementById('input__');
            }
        }
    })
    if((selectPegawai.childNodes.length-1)!=result.length){
        Object.keys(result).forEach(element => {
            var option = document.createElement("OPTION");
            option.innerText = result[element].username;
            option.value = result[element].id_user;
            selectPegawai.appendChild(option);
            if(element == 0){
                selectPegawai.value = result[element].id_user;
            }
        });
    }
   
    var submit_pegawai = document.getElementById('submit-pegawai');
    submit_pegawai.onclick = function () {
        var e = document.getElementById("select-pegawai");
        var nilaiPegawai = e.options[e.selectedIndex].value;
        Object.keys(result).forEach(element => {
             if (result[element].id_user == nilaiPegawai) {
                getNilai(result, element);
             }
        });
    }
    console.log(penilaian);
}

var buttonAdd = document.getElementById('add');
var buttonRemove = document.getElementById('remove');
var tablePenilaian = document.getElementById('form-kompetensi');
buttonAdd.onclick = function(){
    var baris = tablePenilaian.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
    var rows = baris[0].getElementsByTagName('td')[0].rowSpan;
    var row = tablePenilaian.getElementsByTagName('tbody')[0].insertRow(rows-2);
    var index = rows - 3;
    td1.innerText = (rows - 2) + ".";
    rows = rows + 1;
    baris[0].getElementsByTagName('td')[0].rowSpan = rows;
    row.setAttribute("class", "baris");
    row.id = (rows - 3);
    row.appendChild(td1);
    row.appendChild(td2);
    row.appendChild(td3);
    row.appendChild(td4);
    row.appendChild(td5);
    row.appendChild(td6);
    row.appendChild(td7);
    row.appendChild(td8);
    row.appendChild(td9);
    row.appendChild(td10);
    row.appendChild(td11);
    for (let item of row.getElementsByTagName('td')) {
        if(item.getElementsByTagName('input').length!=0){
            if (item.getElementsByTagName('input')[0].dataset.y == (penilaian.produktivitas[index] - 1)) {
                item.getElementsByTagName('input')[0].value = penilaian.produktivitas[index];
            }
        }
    }
    hapusBaris = [];
    baris = document.getElementsByClassName('baris');
    bobot = document.getElementsByClassName('bobot');
    Jumlahbobot = document.getElementsByClassName('totalBobot')[0];
    var i = 1;
    for (let item of baris) {
        item.id = i;
        item.getElementsByTagName('td')[0].innerText = i + ".";
        item.getElementsByTagName('td')[4].getElementsByTagName('input')[0].dataset.x = (i - 1);
        if (item.getElementsByTagName('td')[4].getElementsByTagName('input')[0].value == ""){
            item.getElementsByTagName('td')[4].getElementsByTagName('input')[0].value = 0;
        }
        item.getElementsByTagName('td')[5].getElementsByTagName('input')[0].dataset.x = (i - 1);
        if (item.getElementsByTagName('td')[5].getElementsByTagName('input')[0].value == "") {
            item.getElementsByTagName('td')[5].getElementsByTagName('input')[0].value = 0;
        }
        item.getElementsByTagName('td')[6].getElementsByTagName('input')[0].dataset.x = (i - 1);
        if (item.getElementsByTagName('td')[6].getElementsByTagName('input')[0].value == "") {
            item.getElementsByTagName('td')[6].getElementsByTagName('input')[0].value = 0;
        }
        item.getElementsByTagName('td')[7].getElementsByTagName('input')[0].dataset.x = (i - 1);
        if (item.getElementsByTagName('td')[7].getElementsByTagName('input')[0].value == "") {
            item.getElementsByTagName('td')[7].getElementsByTagName('input')[0].value = 0;
        }
        item.getElementsByTagName('td')[8].getElementsByTagName('input')[0].dataset.x = (i - 1);
        if (item.getElementsByTagName('td')[8].getElementsByTagName('input')[0].value == "") {
            item.getElementsByTagName('td')[8].getElementsByTagName('input')[0].value = 0;
        }
        item.getElementsByTagName('td')[9].getElementsByTagName('input')[0].dataset.x = (i - 1);
        if (item.getElementsByTagName('td')[9].getElementsByTagName('input')[0].value == "") {
            item.getElementsByTagName('td')[9].getElementsByTagName('input')[0].value = 0;
        }
        item.getElementsByTagName('td')[10].getElementsByTagName('input')[0].checked = false;
        i++;
    }
    var j = 1;
    var jumlahbobot = 0;
    for (let item of bobot) {
        item.id = j;
        var nilai = item.innerText;
            if(nilai==""){
                nilai = 0;
                item.innerText = nilai + "%";
            }else{
                nilai.replace("%", "");
            }
        var nilaibobot = parseFloat(nilai);
        jumlahbobot += nilaibobot;
        j++;
    }
    Jumlahbobot.innerText = jumlahbobot + "%";
    select = document.querySelectorAll('#input____');
    select.forEach(element => {
        element.onkeyup = function () {
            getData(element.dataset.x, element.dataset.y);
        };
    });
    var baris = tablePenilaian.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
    baris[0].getElementsByTagName('td')[0].rowSpan = i + 2;
}
var Jumlahbobot = document.getElementsByClassName('totalBobot')[0];
buttonRemove.onclick = function () {
    hapusBaris.forEach(element => {
        baris[element - 1].remove();
    })
    // console.log(baris[0].getElementsByTagName('td').getElementsByTagName('input'));
    baris = document.getElementsByClassName('baris');
    var index=0;
    for (let item of baris[0].getElementsByTagName('td')) {
        if(item.getElementsByTagName('input').length!=0){
           if(item.getElementsByTagName('input')[0].value > 0){
            console.log(item.getElementsByTagName('input')[0].value);
            index = item.getElementsByTagName('input')[0].value - 1;
           }
        }
    }
    getData(0, index);
    update();
}
function update(){
    hapusBaris = [];
    baris = document.getElementsByClassName('baris');
    bobot = document.getElementsByClassName('bobot');
    Jumlahbobot = document.getElementsByClassName('totalBobot')[0];
    var i = 1;
    for (let item of baris) {
        item.id = i;
        item.getElementsByTagName('td')[0].innerText = i + ".";
        item.getElementsByTagName('td')[10].getElementsByTagName('input')[0].checked = false;
        item.getElementsByTagName('td')[4].getElementsByTagName('input')[0].dataset.x = (i - 1);
        item.getElementsByTagName('td')[5].getElementsByTagName('input')[0].dataset.x = (i - 1);
        item.getElementsByTagName('td')[6].getElementsByTagName('input')[0].dataset.x = (i - 1);
        item.getElementsByTagName('td')[7].getElementsByTagName('input')[0].dataset.x = (i - 1);
        item.getElementsByTagName('td')[8].getElementsByTagName('input')[0].dataset.x = (i - 1);
        item.getElementsByTagName('td')[9].getElementsByTagName('input')[0].dataset.x = (i - 1);
        i++;
    }
    var j = 1;
    var jumlahbobot = 0;
    for (let item of bobot) {
        item.id = j;
        item.setAttribute("onkeyup", "javascript:dotest(this,event);");
        var nilai = item.innerText;
        nilai.replace("%", "");
        var nilaibobot = parseFloat(nilai);
        jumlahbobot += nilaibobot;
        j++;
    }

    Jumlahbobot.innerText = jumlahbobot + "%";
    var baris = tablePenilaian.getElementsByTagName('tbody')[0].getElementsByTagName('tr');
    baris[0].getElementsByTagName('td')[0].rowSpan=i+2;
}
function dotest(j,event){
    bobot = document.getElementsByClassName('bobot');
    console.log(bobot);
    var jumlahbobot = 0;
    for (let item of bobot) {
        item.id = j;
        var nilai = item.innerText;
        nilai.replace("%", "");
        if (nilai==""){
            nilai = 0;
        } else if (nilai == "%") {
            nilai = 0;
        }
        var nilaibobot = parseFloat(nilai);
        console.log(jumlahbobot,nilaibobot);
        jumlahbobot += nilaibobot;
        j++;
    }
    Jumlahbobot.innerText = jumlahbobot + "%";
}
var baris = document.getElementsByClassName('baris');
var list = document.getElementsByClassName('hapus');
var hapusBaris = [];
for (let item of list) {
    item.addEventListener("click", function () {
        if(this.checked==true){
            hapusBaris.push(this.parentNode.parentNode.id);
        }else{
            removeA(hapusBaris, this.parentNode.parentNode.id);
        }
    });
}
function removeA(arr) {
    var what, a = arguments,
        L = a.length,
        ax;
    while (L > 1 && arr.length) {
        what = a[--L];
        while ((ax = arr.indexOf(what)) !== -1) {
            arr.splice(ax, 1);
        }
    }
    return arr;
}
var namaPegawai = document.createElement("LABEL");
namaPegawai.innerText = "Nama Pegawai : ";
var pegawai = document.getElementById('namaPegawai');
var selectPegawai = document.createElement("SELECT");
// selectPegawai.setAttribute("class", "form-control");
selectPegawai.setAttribute("id", "select-pegawai");
var option = document.createElement("OPTION");
option.innerText = "Pilih Pegawai";
selectPegawai.appendChild(option);
var selectButtonPegawai = document.createElement("INPUT");
selectButtonPegawai.setAttribute("TYPE", "Button");
selectButtonPegawai.setAttribute("class", "btn btn-primary");
selectButtonPegawai.setAttribute("id", "submit-pegawai");
selectButtonPegawai.value = "Submit";

// submit_pegawai.onclick = function () {
//     console.log('hai');
// }
pegawai.appendChild(namaPegawai);
pegawai.appendChild(selectPegawai);
pegawai.appendChild(selectButtonPegawai);
// check.setAttribute("type", "check");
// document.getElementsByClassName('hapus').forEach(element=>{
//     console.log(element);
// })


// .onclick = function (){
//     console.log(this.checked);
// };

