<?php 
    session_start();
    if(empty($_SESSION['username'])){
        header('Location: /saw');
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">

<?php 
    include "template/header/index.php";
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php 
      include "template/header/navigation.php";
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
        <?php 
            include "template/menu/index.php";
        ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <h4 class="font-weight-bold mb-0">RoyalUI Dashboard</h4>
                </div>
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-sm-12">
              <div class="card">
                <div class="card-body">
                      <?php
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        //$username = "u6124251_faf";
                        //$password = "bismillah94";
                        $dbname = "saw_topsis";
                        // Create connection
                        $conn = new mysqli($servername, $username, $password,$dbname);
                        $sqlmat="select * from tbl_user tu inner join tbl_penilaian tp on tu.id=tp.id_user where jabatan='pegawai'  order by id_user asc";
                        $resulmat=mysqli_query($conn,$sqlmat);
                        
                      ?>
                        <div class="white-box">

                            <h3 class="box-title">Daftar Pegawai</h3>
                             <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>NAMA</th>
                                            <th>C1<br>PRODUKTIVITAS</th>
                                            <th>C2<br>KOMPETENSI</th>
                                            <th>C3<br>BUDAYA</th>
                                          
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                        while($rowmat=mysqli_fetch_array($resulmat,MYSQLI_NUM))
                                        {
                                          // $sql="select * from tbl_user tu inner join tbl_penilaian tp on tu.id=tp.id_user where jabatan='pegawai' ";
                                          
                                          // $result=mysqli_query($conn,$sql);
                                            $hasilNilai = json_decode($rowmat[11]);
                                            $hasilPegawai =array(
                                              $hasilNilai[1],
                                              $hasilNilai[3],
                                              $hasilNilai[5]
                                            );
                                            // $hasilNilai = explode(",",$rowmat[5]);
                                            // var_dump($hasilPegawai);
                                            $no=1;

                                          $a=0;
                                            unset($nilai);
                                            $nilai = array();
                                            
                                              for($i=0; $i<3; $i++){
                                                $nilai[$i]=$hasilPegawai[$i];
                                              }
                                              

                                        ?>
                                        <tr>
                                            <td><?php  echo $rowmat['0']; ?></td>
                                            <td><?php  echo $rowmat['3']." ".$rowmat['4']; ?></td>

                                            <td><?php  echo $hasilPegawai[0]; ?></td>

                                            <td><?php  echo $hasilPegawai[1]; ?></td>
                                            <td><?php  echo $hasilPegawai[2]; ?></td>



                                        </tr>
                                        <?php
                                            $no++;
                                            $a++;
                                            }
                                        // exit;
                                        ?>

                                    </tbody>
                                </table>
                            </div>
                             <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>NAMA</th>
                                            <th>C1<br>Produktivitas</th>
                                            <th>C2<br>KOMPETENSI</th>
                                            <th>C3<br>BUDAYA</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no=1;
                                            unset($index);
                                            $index = array();
                                            $normalisasi = array();
                                            $sql="select * from tbl_user tu inner join tbl_penilaian tp on tu.id=tp.id_user where jabatan='pegawai'  order by id_user asc";
                                            $result=mysqli_query($conn,$sql);
                                            $a=0;
                                            $Nil=array();
                                            while($row=mysqli_fetch_array($result,MYSQLI_NUM))
                                            {
                                              $ix=$no-1;
                                              $index[$ix]=$row['0'];
                                              echo "<tr><td>".$no."</td>";
                                              echo "<td>".$row['1']."</td>";

                                              $d=0;
                                               $hasilNilai = json_decode($row[11]);
                                              $nilai =array(
                                                $hasilNilai[1],
                                                $hasilNilai[3],
                                                $hasilNilai[5]
                                              );
                                              $Nil[] = $nilai;
                                              // var_dump($nilai);
                                              for($i=0; $i<3; $i++){
                                                $d=$i+4;
                                                if($i==0){
                                                  // var_dump($a,$i);
                                                  $Produktivitas=$nilai[$i];
                                                  if(($Produktivitas<0)&&($Produktivitas<=1)){
                                                    $nilai[$i]=1;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($Produktivitas<1)&&($Produktivitas<=2)){
                                                    
                                                    $nilai[$i]=2;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($Produktivitas>2)&&($Produktivitas<=3)){
                                                    $nilai[$i]=3;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($Produktivitas>3)&&($Produktivitas<=4)){
                                                    $nilai[$i]=4;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($Produktivitas>4)&&($Produktivitas<=5)){
                                                    $nilai[$i]=5;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($Produktivitas>5)&&($Produktivitas<=6)){
                                                    $nilai[$i]=6;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }

                                                }elseif($i==1){
                                                  $KOMPETENSI=$nilai[$i];
                                                  if(($KOMPETENSI>0)&&($KOMPETENSI<=1)){
                                                    $nilai[$i]=1;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($KOMPETENSI>1)&&($KOMPETENSI<=2)){
                                                    $nilai[$i]=2;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($KOMPETENSI>2)&&($KOMPETENSI<=3)){
                                                    $nilai[$i]=3;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($KOMPETENSI>3)&&($KOMPETENSI<=4)){
                                                    $nilai[$i]=4;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($KOMPETENSI>4)&&($KOMPETENSI<=5)){
                                                    $nilai[$i]=5;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($KOMPETENSI>5)&&($KOMPETENSI<=6)){
                                                    $nilai[$i]=6;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }

                                                }elseif($i==2){
                                                  $BUDAYA=$nilai[$i];
                                                  if(($KOMPETENSI>0)&&($BUDAYA<=1)){
                                                    $nilai[$i]=1;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($BUDAYA>1)&&($BUDAYA<=2)){
                                                    $nilai[$i]=2;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($BUDAYA>2)&&($BUDAYA<=3)){
                                                    $nilai[$i]=3;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($BUDAYA>3)&&($BUDAYA<=4)){
                                                    $nilai[$i]=4;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($BUDAYA>4)&&($BUDAYA<=5)){
                                                    $nilai[$i]=5;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }elseif(($BUDAYA>5)&&($BUDAYA<=6)){
                                                    $nilai[$i]=6;
                                                    $normalisasi[$i][] = $nilai[$i];
                                                    echo "<td>".$nilai[$i]. "</td>";
                                                  }
                                                }
                                              }

                                        ?>
                                        </tr>
                                        <?php
                                            $no++;
                                            $a++;
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            </div>

                            <?php
                            unset($Nil[0][3]);
                            // var_dump($nilai);
                             $baris=count($Nil);
                             $kolom=count($Nil[0]);
                             
                              $jum=0;
                            for($a=0; $a<$kolom; $a++){
                              $c=$a+1;
                                 $jum=0;

                              for($b=0; $b<$baris; $b++){
                                 $d=$b+1;
                              //  echo 'R ['.$d.' '.$c.']';
                               // echo ' ';
                                // $Nil[$b][$a];
                                 $kuadrat[$a]=$nilai[$a]*$Nil[$b][$a];
                                 $jum+=$kuadrat[$a];
                               ?>
                               <?php
                              }
                              // $jum.' '.' akar^2 ( '.$jum.' ) = ';
                              $jj[$a]=$jum;
                             $jumm[$a]=number_format(sqrt($jum),3);
                              ?>


                               <?php
                            }
                            ?>

                             <!--
                            Matrik Keputusan R -->
                          <hr>
                          <div style="text-align:center;">
                           <b >
                          Normalisasi
                           
                           </b> 
                          </div>
                            <hr>

                           <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th colspan="3">1</th>
                                            <th colspan="3">2</th>
                                            <th colspan="3">3</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                      $nog=1;
                                      $baris=count($Nil);
                                      $kolom=count($Nil[0]);
                                      $hasilNormalisasi = array();
                                      for($a=0; $a<$baris; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';
                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          echo $Nil[$a][$b];
                                        
                                          echo '<hr>';
                                          echo 'Max {';
                                          foreach($normalisasi[$b] as $key => $value){
                                            echo $value;
                                            if( $key != (count($normalisasi[$b])-1)){
                                              echo ", ";
                                            }else{
                                              echo "}";
                                            }
                                            
                                          }
                                          echo '</td>';
                                          echo '<td>';
                                          echo $Nil[$a][$b];
                                          echo '<hr>';
                                          echo max($normalisasi[$b]);
                                          echo '</td>';
                                          echo '<td>';
                                          echo '<b>'. round($Nil[$a][$b]/max($normalisasi[$b]), 3) .'</b>';
                                          $hasilNormalisasi[$a][$b]=round($Nil[$a][$b] /max( $normalisasi[$b]), 3);
                                          echo '</td>';

                                        }
                                        echo " </tr>";
                                        $nog++;
                                      }
                                      // var_dump( $hasilNormalisasi[0][1]);
                                    ?>
                                    <tr>

                                    </tr>
                                    </tbody>
                                </table>
                            </div>

                            <!--
                           hasil normalisasi rij dari matrik r
                         -->
                               <hr>
                                <div style="text-align:center;">
                           <b>
                         hasil normalisasi
                           
                           </b> 
                           </div>
                            <hr>

                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $nog=1;
                                      $baris=count($Nil);
                                      $kolom=count($Nil[0]);
                                      for($a=0; $a<$baris; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';
                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          echo $hasilNormalisasi[$a][$b];
                                          echo '</td>';
                                          //$jum+=$kuadrat[$a];
                                         // $jumlah[$a]=$jum;
                                        }

                                        echo " </tr>";
                                        $nog++;
                                      }
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                          <!--
                            Normalisai Rij
                          -->
                             <hr>
                              <div style="text-align:center;">
                           <b>
                          Normalisai Rij
                           
                           </b> 
                           </div>
                            <hr>
                            <div class="table-responsive">
                            <?php 
                              $w = array(
                                0.70 , 0.15 , 0.15
                              );
                            ?>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <tr>
                                    <td>W</td>
                                   <?php 
                                    foreach($w as $value){
                                      echo "<td>".$value."</td>";
                                    }
                                   ?>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>


                            <!--Matrik X1-->
                            <hr>
                             <div style="text-align:center;">
                           <b>
                         Normalisai x W
                           
                           </b> 
                           </div>
                            <hr>

                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $nog=1;
                                      $baris=count($Nil);
                                      $kolom=count($Nil[0]);
                                      $tmp=0;
                                      $r=[];
                                      for($a=0; $a<$baris; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';

                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          echo $w[$b].' * '.$hasilNormalisasi[$a][$b].' = ';
                                          $tmp= number_format($w[$b]*$hasilNormalisasi[$a][$b],3);
                                          $r[$a][$b]=$tmp;
                                          echo $tmp;
                                          echo '</td>';
                                        }
                                        echo " </tr>";
                                        $nog++;
                                      }
                                    ?>
                                    <tr>

                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                          <!--  Hasil Normalisi -->
                            <hr>
                             <div style="text-align:center;">
                           <b>
                          Hasil Normalisi * W
                           
                           </b> 
                           </div>
                            <hr>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>
                                            <th>Hasil</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $nog=1;
                                      $baris=count($Nil);
                                      $kolom=count($Nil[0]);
                                      $hasil = array(0,0,0);
                                      for($a=0; $a<$baris; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';
                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          $hasil[$a]+=$r[$a][$b];
                                          echo $r[$a][$b];
                                          echo '</td>';
                                        }
                                        echo '<td><b>'.$hasil[$a].'</b></td>';
                                        echo " </tr>";
                                        $nog++;
                                      }
                                      echo "<tr>";
                                      echo "</tr>";
                                    ?>
                                    </tbody>
                                </table>
                            </div>
                         
                            
                        </div>
                      <?php 
                    // }
                       ?>
                    </div>
                </div>
             </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->
        <?php 
            include "template/footer/index.php";
        ?>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php 
    include "template/footer/footer.php";
?>
</body>

</html>

