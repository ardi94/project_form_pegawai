<nav class="sidebar sidebar-offcanvas" id="sidebar">
  <ul class="nav">
    
    
    <!-- <li class="nav-item">
      <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
        <i class="ti-palette menu-icon"></i>
        <span class="menu-title">UI Elements</span>
        <i class="menu-arrow"></i>
      </a>
      <div class="collapse" id="ui-basic">
        <ul class="nav flex-column sub-menu">
          <li class="nav-item"> <a class="nav-link" href="template/royal_ui/pages/ui-features/buttons.html">Buttons</a></li>
          <li class="nav-item"> <a class="nav-link" href="template/royal_ui/pages/ui-features/typography.html">Typography</a></li>
        </ul>
      </div>
    </li> -->
    <li class="nav-item">
      <a class="nav-link" href="home.php">
        <i class="ti-shield menu-icon"></i>
        <span class="menu-title">Homepage</span>
      </a>
    </li>
    <?php if($_SESSION['jabatan']=='Admin'){
    ?>

    <li class="nav-item">
      <a class="nav-link" href="daftar_pegawai.php">
        <i class="ti-id-badge menu-icon"></i>
        <span class="menu-title">Daftar Pegawai</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="informasi_umum.php">
        <i class="ti-book menu-icon"></i>
        <span class="menu-title">Informasi Umum</span>
      </a>
    </li>
    <?php
    } else if($_SESSION['jabatan']=='kepala divisi'){
    ?>
    <li class="nav-item">
      <a class="nav-link" href="daftar_pegawai.php">
        <i class="ti-id-badge menu-icon"></i>
        <span class="menu-title">Daftar Pegawai</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="penilaian_pegawai.php">
        <i class="ti-bookmark menu-icon"></i>
        <span class="menu-title">Penilaian Pegawai</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="collapse" href="#ui-basic" aria-expanded="false" aria-controls="ui-basic">
        <i class="ti-pencil-alt menu-icon"></i>
        <span class="menu-title">Metode Perhitungan</span>
        <i class="menu-arrow"></i>
      </a>
      <div class="collapse" id="ui-basic">
        <ul class="nav flex-column sub-menu">
          <li class="nav-item"> <a class="nav-link" href="saw.php">SAW</a></li>
          <li class="nav-item"> <a class="nav-link" href="topsis.php">Topsis</a></li>
        </ul>
      </div>
    </li>
    <!-- <li class="nav-item">
      <a class="nav-link" href="penilaian_pegawai.php">
        <i class="ti-bookmark menu-icon"></i>
        <span class="menu-title">Penilaian Pegawai</span>
      </a>
    </li> -->
    <li class="nav-item">
      <a class="nav-link" href="informasi_umum.php">
        <i class="ti-book menu-icon"></i>
        <span class="menu-title">Informasi Umum</span>
      </a>
    </li>
    <?php
    } else if($_SESSION['jabatan']=='pegawai'){
    ?>
    <!-- <li class="nav-item">
      <a class="nav-link" href="daftar_pegawai.php">
        <i class="ti-id-badge menu-icon"></i>
        <span class="menu-title">Data Nama Pegawai</span>
      </a>
    </li> -->
    <li class="nav-item">
      <a class="nav-link" href="penilaian_pegawai.php">
        <i class="ti-bookmark menu-icon"></i>
        <span class="menu-title">Penilaian Pegawai</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="informasi_umum.php">
        <i class="ti-book menu-icon"></i>
        <span class="menu-title">Informasi Umum</span>
      </a>
    </li>
    <!-- <li class="nav-item">
      <a class="nav-link" href="development.php">
        <i class="ti-clipboard menu-icon"></i>
        <span class="menu-title">Development & Kebutuhan training Pekerja</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="saran.php">
        <i class="ti-info menu-icon"></i>
        <span class="menu-title">Saran</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="informasi_umum.php">
        <i class="ti-book menu-icon"></i>
        <span class="menu-title">Informasi Umum</span>
      </a>
    </li> -->
    <?php 
    }
    ?>
    <!-- <li class="nav-item">
      <a class="nav-link" href="template/royal_ui/pages/forms/basic_elements.html">
        <i class="ti-layout-list-post menu-icon"></i>
        <span class="menu-title">Form elements</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="template/royal_ui/pages/charts/chartjs.html">
        <i class="ti-pie-chart menu-icon"></i>
        <span class="menu-title">Charts</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="daftar_pegawai.php">
        <i class="ti-view-list-alt menu-icon"></i>
        <span class="menu-title">Tables</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="template/royal_ui/pages/icons/themify.html">
        <i class="ti-star menu-icon"></i>
        <span class="menu-title">Icons</span>
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-toggle="collapse" href="#auth" aria-expanded="false" aria-controls="auth">
        <i class="ti-user menu-icon"></i>
        <span class="menu-title">User Pages</span>
        <i class="menu-arrow"></i>
      </a>
      <div class="collapse" id="auth">
        <ul class="nav flex-column sub-menu">
          <li class="nav-item"> <a class="nav-link" href="template/royal_ui/pages/samples/login.html"> Login </a></li>
          <li class="nav-item"> <a class="nav-link" href="template/royal_ui/pages/samples/login-2.html"> Login 2 </a></li>
          <li class="nav-item"> <a class="nav-link" href="template/royal_ui/pages/samples/register.html"> Register </a></li>
          <li class="nav-item"> <a class="nav-link" href="template/royal_ui/pages/samples/register-2.html"> Register 2 </a></li>
          <li class="nav-item"> <a class="nav-link" href="template/royal_ui/pages/samples/lock-screen.html"> Lockscreen </a></li>
        </ul>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="template/royal_ui/documentation/documentation.html">
        <i class="ti-write menu-icon"></i>
        <span class="menu-title">Documentation</span>
      </a>
    </li> -->
  </ul>
</nav>
<script> 
var session = {
  id : "<?= $_SESSION['id'] ?>",
  jabatan : "<?= $_SESSION['jabatan'] ?>"
} 
 </script>