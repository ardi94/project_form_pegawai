<?php 
    session_start();
    if(empty($_SESSION['username'])){
        header('Location: /saw');
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">

<?php 
    include "template/header/index.php";
?>
<body>
  <div class="container-scroller">
    <!-- partial:partials/_navbar.html -->
    <?php 
      include "template/header/navigation.php";
    ?>
    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
        <?php 
            include "template/menu/index.php";
        ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">
          <div class="row">
            <div class="col-md-12 grid-margin">
              <div class="d-flex justify-content-between align-items-center">
                <div>
                  <h4 class="font-weight-bold mb-0">Dashboard</h4>
                </div>
                <!-- <div>
                    <button type="button" class="btn btn-primary btn-icon-text btn-rounded">
                      <i class="ti-clipboard btn-icon-prepend"></i>Report
                    </button>
                </div> -->
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-lg-12 grid-margin stretch-card">
              <div class="card">
                <div class="card-body">
                  <h4 class="card-title">Penilaian Pegawai</h4>
                  <div class="form-group row float-right" style="margin-right: 0px" id="namaPegawai"></div>
                  <div class="table-responsive">
                    <table class="table table-bordered">
                        <tr>
                          <td class="py-1">
                            <br>
                            <table class="table table-bordered">
                                <tr>
                                    <th style="text-align:center;">
                                        ASPEK PENILAIAN KOMPETENSI
                                    </th>
                                </tr>
                            </table>
                            <br>
                            <div class="float-right"> 
                                <input type="button" class="btn btn-outline-primary" id="add" value="Tambah KPI"> 
                                <input type="button" class="btn btn-outline-primary" id="remove" value="Hapus KPI"> 
                            </div>
                            
                            <table id="form-kompetensi" class="table table-bordered"  style="vertical-align:middle;">
                                <thead>
                                    <tr>
                                        <th style="vertical-align:middle; text-align:center; width:5px;">
                                            ASPEK
                                        </th>
                                        <th style="vertical-align:middle; text-align:center; width:5px;">
                                            NO
                                        </th>
                                        <th style="vertical-align:middle; text-align:center; width: 10px;" >
                                            Key Performance Indicator (KPI)
                                        </th>
                                        <th style="vertical-align:middle; text-align:center; width: 5px;" >
                                            Pencapaian
                                        </th>
                                        <th style="vertical-align:middle; text-align:center; width: 3px;" >
                                            Bobot
                                        </th>
                                        <th style="vertical-align:middle; text-align:center; width: 1px; padding: 0px 0px 0px 0px;">1</th>
                                        <th style="vertical-align:middle; text-align:center; width: 1px; padding: 0px 0px 0px 0px;">2</th>
                                        <th style="vertical-align:middle; text-align:center; width: 1px; padding: 0px 0px 0px 0px;">3</th>
                                        <th style="vertical-align:middle; text-align:center; width: 1px; padding: 0px 0px 0px 0px;">4</th>
                                        <th style="vertical-align:middle; text-align:center; width: 1px; padding: 0px 0px 0px 0px;">5</th>
                                        <th style="vertical-align:middle; text-align:center; width: 1px; padding: 0px 0px 0px 0px;">6</th>
                                        <th style="vertical-align:middle; text-align:center; width: 1px; padding: 0px 0px 0px 0px;">Hapus</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td rowspan="16" style="transform: rotate(270deg);  padding: 0px 0px 0px 0px;"><b>PRODUKTIVITAS (70 %)</b></td>
                                    </tr>
                                    <tr class="baris" id="1">
                                        <td>
                                            1.
                                        </td>
                                        <td id="kpi-1" style="vertical-align:middle;" class="kpi" contenteditable="true">
                                            Update data TSAF & LTIF maksimal tanggal 15 setiap bulan
                                        </td>
                                        <td id="pencapaian-1" style="vertical-align:middle;" class="pencapaian" contenteditable="true">
                                            Melakukan update menyesuaikan dengan Jadwal Laporan <br>
                                            Periodik (bulanan) Pengendali Kinerja
                                        </td>
                                       
                                        <td id="1" style="text-align:center; vertical-align:middle;" class="bobot" contenteditable="true">
                                            5%
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="0" data-y="0">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="0" data-y="1">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="0" data-y="2">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="0" data-y="3">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="0" data-y="4">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="0" data-y="5">
                                        </td>
                                        <td>
                                            <input class="hapus" type="checkbox">
                                        </td>
                                    </tr>
                                    <tr class="baris" id="2">
                                        <td>
                                            2.
                                        </td>
                                        <td id="kpi-2" style="vertical-align:middle;" class="kpi" contenteditable="true">
                                            Melaksanakan koordinasi & evaluasi terkait rapat P2K3/ <br> 
                                            CSC maksimal tanggal 20 setiap bulan
                                        </td>
                                       
                                        <td id="pencapaian-2" style="vertical-align:middle;" class="pencapaian" contenteditable="true">
                                            Melakukan upadate disesuaikan dengan kondisi tertentu <br>
                                            Perusahaan (CSMS, Project Surabaya)
                                        </td>
                                        <td id="2" style="text-align:center; vertical-align:middle;" class="bobot" contenteditable="true">
                                            10%
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="1" data-y="0">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="1" data-y="1">
                                        </td>
                                       <td id="input">
                                            <input id="input____" data-x="1" data-y="2">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="1" data-y="3">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="1" data-y="4">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="1" data-y="5">
                                        </td>
                                        <td>
                                            <input class="hapus" type="checkbox">
                                        </td>
                                    </tr>
                                    <tr class="baris" id="3">
                                        <td>
                                            3.
                                        </td>
                                        <td id="kpi-3" style="vertical-align:middle;" class="kpi" contenteditable="true">
                                            'Melaksanakan koordinasi & evaluasi terkait RCA maksimal <br> 
                                            tanggal 20 setiap bulan
                                        </td>
                                        
                                        <td id="pencapaian-3" style="vertical-align:middle;" class="pencapaian" contenteditable="true">
                                            Melakukan Audit disesuaikan dengan kondisi Perusahaan<br> 
                                            (project Surabaya)
                                        </td>
                                        <td id="3" style="text-align:center; vertical-align:middle;" class="bobot" contenteditable="true">
                                            10%
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="2" data-y="0">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="2" data-y="1">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="2" data-y="2">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="2" data-y="3">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="2" data-y="4">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="2" data-y="5">
                                        </td>
                                        <td>
                                            <input class="hapus" type="checkbox">
                                        </td>
                                    </tr>
                                    <tr class="baris" id="4">
                                        <td>
                                            4.
                                        </td>
                                        <td id="kpi-4" style="vertical-align:middle;" class="kpi" contenteditable="true">
                                             Melaksanakan edukasi kesehatan 2x setahun pada Bulan Juni<br> 
                                             dan November 2019
                                        </td>
                                        
                                        <td id="pencapaian-4" style="vertical-align:middle;" class="pencapaian" contenteditable="true">
                                            Edukasi Kesehatan "STROKE", Edukasi Kesehatan "Stress<br> Release",
                                            Edukasi Kesehatan "Kanker Serviks"
                                        </td>
                                        <td id="4" style="text-align:center; vertical-align:middle;" class="bobot" contenteditable="true">
                                            10%
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="3" data-y="0">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="3" data-y="1">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="3" data-y="2">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="3" data-y="3">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="3" data-y="4">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="3" data-y="5">
                                        </td>
                                        <td>
                                            <input class="hapus" type="checkbox">
                                        </td>
                                    </tr>
                                    <tr class="baris" id="5">
                                        <td>
                                            5.
                                        </td>
                                        <td id="kpi-5" style="vertical-align:middle;" class="kpi" contenteditable="true">
                                            Melakukan pelaporan P2K3 setiap 3 Bulan sekali maksimal <br>
                                            tanggal 20
                                        </td>
                                        <td id="pencapaian-5" style="vertical-align:middle;" class="pencapaian" contenteditable="true">
                                            Pelaporan dilakukan pada tanggal 18 Januari 2019, 9 April<br> 2019,
                                            25 Juli 2019, 31 Oktober 2019
                                        </td>
                                        <td id="5" style="text-align:center; vertical-align:middle;" class="bobot" contenteditable="true">
                                            10%
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="4" data-y="0">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="4" data-y="1">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="4" data-y="2">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="4" data-y="3">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="4" data-y="4">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="4" data-y="5">
                                        </td>
                                        <td>
                                            <input class="hapus" type="checkbox">
                                        </td>
                                    </tr>
                                    <tr class="baris" id="6">
                                        <td>
                                            6.
                                        </td>
                                        <td id="kpi-6" style="vertical-align:middle;" class="kpi" contenteditable="true">
                                           Melakukan sosialisasi PO K3/ IHT K3 maksimal 3 bulan sekali
                                        </td>
                                        
                                        <td id="pencapaian-6" style="vertical-align:middle;" class="pencapaian" class="pencapaian" contenteditable="true">
                                            Melakukan edukasi terhadap pekerja chiller
                                        </td>
                                        <td id="6" style="text-align:center; vertical-align:middle;" class="bobot" contenteditable="true">
                                            10%
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="5" data-y="0">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="5" data-y="1">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="5" data-y="2">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="5" data-y="3">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="5" data-y="4">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="5" data-y="5">
                                        </td>
                                        <td>
                                            <input class="hapus" type="checkbox">
                                        </td>
                                    </tr>
                                    <tr class="baris" id="7">
                                        <td>
                                            7.
                                        </td>
                                        <td id="kpi-7" style="vertical-align:middle;" class="kpi" contenteditable="true">
                                           Melakukan sosialisasi & internalisasi budaya K3 terhadap <br>
                                           pekerja baru setiap ada permintaan
                                            
                                        </td>
                                         
                                        <td id="pencapaian-7" style="vertical-align:middle;" class="pencapaian" contenteditable="true">
                                            Ikut serta dalam program sosialisasi terhadap pekerja<br>
                                            internal baru
                                        </td>
                                        <td id="7" style="text-align:center; vertical-align:middle;" class="bobot" contenteditable="true">
                                            5%
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="6" data-y="0">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="6" data-y="1">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="6" data-y="2">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="6" data-y="3">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="6" data-y="4">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="6" data-y="5">
                                        </td>
                                        <td>
                                            <input class="hapus" type="checkbox">
                                        </td>
                                    </tr>
                                    <tr class="baris" id="8">
                                        <td>
                                            8.
                                        </td>
                                        <td id="id="kpi-8" style="vertical-align:middle;" class="kpi" contenteditable="true">
                                            Melakukan pemeriksaan kesehatan pekerja & lingkungan <br>
                                            pekerja maksimal Bulan November (1 tahun sekali)
                                        </td>
                                       
                                        <td id="pencapaian-8" style="vertical-align:middle;" class="pencapaian" contenteditable="true">
                                            - Melakukan MCU Pekerja dan melakukan tindak lanjut <br>
                                            hasil MCU (vaksin Hepatitis B)
                                        </td>
                                        <td id="8" style="text-align:center; vertical-align:middle;" class="bobot" contenteditable="true">
                                            10%
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="7" data-y="0">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="7" data-y="1">
                                        </td>
                                       <td id="input">
                                            <input id="input____" data-x="7" data-y="2">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="7" data-y="3">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="7" data-y="4">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="7" data-y="5">
                                        </td>
                                        <td>
                                            <input class="hapus" type="checkbox">
                                        </td>
                                    </tr>
                                    <tr class="baris" id="9">
                                        <td>
                                            9.
                                        </td>
                                        <td id="kpi-9" style="vertical-align:middle;" class="kpi"  contenteditable="true">
                                            Melakukan monitoring terhadap pemenuhan peraturan SMK3 <br>setiap 3 bulan sekali
                                        </td>
                                        
                                        <td id="pencapaian-9" style="vertical-align:middle;" class="pencapaian" contenteditable="true">
                                            Melakukan review prosedur dan pemenuhan kebutuhan <br>
                                            Perusahaan terhadap peraturan K3 
                                        </td>
                                        <td id="9" style="text-align:center; vertical-align:middle;" class="bobot" contenteditable="true">
                                            5%
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="8" data-y="0">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="8" data-y="1">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="8" data-y="2">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="8" data-y="3">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="8" data-y="4">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="8" data-y="5">
                                        </td>
                                        <td>
                                            <input class="hapus" type="checkbox">
                                        </td>
                                    </tr>
                                    <tr class="baris" id="10">
                                        <td>
                                            10.
                                        </td>
                                        <td id="kpi-10" style="vertical-align:middle;" class="kpi" contenteditable="true">
                                             Melakukan pemeriksaan terhadap alat kerja setiap 1 bulan sekali
                                        </td>
                                        
                                        <td id="pencapaian-10" style="vertical-align:middle;" class="pencapaian" contenteditable="true">
                                            Melakukan koordinasi kepada Teknisi terhadap pemenuhan<br> APD
                                        </td>
                                        <td id="10" style="text-align:center; vertical-align:middle;" class="bobot" contenteditable="true">
                                            5%
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="9" data-y="0">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="9" data-y="1">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="9" data-y="2">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="9" data-y="3">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="9" data-y="4">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="9" data-y="5">
                                        </td>
                                        <td>
                                            <input class="hapus" type="checkbox">
                                        </td>
                                    </tr>
                                    <tr class="baris" id="11">
                                        <td>
                                            11.
                                        </td>
                                        <td id="kpi-11" style="vertical-align:middle;" class="kpi" contenteditable="true">
                                            Membuat usulan kebutuhan diklat K3 untuk pekerja internal <br>sesuai kebutuhan
                                        </td>
                                        
                                        <td id="pencapaian-11" style="vertical-align:middle;" class="pencapaian" contenteditable="true">
                                            Melakukan koordinasi kepada HR untuk pemenuhan Diklat K3 <br>
                                            berdasarkan kebutuhan Perusahaan (Mengikutsertakan Irpan <br>
                                            dalam training K3 Umum)
                                        </td>
                                        <td id="11" style="text-align:center; vertical-align:middle;" class="bobot" contenteditable="true">
                                            5%
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="10" data-y="0">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="10" data-y="1">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="10" data-y="2">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="10" data-y="3">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="10" data-y="4">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="10" data-y="5">
                                        </td>
                                        <td>
                                            <input class="hapus" type="checkbox">
                                        </td>
                                    </tr>
                                    <tr class="baris" id="12">
                                        <td>
                                            12.
                                        </td>
                                        <td id="kpi-12" style="vertical-align:middle;" class="kpi" contenteditable="true">
                                            Melakukan monitoring terhadap perizinan perusahaan setiap <br>3 bulan sekali
                                        </td>
                                        
                                        <td id="pencapaian-12" style="vertical-align:middle;" class="pencapaian" contenteditable="true">
                                            Melakukan update Perizinan Pusat dan Wilayah (Pelaporan <br>
                                            Ketenagakerjaan, OSS, MICE, SBU, IUJK)
                                        </td>
                                         <td id="12" style="text-align:center; vertical-align:middle;" class="bobot" contenteditable="true">
                                             5%
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="11" data-y="0">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="11" data-y="1">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="11" data-y="2">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="11" data-y="3">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="11" data-y="4">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="11" data-y="5">
                                        </td>
                                        <td>
                                            <input class="hapus" type="checkbox">
                                        </td>
                                    </tr>
                                    <tr class="baris" id="13">
                                        <td>
                                            13.
                                        </td>
                                        <td id="kpi-13" style="vertical-align:middle;" class="kpi" contenteditable="true">
                                            Melakukan penyelesaian perizinan perusahaan maksimal 1 bulan <br>setelah dokumen lengkap
                                        </td>
                                       
                                        <td id="pencapaian-13" style="vertical-align:middle;" class="pencapaian" contenteditable="true">
                                            Perzinan Pusat dan Wilayah telah selesai tepat waktu
                                        </td>
                                        <td id="13" style="text-align:center; vertical-align:middle;" class="bobot" contenteditable="true">
                                            10%
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="12" data-y="0">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="12" data-y="1">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="12" data-y="2">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="12" data-y="3">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="12" data-y="4">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="12" data-y="5">
                                        </td>
                                        <td>
                                            <input class="hapus" type="checkbox">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="3" id="text_end">
                                            Total Nilai
                                        </td>
                                        <td id="text" class="totalBobot" style="text-align:center; ">
                                            100%
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="33" data-y="0">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="33" data-y="1">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="33" data-y="2">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="33" data-y="3">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="33" data-y="4">
                                        </td>
                                        <td id="input">
                                            <input id="input____" data-x="33" data-y="5">
                                        </td>
                                        <td rowspan="2">
                                            
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="4" id="text_end">
                                           Rata-rata
                                        </td>
                                        <td colspan="6" style="padding: 0px 110px 0px 230px;">
                                            <input id="input____" data-x="34" data-y="0" class="hasil">
                                        </td>
                                    </tr>
                                </tbody> 
                            </table>
                            <br>
                            <table class="table table-bordered"  style="vertical-align:middle;">
                                <thead>
                                    <tr>
                                        <th rowspan="3" style="vertical-align:middle; text-align:center; width:5px;">
                                            ASPEK
                                        </th>
                                        <th rowspan="3" style="vertical-align:middle; text-align:center;  width:5%;">
                                            NO
                                        </th>
                                        <th rowspan="3" style="vertical-align:middle; text-align:center; width: 20%;" >
                                            ITEM YANG DINILAI
                                        </th>
                                        <th colspan="6"  id="judul">
                                            Grade
                                        </th>
                                    </tr>
                                    <tr>
                                        <th id="judul" class="width_">Unsatisfaction</th>
                                        <th id="judul" class="width_">Reasonable</th>
                                        <th id="judul" class="width_">Good</th>
                                        <th id="judul" class="width_">Good Plus</th>
                                        <th id="judul" class="width_">Very Good</th>
                                        <th id="judul" class="width_">Outstanding</th>
                                    </tr>
                                    <tr>
                                        <th id="judul">1</th>
                                        <th id="judul">2</th>
                                        <th id="judul">3</th>
                                        <th id="judul">4</th>
                                        <th id="judul">5</th>
                                        <th id="judul">6</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td rowspan="9" style="transform: rotate(270deg); padding: 0px 0px 0px 0px;"><b>BUDAYA (15%)</b></td>
                                    </tr>
                                    <tr>
                                        <td>
                                            1. A
                                        </td>
                                        <td id="text">
                                            <b>Harmony</b> <br> 
                                            Mampu mengutamakan hubungan yang harmoni sehingga tercipta <br>
                                            lingkungan kerja yang kondusif dan produktif
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="35" data-y="0">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="35" data-y="1">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="35" data-y="2">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="35" data-y="3">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="35" data-y="4">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="35" data-y="5">
                                        </td>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            1. B
                                        </td>
                                        <td id="text">
                                            <b>Loyal</b> <br>
                                            Senantiasa loyal kepada rekan sejawat, atasan maupun <br> 
                                            kepada perusahaan, serta mengutamakan kepentingan <br> 
                                            perusahaan diatas kepentingan pribadi/golongan
                                        </td>
                                       <td id="input_">
                                            <input id="input__" data-x="36" data-y="0">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="36" data-y="1">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="36" data-y="2">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="36" data-y="3">
                                        </td>
                                       <td id="input_">
                                            <input id="input__" data-x="36" data-y="4">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="36" data-y="5">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            1. C
                                        </td>
                                        <td id="text">
                                            <b>Integrity</b> <br>
                                            Mempunyai integritas yang dapat diandalkan serta menjunjung <br>
                                            tinggi kedisiplinan, nilai etika dan moral
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="37" data-y="0">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="37" data-y="1">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="37" data-y="2">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="37" data-y="3">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="37" data-y="4">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="37" data-y="5">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            1. D
                                        </td>
                                        <td id="text">
                                            <b>Spirit</b> <br>
                                             Pekerja keras, pantang menyerah dan bersemangat dalam <br>
                                             memberikan pelayanan prima
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="38" data-y="0">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="38" data-y="1">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="38" data-y="2">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="38" data-y="3">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="38" data-y="4">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="38" data-y="5">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            1. E
                                        </td>
                                        <td id="text">
                                            <b>Respect</b> <br>
                                            Senantiasa menaruh rasa hormat dan menghargai dalam berinteraksi
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="39" data-y="0">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="39" data-y="1">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="39" data-y="2">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="39" data-y="3">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="39" data-y="4">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="39" data-y="5">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" id="text_end">
                                           Total Nilai
                                        </td>
                                        
                                       <td id="input_">
                                            <input id="input__" data-x="40" data-y="0">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="40" data-y="1">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="40" data-y="2">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="40" data-y="3">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="40" data-y="4">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="40" data-y="5">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" id="text_end">
                                           Rata-rata
                                        </td>
                                        
                                        <td colspan="6" id="input_" style="padding: 0px 0px 0px 470px;">
                                            <input id="input__" data-x="41" data-y="0" class="hasil">
                                        </td>
                                         <!-- <td id="input_">
                                            <input id="input__" data-x="7" data-y="1>
                                        </td>
                                         <td id="input_">
                                            <input id="input__" data-x="7" data-y="2">
                                        </td>
                                         <td id="input_">
                                            <input id="input__" data-x="7" data-y="3">
                                        </td>
                                         <td id="input_">
                                            <input id="input__" data-x="7" data-y="4">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="7" data-y="5">
                                        </td> -->
                                    </tr>
                                </tbody>
                            </table>
                            <br>
                            <table class="table table-bordered"  style="vertical-align:middle;">
                                <thead>
                                    <tr>
                                        <th rowspan="3" style="vertical-align:middle; text-align:center; width:5px;">
                                            ASPEK
                                        </th>
                                        <th rowspan="3" style="vertical-align:middle; text-align:center;  width:5%;">
                                            NO
                                        </th>
                                        <th rowspan="3" style="vertical-align:middle; text-align:center; width: 20%;" >
                                            ITEM YANG DINILAI
                                        </th>
                                        <th colspan="6"  id="judul">
                                            Grade
                                        </th>
                                    </tr>
                                    <tr>
                                        <th id="judul" class="width_">Unsatisfaction</th>
                                        <th id="judul" class="width_">Reasonable</th>
                                        <th id="judul" class="width_">Good</th>
                                        <th id="judul" class="width_">Good Plus</th>
                                        <th id="judul" class="width_">Very Good</th>
                                        <th id="judul" class="width_">Outstanding</th>
                                    </tr>
                                    <tr>
                                        <th id="judul">1</th>
                                        <th id="judul">2</th>
                                        <th id="judul">3</th>
                                        <th id="judul">4</th>
                                        <th id="judul">5</th>
                                        <th id="judul">6</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td rowspan="9" style="transform: rotate(270deg); padding: 0px 0px 0px 0px;"><b>KOMPETENSI (15%)</b></td>
                                    </tr>
                                    <tr>
                                        <td>
                                            1. A
                                        </td>
                                        <td id="text">
                                            <b>Pengetahuan Umum</b> <br>  Memahami dan menyelesaikan pekerjaan yang menjadi tanggung <br> jawabnya
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="42" data-y="0">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="42" data-y="1">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="42" data-y="2">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="42" data-y="3">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="42" data-y="4">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="42" data-y="5">
                                        </td>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            1. B
                                        </td>
                                        <td id="text">
                                            <b>Pengambilan Keputusan</b> <br>
                                            Mampu mengambil keputusan dengan cepat dan tepat dalam <br> 
                                            menyelesaikan tugas-tugas yang menjadi tanggung jawabnya
                                        </td>
                                       <td id="input_">
                                            <input id="input__" data-x="43" data-y="0">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="43" data-y="1">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="43" data-y="2">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="43" data-y="3">
                                        </td>
                                       <td id="input_">
                                            <input id="input__" data-x="43" data-y="4">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="43" data-y="5">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            1. C
                                        </td>
                                        <td id="text">
                                            <b>Perencanaan</b> <br>
                                            Mampu membuat perencanaan kerja, berdasarkan skala prioritas
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="44" data-y="0">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="44" data-y="1">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="44" data-y="2">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="44" data-y="3">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="44" data-y="4">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="44" data-y="5">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            1. D
                                        </td>
                                        <td id="text">
                                            <b>Kepemimpinan</b> <br>
                                            Mampu menggunakan cara-cara pendekatan yang tepat dalam <br>
                                            mengarahkan orang orang (kelompok, bawahan, rekan setingkat,<br>
                                             atasan) untuk menyelesaikan tugas
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="45" data-y="0">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="45" data-y="1">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="45" data-y="2">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="45" data-y="3">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="45" data-y="4">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="45" data-y="5">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            1. E
                                        </td>
                                        <td id="text">
                                            <b>Komunikasi</b> <br>
                                            Mampu mengekspresikan diri dihadapan orang lain secara verbal <br>
                                            maupun non verbal. Mampu memberikan/menjabarkan informasi <br>
                                            kedalam bahasa yang bisa dimengerti oleh orang lain.
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="46" data-y="0">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="46" data-y="1">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="46" data-y="2">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="46" data-y="3">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="46" data-y="4">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="46" data-y="5">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            1. F
                                        </td>
                                        <td id="text">
                                            <b>Multi Tasking</b> <br>
                                            Mampu menyelesaikan beberapa pekerjaan sesuai dengan kebutuhan
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="47" data-y="0">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="47" data-y="1">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="47" data-y="2">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="47" data-y="3">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="47" data-y="4">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="47" data-y="5">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" id="text_end">
                                           Total Nilai
                                        </td>
                                        
                                       <td id="input_">
                                            <input id="input__" data-x="48" data-y="0">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="48" data-y="1">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="48" data-y="2">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="48" data-y="3">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="48" data-y="4">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="48" data-y="5">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2" id="text_end">
                                           Rata-rata
                                        </td>
                                        
                                        <td colspan="6" id="input_" style="padding: 0px 0px 0px 450px;">
                                            <input id="input__" data-x="49" data-y="0" class="hasil">
                                        </td>
                                         <!-- <td id="input_">
                                            <input id="input__" data-x="7" data-y="1>
                                        </td>
                                         <td id="input_">
                                            <input id="input__" data-x="7" data-y="2">
                                        </td>
                                         <td id="input_">
                                            <input id="input__" data-x="7" data-y="3">
                                        </td>
                                         <td id="input_">
                                            <input id="input__" data-x="7" data-y="4">
                                        </td>
                                        <td id="input_">
                                            <input id="input__" data-x="7" data-y="5">
                                        </td> -->
                                    </tr>
                                </tbody>
                            </table>
                            <br>
                            <table class="table table-bordered">
                                <tr>
                                    <th style="text-align:center;">
                                        PENDAPAT PEKERJA
                                    </th>
                                </tr>
                            </table>
                            <br>
                            <table class="table table-bordered">
                                <tr>
                                    <th id="judul" class="width_">
                                        FAKTOR FAKTOR YANG MENUNJANG KINERJA
                                    </th>
                                    <th id="judul" class="width_">
                                        FAKTOR FAKTOR YANG MENGHAMBAT KINERJA
                                    </th>
                                </tr>
                                <tr>
                                    <td style="text-align:center;"  id="text">
                                        <textarea name="" cols="30" rows="10" id="input__" data-x="50" data-y="0"></textarea>
                                    </td>
                                    <td style="text-align:center;"  id="text">
                                        <textarea name="" cols="30" rows="10" id="input__" data-x="50" data-y="1"></textarea>
                                    </td>
                                </tr>
                            </table>
                            <br>
                            <!-- <table>
                                <tr>
                                    <th> -->
                                       <b> <u>DEVELOPMENT & KEBUTUHAN TRAINING PEKERJA</u></b>
                                    <!-- </th>
                                </tr>
                            </table> -->
                            <br>
                            <br>
                            <table class="table">
                                <tr>
                                    <td id="text" style=" border: 0px solid #c9ccd7;">
                                        <label class="container">
                                            <p>Job Enrichment / Enlagerment</p>
                                            <input data-x="51" data-y="0" type="checkbox">
                                            <span class="checkmark"></span>
                                        </label>
                                    </td>
                                    <td id="text" style=" border: 0px solid #c9ccd7;">
                                        <label class="container">
                                            <p>Penugasan/ Projects</p>
                                            <input data-x="51" data-y="1" type="checkbox">
                                            <span class="checkmark"></span>
                                        </label>
                                    </td>
                                </tr>
                                <tr>
                                    <td id="text" style=" border: 0px solid #c9ccd7;">
                                        <label class="container">
                                            <p>Job Rotation</p>
                                            <input data-x="51" data-y="2" type="checkbox">
                                            <span class="checkmark"></span>
                                        </label>
                                    </td>
                                    <td id="text" style=" border: 0px solid #c9ccd7;">
                                        <label class="container">
                                            <p>Training/ Short Course/ Seminar</p>
                                            <input data-x="51" data-y="3" type="checkbox">
                                            <span class="checkmark"></span>
                                        </label>
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2" id="text">
                                        <textarea id="input__" data-x="51" data-y="4" name="" cols="30" rows="4" placeholder="Komentar" ></textarea>
                                    </td>
                                </tr>
                            </table>
                            <br>
                            <table class="table table-bordered">
                                <tr>
                                    <th id="judul" style="text-align:left; width:50%;" class="width_" colspan="5">
                                        HASIL PENILAIAN
                                    </th>
                                    <th id="judul" style="text-align:left; width:50%;" class="width_">
                                        DESKRIPSI
                                    </th>
                                </tr>
                                <tr>
                                    <th id="judul" style="text-align:left; width:2%;">NO
                                    </th>
                                    <th id="judul">Aspek Penilaian
                                    </th>
                                    <th id="judul">Hasil 
                                    </th>
                                    <th id="judul">Bobot
                                    </th>
                                    <th id="judul">Hasil 
                                    </th>
                                    <th id="judul" style="text-align:left;" > KELEBIHAN
                                    </th>
                                </tr>
                                <tr>
                                    <td id="text" style="text-align:left;">1.</td>
                                    <td id="text">Produktifitas</td>
                                    <td id="text"> <input id="input__" data-x="52" data-y="0" style="text-align:center;" readonly></td>
                                    <td id="text"> <input id="input__" data-x="52" data-y="1" value="70%" style="text-align:center;" readonly></td>
                                    <td id="text"> <input id="input__" data-x="52" data-y="2" style="text-align:center;" readonly></td>
                                    <td rowspan="3" id="text"><textarea id="input__" name="" data-x="52" data-y="3" cols="30" rows="4"></textarea> </td>
                                </tr>
                                <tr>
                                    <td id="text" style="text-align:left;">2.</td>
                                    <td id="text">Budaya</td>
                                    <td id="text"> <input id="input__" data-x="52" data-y="4" style="text-align:center;" readonly></td>
                                    <td id="text"> <input id="input__" data-x="52" data-y="5" value="15%" style="text-align:center;" readonly></td>
                                    <td id="text"> <input id="input__" data-x="52" data-y="6" style="text-align:center;" readonly></td>
                                </tr>
                                <tr>
                                    <td id="text" style="text-align:left;">3.</td>
                                    <td id="text">Kompetensi</td>
                                    <td id="text"> <input id="input__" data-x="52" data-y="7" style="text-align:center;" readonly></td>
                                    <td id="text"> <input id="input__" data-x="52" data-y="8" value="15%" style="text-align:center;" readonly></td>
                                    <td id="text"> <input id="input__" data-x="52" data-y="9" style="text-align:center;" readonly></td>
                                </tr>
                                <tr>
                                    <th id="judul" colspan="4">NILAI AKHIR
                                    </th>
                                    <th id="text"> <input id="input__" data-x="53" data-y="0" style="text-align:center;">
                                    </th>
                                    <th id="judul" style="text-align:left;"> KEKURANGAN
                                    </th>
                                </tr>
                                <tr>
                                    <td id="judul" colspan="4">PREDIKAT AWAL</td>
                                    <td id="text"> <input id="input__" data-x="53" data-y="1" style="text-align:center;"></td>
                                    <td rowspan="2" id="text"> <textarea id="input__" data-x="53" data-y="2" name="" cols="30" rows="4"></textarea>
                                    </td>
                                </tr>
                                <tr>
                                    <td id="judul" colspan="4">PREDIKAT AKHIR</td>
                                    <td id="text"> <input id="input__" data-x="53" data-y="3" style="text-align:center;" disabled></td>
                                </tr>
                            </table>
                            <br>
                            <table class="table-bordered" style="width:50%;">
                                <tr>
                                    <th id="judul" style="text-align:center; width:50%;" class="width_">
                                        TTD ATASAN
                                    </th>
                                    <th id="judul" style="text-align:center; width:50%;" class="width_">
                                        TTD ATASAN TIDAK LANGSUNG
                                    </th>
                                </tr>
                                <tr>
                                    <td style="height:100px"> </td>
                                    <td style="height:100px"> </td>
                                </tr>
                            </table>
                            <br>
                            <center>
                                <button id="save" type="submit" class="btn btn-primary mr-2">Submit</button>
                            </center>
                          </td>
                        </tr>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:../../partials/_footer.html -->
        <footer class="footer">
          <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">Copyright © 2020 <a href="" target="_blank">Templatewatch</a>. Modified By Nita Candra Mulya</span>
            <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Hand-crafted & made with <i class="ti-heart text-danger ml-1"></i></span>
          </div>
        </footer>
        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->

<?php 
    include "template/footer/footer.php";
?>
</body>
<script>
    var tr = document.createElement("TR");
    var td1 = document.createElement("TD");
    var td2 = document.createElement("TD");
    var td3 = document.createElement("TD");
    var td4 = document.createElement("TD");
    var td5 = document.createElement("TD");
    var td6 = document.createElement("TD");
    var td7 = document.createElement("TD");
    var td8 = document.createElement("TD");
    var td9 = document.createElement("TD");
    var td10 = document.createElement("TD");
    var td11 = document.createElement("TD");
    var input1 = document.createElement("INPUT");
    var input2 = document.createElement("INPUT");
    var input3 = document.createElement("INPUT");
    var input4 = document.createElement("INPUT");
    var input5 = document.createElement("INPUT");
    var input6 = document.createElement("INPUT");
    var input7 = document.createElement("INPUT");
    tr.id = 0;
    td1.innerText = "Hai";
    td2.style = "vertical-align:middle;";
    td2.classList.add("kpi");
    td2.setAttribute("contenteditable", "true");
    td3.style = "vertical-align:middle;";
    td3.classList.add("pencapaian");
    td3.setAttribute("contenteditable", "true");
    td4.style = "vertical-align:middle; text-align:center;";
    td4.classList.add("bobot");
    td4.setAttribute("contenteditable", "true");
    td5.id="input";
    td6.id="input";
    td7.id="input";
    td8.id="input";
    td9.id="input";
    td10.id="input";
    input1.id = "input____";
    input2.id = "input____";
    input3.id = "input____";
    input4.id = "input____";
    input5.id = "input____";
    input6.id = "input____";
    // input7.class= 'hapus';
    input7.setAttribute("class", "hapus");
    input7.setAttribute("type", "checkbox");
    input1.dataset.x = 0;
    input2.dataset.x = 0;
    input3.dataset.x = 0;
    input4.dataset.x = 0;
    input5.dataset.x = 0;
    input6.dataset.x = 0;
    input1.dataset.y = 0;
    input2.dataset.y = 1;
    input3.dataset.y = 2;
    input4.dataset.y = 3;
    input5.dataset.y = 4;
    input6.dataset.y = 5;
    td5.appendChild(input1);
    td6.appendChild(input2);
    td7.appendChild(input3);
    td8.appendChild(input4);
    td9.appendChild(input5);
    td10.appendChild(input6);
    td11.appendChild(input7);
    tr.appendChild(td1);
    tr.appendChild(td2);
    tr.appendChild(td3);
    tr.appendChild(td4);
    tr.appendChild(td5);
    tr.appendChild(td6);
    tr.appendChild(td7);
    tr.appendChild(td8);
    tr.appendChild(td9);
    tr.appendChild(td10);
    tr.appendChild(td11);
    
    console.log(tr);
</script>
<script src="assets/js/perhitungan.js"></script>
</html>

