<?php
include "koneksi/koneksi.php";

if(isset($_POST['user_name']))
{
 $name=$_POST['user_name'];
 if (!preg_match("/^[0-9]{4}[\-]?[0-9]{2}[\-]?[0-9]{2}[\-]?[0-9]{4}/",$name)) {
   echo "Format yang anda masukkan harus sesuai ";
 }else{
   $checkdata="SELECT nim FROM tbl_mahasiswa WHERE nim='$name' ";

   $result = $conn->query($checkdata);

   if($result->num_rows > 0)
   {
    echo "NIM Mahasiswa Sudah Ada, Masukkan NIM LAIN ";
   }
   else
   {
    echo "OK";
   }
 }

 exit();
}

if(isset($_POST['user_email']))
{
 $emailId=$_POST['user_email'];

 $checkdata=" SELECT loginid FROM user WHERE loginid='$emailId' ";

 $query=mysql_query($checkdata);

 if(mysql_num_rows($query)>0)
 {
  echo "Email Already Exist";
 }
 else
 {
  echo "OK";
 }
 exit();
}


?>
