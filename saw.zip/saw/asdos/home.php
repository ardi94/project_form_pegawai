<?php
    include "koneksi/koneksi.php";
    include "sql/sql.php";
    if($_SESSION['id']==''){
        header("location: index.php");
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="plugins/images/favicon.png">
    <title>WEB - Seleksi Pemilihan Asisten Dosen</title>
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <!-- toast CSS -->
    <link href="plugins/bower_components/toast-master/css/jquery.toast.css" rel="stylesheet">
    <!-- morris CSS -->
    <link href="plugins/bower_components/morrisjs/morris.css" rel="stylesheet">
    <!-- animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- color CSS -->
    <link href="css/colors/green.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <div id="wrapper">
        <!-- Navigation -->
         <?php include "nav.php"; ?>
        <!-- Left navbar-header -->
        <?php include "sidebar.php"; ?>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Dashboard</h4> </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- row -->

                <!-- /.row -->
                <!--row -->

                <!--row -->
                <?php if($hakakses!='mahasiswa'){ ?>
                  <div class="row">
                    <div class="row">
                    <div class="col-sm-6">
                        <div class="white-box">
                            <h3 class="box-title">Kriteria Asisten Dosen
                            </h3>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>KRITERIA</th>
                                            <th>BOBOT</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no=1;

                                            $sql="select * from tbl_kriteria ";
                                            $result=mysqli_query($conn,$sql);
                                            $a=0;
                                            while($row=mysqli_fetch_array($result,MYSQLI_NUM))
                                            {

                                        ?>
                                        <tr>
                                            <td><?php  echo $no; ?></td>
                                            <td><?php  echo $row['1']; ?></td>
                                            <td><?php  echo $row['2']; ?></td>

                                        </tr>
                                        <?php
                                            $no++;
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-sm-12">
                        <?php
                          $sqlmat="select * from tbl_matkul order by id_m asc";
                          $resultt=mysqli_query($conn,$sqlmat);
                          while($rowmat=mysqli_fetch_array($resultt,MYSQLI_NUM))
                          {
                        ?>
                        <div class="white-box">
                            <h3 class="box-title">Daftar Mahasiswa <?php echo $rowmat['1']; ?>
                            </h3>
                            <?php
                              $sql="select * from tbl_mahasiswa where id_m='".$rowmat['0']."' order by nilai asc";
                              $result=mysqli_query($conn,$sql);
                              if($result->num_rows > 0){
                            ?>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>NIM</th>
                                            <th>NAMA</th>
                                            <th>C1<br>IPK</th>
                                            <th>C2<br>WAWANCARA</th>
                                            <th>C3<br>sikap</th>
                                            <th>C4<br>KEHADIRAN</th>
                                            <th>C5<br>SERTIFIKAT</th>
                                            <th>C6<br>TES UMUM</th>
                                            <th>C7<br>TES KHUSUS</th>
                                            <th>C8<br>MATA KULIAH</th>
                                            <!--
                                            <th>Hasil<br>Nilai</th>
                                          -->
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no=1;
                                            $a=0;
                                            while($row=mysqli_fetch_array($result,MYSQLI_NUM))
                                            {
                                              $sqlmat="select * from tbl_matkul where id_m='".$row['1']."'";
                                              $resultmat = $conn->query($sqlmat);
                                             	$rowmat = $resultmat->fetch_row();
                                        ?>
                                        <tr>
                                            <td><?php  echo $row['0']; ?></td>
                                            <td><?php  echo $row['1']; ?></td>
                                            <td><?php  echo $row['4']; ?></td>

                                            <td><?php  echo $row['5']; ?></td>
                                            <td><?php  echo $row['6']; ?></td>

                                            <td><?php  echo $row['7']; ?></td>
                                            <td><?php  echo $row['8']; ?></td>

                                            <td><?php  echo $row['9']; ?></td>
                                            <td><?php  echo $row['10']; ?></td>

                                            <td><?php  echo $row['11']; ?></td>



                                        </tr>
                                        <?php
                                            $no++;
                                            $a++;
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            </div>
                          <?php
                            }else{
                          ?>
                            <p style="text-align:center;">Tidak ada mahasiswa untuk program Asiten Dosen Mata Kuliah <?php echo $rowmat['1']; ?></p>
                          <?php
                            }
                          ?>
                        </div>
                      <?php } ?>
                    </div>
                </div>
                <?php }else{  ?>
                     <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                            <p><h4>
                                Selamat Mengikuti TES Seleksi Asisten Dosen</h4> <br>
                                Web ini bertujuan agar mahasiswa mengetahui hasil dari tes seleksi asisten dosen.

                                <br>

                                <?php
                                $sql="select * from tbl_mahasiswa order by nilai desc limit 1";
                                $result = $conn->query($sql);
                                $row = $result->fetch_assoc();

                                $nilai=$row['nilai'];
                                $sqll = "SELECT * FROM tbl_matkul where id_m='".$_SESSION['matkul']."' ";
                                $resultt = $conn->query($sqll);
                                $rowt = $resultt->fetch_assoc();

                                if($nilai==0){
                                    ?>
Proses seleksi sebagai Asisten dosen Mata Kuliah <?php echo 	$rowt['nm_matkul']; ?> masih berlangsung.
                                    <?php
                                }else{
                                    ?>
dibawah ini adalah mahasiswa yang terpilih sebagai Asisten dosen Mata Kuliah <?php echo 	$rowt['nm_matkul']; ?>

                                    <?php
                                } ?>

                            </p>

                            <div class="table-responsive" <?php if($nilai==0){ ?> hidden <?php }else{ ?>   <?php    } ?>>
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>NIM</th>
                                            <th>NAMA</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no=1;

                                            $sql="select * from tbl_mahasiswa where id_m='".$_SESSION['matkul']."' order by nilai desc limit 1";
                                            $result=mysqli_query($conn,$sql);
                                            $a=0;
                                            while($row=mysqli_fetch_array($result,MYSQLI_NUM))
                                            {

                                        ?>
                                        <tr>
                                            <td><?php  echo $row['0']; ?></td>
                                            <td><?php  echo $row['1']; ?></td>

                                        </tr>
                                        <?php
                                            $no++;
                                            $a++;
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                 <?php } ?>
                <!-- /.row -->
                <!-- row -->

                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center"> 2018 &copy; Modified by Vany Rofika </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!--Counter js -->
    <script src="plugins/bower_components/waypoints/lib/jquery.waypoints.js"></script>
    <script src="plugins/bower_components/counterup/jquery.counterup.min.js"></script>
    <!--Morris JavaScript -->
    <script src="plugins/bower_components/raphael/raphael-min.js"></script>
    <script src="plugins/bower_components/morrisjs/morris.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
    <script src="js/dashboard1.js"></script>
    <script src="plugins/bower_components/toast-master/js/jquery.toast.js"></script>
    <script type="text/javascript">
    $(document).ready(function() {
        $.toast({
            heading: '',
            text: 'Selamat Datang di Web Asisten Dosen STIKOM Amik Tunas Bangsa.',
            position: 'top-right',
            loaderBg: '#ff6849',
            icon: 'info',
            hideAfter: 3500,
            stack: 6
        })
    });
    </script>
</body>

</html>
