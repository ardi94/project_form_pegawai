<?php

if(isset($_POST['savedata']))
{
    $type=$_POST['type'];
    $a=$_POST['a'];
    $b=$_POST['b'];
    $c=$_POST['c'];
    $d=$_POST['d'];
    $e=$_POST['e'];
    $f=$_POST['f'];
    $g=$_POST['g'];
    $h=$_POST['h'];
    $i=$_POST['i'];
    $j=$_POST['j'];
    $k=$_POST['k'];

    $l=$_POST['l'];
    if($type=='tambah'){

      $sql="insert into tbl_mahasiswa value ('$a','$b','$k','$c','$d','$e','$f','$g','$h','$i','$j','$l','')";

    }elseif($type=='edit'){
      $sql="update tbl_mahasiswa set nm_mahasiswa='$b',  semester='$c',ipk='$d', wawancara='$e', sikap='$f', kehadiran='$g', sertifikat='$h', tesumum='$i', teskhusus='$j', matakuliah='$l' where nim='$a'";

    }

    if(mysqli_query($conn, $sql))
    {
      $sql="";
      if($type=='edit'){
        $successMSG = "Data mahasiswa berhasil diperbarui";

      }
      else {
        $successMSG = "Data mahasiswa berhasil ditambah";

      }
    }
    else
    {
      $errMSG = "error while saving data....";
    }
}
elseif(isset($_POST['hapus']))
{
    $a=$_POST['a'];
    $sql="delete  from tbl_mahasiswa where nim='$a'";

    if(mysqli_query($conn, $sql))
    {
      $successMSG = "Data mahasiswa berhasil dihapus";

    }
    else
    {
      $errMSG = "error while saving data....";
    }
}elseif(isset($_POST['hapusmk']))
{
    $a=$_POST['a'];
    $sql="delete  from tbl_matkul where id_m='$a'";
    mysqli_query($conn, $sql);
    $sql="delete  from tbl_mahasiswa where id_m='$a'";

    if(mysqli_query($conn, $sql))
    {
      $successMSG = "Data mahasiswa berhasil dihapus";

    }
    else
    {
      $errMSG = "error while saving data....";
    }
}
elseif(isset($_POST['savekriteria']))
{

    $type=$_POST['type'];
    $a=$_POST['a'];
    $b=$_POST['b'];
    $c=$_POST['c'];
    //$d=$_POST['d'];
    if(($c>0)&&($c<=5)){
        $y = 2;
        $result = fmod($c,$y);
        if(($result==0)||($result==1)){
            if($type=='tambah'){
        $sqli="select * from tbl_kriteria order by id_k desc limit 1";
        $result = $conn->query($sqli);
        $row = $result->fetch_assoc();
        $id=substr($row["id_k"], 1);
        $idc=$id+1;
        $id="C".$idc;
                $sql="insert into tbl_kriteria value ('$id','$b','$c')";
            }elseif($type=='edit'){
                $sql="update tbl_kriteria set  nm_k='$b', bobot='$c' where id_k='$a'";
            }

           if(mysqli_query($conn, $sql))
            {

              $successMSG = "Data Kritera berhasil diperbarui";

            }
            else
            {
              $errMSG = "error while saving data....";
            }

        }else{
            $errMSG = "Nilai bobot harus bilangan genap";
        }


    }else{
        $errMSG = "Nilai bobot harus dalam range 1 sd 4";
    }




}
elseif(isset($_POST['savematkul']))
{

    $type=$_POST['type'];
    $a=$_POST['a'];
    $b=$_POST['b'];
    if($type=='tambah'){
        $sqli="select * from tbl_matkul order by id_m desc limit 1";
        $result = $conn->query($sqli);
        $row = $result->fetch_assoc();
        $id=substr($row["id_m"], 1);
        $idc=$id+1;
        $id="M".$idc;
                $sql="insert into tbl_matkul value ('$id','$b')";
    }elseif($type=='edit'){
                $sql="update tbl_matkul set  nm_matkul='$b' where id_m='$a'";
    }

    if(mysqli_query($conn, $sql))
    {
      if($type=='tambah'){
        $successMSG = "Data Matakuliah berhasil disimpan";
      }else{
        $successMSG = "Data Matakuliah berhasil diperbarui";

      }
    }
    else
    {
      $errMSG = "error while saving data....";
    }

}elseif(isset($_POST['daftar']))
{

    $a=$_POST['user'];
    $b=$_POST['pass'];
    $c=$_POST['name'];
    $d='mahasiswa';
    $e=$_POST['nim'];
    $sql="insert into tbl_user value ('','$a','$b','$c','$d','$e')";


    if(mysqli_query($conn, $sql))
    {

      $successMSG = "Data user berhasil ditambah";

    }
    else
    {
      $errMSG = "error while saving data....";
    }
}
 ?>
