<?php
    include "koneksi/koneksi.php";
    include "sql/sql.php";
    if($_SESSION['id']==''){
        header("location: index.php");
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="plugins/images/favicon.png">
    <title>WEB - Seleksi Pemilihan Asisten Dosen</title>
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <!-- animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- color CSS -->
    <link href="css/colors/green.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <div id="wrapper">
        <!-- Navigation -->
        <?php include "nav.php"; ?>
        <!-- Left navbar-header -->
        <?php include "sidebar.php"; ?>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Data Matakuliah</h4> </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">Data Matakuliah</li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /row -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="white-box">
                           <?php
                            if(isset($errMSG)){
                            ?>
                            <meta http-equiv="refresh" content="5">
                            <div class="alert alert-danger">
                            <span class="glyphicon glyphicon-info-sign"></span> <strong><?php echo $errMSG; ?></strong>
                            </div>
                            <?php

                            }
                            else if(isset($successMSG)){
                            ?>
                            <meta http-equiv="refresh" content="10">
                            <div class="alert alert-success">
                            <strong><span class="glyphicon glyphicon-info-sign"></span> <?php echo $successMSG; ?></strong>
                            </div>
                            <?php
                            }

                          ?>
                            <h3 class="box-title">Data Matakuliah</h3>
                            <button class="btn btn-info" data-toggle='modal' data-target='#form' data-type="tambah">Tambah</button>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>ID MATAKULIAH</th>
                                            <th>NAMA MATAKULIAH</th>
                                            <th>AKSI</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no=1;
                                            $sql="select * from tbl_matkul";
                                            $result=mysqli_query($conn,$sql);
                                            while($row=mysqli_fetch_array($result,MYSQLI_NUM))
                                            {


                                        ?>
                                        <tr>
                                            <td><?php  echo $no; ?></td>
                                            <td><?php  echo $row['0']; ?></td>
                                            <td><?php  echo $row['1']; ?></td>

                                            <td>
                                            <button class="btn btn-warning" data-toggle="modal"
                                                data-target="#form"
                                                data-judul="Edit"
                                                data-type="edit"
                                                data-a="<?php  echo $row['0']; ?>"
                                                data-b="<?php  echo $row['1']; ?>"
                                                >Edit</button> &nbsp;
                                            <button class="btn btn-info" data-toggle="modal"
                                                data-target="#deleteform"
                                                data-type="hapus"
                                                data-a="Apakah anda ingin menghapus data ini?"
                                                data-b="<?php echo $row['0']; ?>"
                                                data-c="<?php echo $row['1']; ?>"
                                                 > Hapus</button>

                                            </td>
                                        </tr>
                                        <?php
                                            $no++;
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center"> 2018 &copy; Modified by Vany Rofika </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <div class="modal fade" id="form" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="exampleModalLabel">New message</h4>
          </div>
          <form method="post" action="">
              <div class="modal-body">
                    <input type="text" id="type" name="type"  hidden >
                    <input type="text" id="a" name="a"  hidden >
                  <div class="form-group">
                    <label for="recipient-name" class="control-label">NAMA MATAKULIAH</label>
                    <input type="text" class="form-control" id="b" name="b" required>
                  </div>

                  </div>
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" name="savematkul"  class="btn btn-primary">Save</button>
                  </div>
           </form>
        </div>
      </div>
    </div>
    <div class="modal fade" id="deleteform" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="a">New message</h4>
          </div>
          <div class="modal-body">
            <form method="post" action="">
              <div class="form-group">
                <input type="text" id="a" name="a"  hidden>
                <input type="text" id="b" name="b"  hidden>
              </div>
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" name="hapusmk" class="btn btn-primary"  >Save</button>
            </form>
          </div>
          <div class="modal-footer">

          </div>
        </div>
      </div>
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
    <script type="text/javascript">
        $('#form').on('show.bs.modal', function (event) {
          var button = $(event.relatedTarget) // Button that triggered the modal
          var judul = button.data('judul')
          var type = button.data('type')
          var a = button.data('a')
          var b = button.data('b')

          var modal = $(this)
          modal.find('.modal-title').text(judul)

          modal.find('.modal-body #type').val(type)
          modal.find('.modal-body #a').val(a)
          modal.find('.modal-body #b').val(b)
        })

        $('#deleteform').on('show.bs.modal', function (event) {
          var button = $(event.relatedTarget) // Button that triggered the modal
          var a = button.data('a')
          var b = button.data('b')
          var c = button.data('c')

          
          var modal = $(this)
          modal.find('.modal-title').text(a)
          modal.find('.modal-body #a').val(b)

          modal.find('.modal-body #b').val(c)

        })
    </script>
</body>

</html>
