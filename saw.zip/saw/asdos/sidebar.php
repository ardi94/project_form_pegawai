        <div class="navbar-default sidebar" role="navigation">
            <div class="sidebar-nav navbar-collapse slimscrollsidebar">
                <ul class="nav" id="side-menu">
                    <?php
                    $hakakses=$_SESSION['roles'];
                    $hakakses;
                    if($hakakses=='admin'){ ?>
                    <li style="padding: 10px 0 0;">
                        <a href="home.php" class="waves-effect"><i class="fa fa-clock-o fa-fw" aria-hidden="true"></i><span class="hide-menu">Home</span></a>
                    </li>
                    <li>
                        <a href="matakuliah.php" class="waves-effect"><i class="fa fa-book fa-fw" aria-hidden="true"></i><span class="hide-menu">Data Mata Kuliah</span></a>
                    </li>
                    <li>
                        <a href="mahasiswa.php" class="waves-effect"><i class="fa fa-users fa-fw" aria-hidden="true"></i><span class="hide-menu">Data Mahasiswa</span></a>
                    </li>
                    <li>
                        <a href="kriteria.php" class="waves-effect"><i class="fa fa-book fa-fw" aria-hidden="true"></i><span class="hide-menu">Data Kriteria</span></a>
                    </li>
                    <li>
                        <a href="metode.php" class="waves-effect"><i class="fa fa-book fa-fw" aria-hidden="true"></i><span class="hide-menu">Perhitungan</span></a>
                    </li>
                <?php }elseif($hakakses=='mahasiswa'){
                ?>
                    <li style="padding: 10px 0 0;">
                        <a href="home.php" class="waves-effect"><i class="fa fa-clock-o fa-fw" aria-hidden="true"></i><span class="hide-menu">Home</span></a>
                    </li>


                <?php
                }elseif($hakakses=='dosen'){
                ?>
                    <li style="padding: 10px 0 0;">
                        <a href="home.php" class="waves-effect"><i class="fa fa-clock-o fa-fw" aria-hidden="true"></i><span class="hide-menu">Home</span></a>
                    </li>
                    <li>
                        <a href="kriteria.php" class="waves-effect"><i class="fa fa-book fa-fw" aria-hidden="true"></i><span class="hide-menu">Data Kriteria</span></a>
                    </li>
                <?php
                    }
                ?>
                    <li>
                        <a href="proses/proseslogout.php" class="waves-effect"><i class="fa fa-sign-out fa-fw" aria-hidden="true"></i><span class="hide-menu">Logout</span></a>
                    </li>
                    <!--
                    <li>
                        <a href="basic-table.html" class="waves-effect"><i class="fa fa-table fa-fw" aria-hidden="true"></i><span class="hide-menu">Basic Table</span></a>
                    </li>
                    <li>
                        <a href="fontawesome.html" class="waves-effect"><i class="fa fa-font fa-fw" aria-hidden="true"></i><span class="hide-menu">Icons</span></a>
                    </li>
                    <li>
                        <a href="map-google.html" class="waves-effect"><i class="fa fa-globe fa-fw" aria-hidden="true"></i><span class="hide-menu">Google Map</span></a>
                    </li>
                    <li>
                        <a href="blank.html" class="waves-effect"><i class="fa fa-columns fa-fw" aria-hidden="true"></i><span class="hide-menu">Blank Page</span></a>
                    </li>
                    <li>
                        <a href="404.html" class="waves-effect"><i class="fa fa-info-circle fa-fw" aria-hidden="true"></i><span class="hide-menu">Error 404</span></a>
                    </li>
                -->
                </ul>

            </div>
        </div>
