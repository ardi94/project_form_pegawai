<?php
session_start();



$servername = "localhost";
$username = "root";
$password = "";
//$username = "u6124251_faf";
//$password = "bismillah94";
$dbname = "db_asisten";
// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
//echo "Connected successfully";

//include "../../sql/sql.php";
 ?>
