-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 20, 2018 at 02:48 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_asisten`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kriteria`
--

CREATE TABLE `tbl_kriteria` (
  `id_k` varchar(3) NOT NULL,
  `nm_k` varchar(25) NOT NULL,
  `bobot` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_kriteria`
--

INSERT INTO `tbl_kriteria` (`id_k`, `nm_k`, `bobot`) VALUES
('C1', 'IPK', 4),
('C2', 'WAWANCARA', 3),
('C3', 'SIKAP', 2),
('C4', 'KEHADIRAN', 1),
('C5', 'SERTIFIKAT', 3),
('C6', 'TES UMUM', 3),
('C7', 'TES KHUSUS', 3);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_mahasiswa`
--

CREATE TABLE `tbl_mahasiswa` (
  `nim` varchar(15) NOT NULL,
  `nm_mahasiswa` varchar(25) NOT NULL,
  `id_m` varchar(3) NOT NULL,
  `semester` int(11) NOT NULL,
  `ipk` double NOT NULL,
  `wawancara` int(11) NOT NULL,
  `sikap` int(11) NOT NULL,
  `kehadiran` int(11) NOT NULL,
  `sertifikat` int(11) NOT NULL,
  `tesumum` int(11) NOT NULL,
  `teskhusus` int(11) NOT NULL,
  `nilai` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_mahasiswa`
--

INSERT INTO `tbl_mahasiswa` (`nim`, `nm_mahasiswa`, `id_m`, `semester`, `ipk`, `wawancara`, `sikap`, `kehadiran`, `sertifikat`, `tesumum`, `teskhusus`, `nilai`) VALUES
('2016-01-03-0001', 'ade harti', 'M1', 4, 3.63, 80, 75, 13, 4, 90, 70, 0.546),
('2016-01-03-0016', 'hartika simanjuntak', 'M1', 4, 3.28, 70, 75, 14, 3, 90, 70, 0.462),
('2016-01-03-0056', 'Paracetamol', 'M2', 5, 3.9, 90, 84, 14, 4, 80, 80, 0.876),
('2016-01-03-0090', 'Aisyah', 'M2', 6, 3.7, 90, 90, 13, 4, 85, 86, 0.922),
('2016-01-03-0094', 'fikri haikal', 'M1', 4, 3.06, 75, 90, 14, 1, 89, 90, 0.533),
('2016-01-03-0108', 'muhammad rafly', 'M1', 4, 3.38, 70, 85, 13, 0, 0, 0, 0.19),
('2016-01-03-0117', 'ade candra', 'M1', 4, 3.25, 85, 75, 14, 0, 0, 0, 0.184),
('2016-01-03-0167', 'elisa', 'M1', 4, 3.47, 70, 75, 14, 0, 0, 0, 0.15),
('2017-01-03-0028', 'risa irwanda', 'M1', 2, 3.09, 80, 70, 12, 0, 0, 0, 0.116),
('2017-01-03-0031', 'sri wulandika', 'M1', 2, 3.82, 75, 85, 14, 0, 0, 0, 0.264),
('2017-01-03-0032', 'srikandi gita anggraini', 'M1', 2, 3.27, 70, 80, 13, 0, 0, 0, 0.19),
('2017-01-03-0083', 'agung surya', 'M1', 2, 3, 80, 75, 14, 0, 0, 0, 0.14);

-- --------------------------------------------------------

--
-- Table structure for table `tbl_matkul`
--

CREATE TABLE `tbl_matkul` (
  `id_m` varchar(3) NOT NULL,
  `nm_matkul` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_matkul`
--

INSERT INTO `tbl_matkul` (`id_m`, `nm_matkul`) VALUES
('M1', 'Pemrograman Web IT'),
('M2', 'Pemrograman C'),
('M3', 'Teknik Arsitektur Komputer');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `id` int(11) NOT NULL,
  `username` varchar(25) NOT NULL,
  `password` varchar(25) NOT NULL,
  `name` varchar(35) NOT NULL,
  `roles` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`id`, `username`, `password`, `name`, `roles`) VALUES
(1, 'admin', 'admin', 'Vany Rofika', 'admin'),
(2, 'dosen', 'dosen', 'Dosen', 'dosen'),
(3, 'mahasiswa', 'mahasiswa', 'Mahasiswa', 'mahasiswa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_kriteria`
--
ALTER TABLE `tbl_kriteria`
  ADD PRIMARY KEY (`id_k`);

--
-- Indexes for table `tbl_mahasiswa`
--
ALTER TABLE `tbl_mahasiswa`
  ADD PRIMARY KEY (`nim`);

--
-- Indexes for table `tbl_matkul`
--
ALTER TABLE `tbl_matkul`
  ADD PRIMARY KEY (`id_m`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
