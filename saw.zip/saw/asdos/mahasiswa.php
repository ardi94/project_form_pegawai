<?php
    include "koneksi/koneksi.php";
    include "sql/sql.php";
    if($_SESSION['id']==''){
        header("location: index.php");
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="plugins/images/favicon.png">
    <title>WEB - Seleksi Pemilihan Asisten Dosen</title>
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <!-- animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- color CSS -->
    <link href="css/colors/green.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <div id="wrapper">
        <!-- Navigation -->
        <?php include "nav.php"; ?>
        <!-- Left navbar-header -->
        <?php include "sidebar.php"; ?>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Data Mahasiswa</h4> </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">Data Mahasiswa</li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /row -->
                <div class="row">
                    <div class="col-sm-12">
                          <?php
                            if(isset($errMSG)){
                            ?>
                            <meta http-equiv="refresh" content="5">
                            <div class="alert alert-danger">
                            <span class="glyphicon glyphicon-info-sign"></span> <strong><?php echo $errMSG; ?></strong>
                            </div>
                            <?php

                            }
                            else if(isset($successMSG)){
                            ?>
                            <meta http-equiv="refresh" content="10">
                            <div class="alert alert-success">
                            <strong><span class="glyphicon glyphicon-info-sign"></span> <?php echo $successMSG; ?></strong>
                            </div>
                            <?php
                            }

                          ?>
                          <button class="btn btn-info" onclick="tambah()" data-toggle='modal'  data-target='#form' data-type="tambah" style="float: right;">Tambah Mahasiswa</button>

                          <?php
                            $sqlmat="select * from tbl_matkul order by id_m asc";
                            $resultt=mysqli_query($conn,$sqlmat);
                            while($rowmat=mysqli_fetch_array($resultt,MYSQLI_NUM))
                            {
                          ?>
                            <h3 class="box-title">Data Mahasiswa <?php echo $rowmat['1']; ?></h3>
                          <?php
                          $sql="select * from tbl_mahasiswa where id_m='".$rowmat['0']."'";
                          $result=mysqli_query($conn,$sql);

                            if($result->num_rows > 0){
                          ?>
                          <div class="white-box">

                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>#</th>
                                            <th>NIM</th>
                                            <th>NAMA</th>
                                            <th>SEMESTER</th>
                                            <th>IPK</th>
                                            <th>WAWANCARA</th>
                                            <th>SIKAP</th>
                                            <th>KEHADIRAN</th>
                                            <th>SERTIFIKAT</th>
                                            <th>TES UMUM</th>
                                            <th>TES KHUSUS</th>
                                            <th>MATA KULIAH <br><?php echo $rowmat['1']; ?></th>
                                            <th>AKSI</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no=1;
                                          while($row=mysqli_fetch_array($result,MYSQLI_NUM))
                                            {


                                        ?>
                                        <tr>
                                            <td><?php  echo $no; ?></td>
                                            <td><?php  echo $row['0']; ?></td>
                                            <td><?php  echo $row['1']; ?></td>
                                            <td><?php  echo $row['3']; ?></td>
                                            <td><?php  echo $row['4']; ?></td>
                                            <td><?php  echo $row['5']; ?></td>
                                            <td><?php  echo $row['6']; ?></td>
                                            <td><?php  echo $row['7']; ?></td>
                                            <td><?php  echo $row['8']; ?></td>
                                            <td><?php  echo $row['9']; ?></td>
                                            <td><?php  echo $row['10']; ?></td>
                                            <td><?php  echo $row['11']; ?></td>
                                            <td>
                                            <button class="btn btn-info" onclick="edit()" data-toggle="modal"
                                                data-target="#form"
                                                data-judul="Edit"
                                                data-type="edit"
                                                data-a="<?php  echo $row['0']; ?>"
                                                data-b="<?php  echo $row['1']; ?>"
                                                data-c="<?php  echo $row['3']; ?>"
                                                data-d="<?php  echo $row['4']; ?>"
                                                data-e="<?php  echo $row['5']; ?>"
                                                data-f="<?php  echo $row['6']; ?>"
                                                data-g="<?php  echo $row['7']; ?>"
                                                data-h="<?php  echo $row['8']; ?>"
                                                data-i="<?php  echo $row['9']; ?>"
                                                data-j="<?php  echo $row['10']; ?>"

                                                data-j="<?php  echo $row['11']; ?>"
                                                data-k="<?php  echo $row['2']; ?>"
                                                >Edit</button> &nbsp;
                                            <button class="btn btn-info" data-toggle="modal"
                                                data-target="#deleteform"
                                                data-type="hapus"
                                                data-a="Apakah anda ingin menghapus data ini?"
                                                data-b="<?php echo $row['0']; ?>" > Hapus</button>
                                            </td>
                                        </tr>
                                        <?php
                                            $no++;
                                        }
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                          </div>
                          <?php }else{
                            ?>
                            <div class="white-box">

                              <p style="text-align:center;">Tidak ada mahasiswa untuk program Asiten Dosen Mata Kuliah <?php echo $rowmat['1']; ?></p>
                                </div>
                            <?php
                          }
                        } ?>

                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center"> 2018 &copy; Modified by Vany Rofika </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <div class="modal fade" id="form" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="exampleModalLabel">New message</h4>
          </div>
          <form method="post" action="">
              <div class="modal-body">
                <div class='col-md-6 ' >
                  <div class="form-group">
                    <label for="message-text" class="control-label">NIM</label>
                    <input type="text" id="type" name="type"  hidden >
                     <input type="text" class="form-control idtambah" id="a" name="a" pattern="[0-9]{4}[\-]?[0-9]{2}[\-]?[0-9]{2}[\-]?[0-9]{4}" title="Format Harrus Sesuai 2016-01-01-0001" onkeyup="checkname();"  disabled="disabled" required>
                     <input type="text" id="a" name="a" class="idedit"  disabled="disabled" hidden>
                     <span id="name_status"></span>
                    </div>
               </div>
               <div class='col-md-6'>

                  <div class="form-group">
                    <label for="recipient-name" class="control-label">NAMA</label>
                    <input type="text" class="form-control" id="b" name="b"  required>
                   </div>
              </div>
              <div class='col-md-6'>

                 <div class="form-group">
                   <label for="recipient-name" class="control-label">Mata Kuliah</label>
                   <select type="text" class="form-control"  id="k" name="k"  required>
                     <?php
                     $sqlmat="select * from tbl_matkul ";
                     $resultt=mysqli_query($conn,$sqlmat);
                     while($rowmat=mysqli_fetch_array($resultt,MYSQLI_NUM))
                     {
                     ?>
                      <option value="<?php echo $rowmat['0']; ?>"><?php echo $rowmat['1']; ?></option>
                    <?php } ?>
                   </select>

                  </div>
             </div>
              <div class='col-md-6'>

                  <div class="form-group">
                    <label for="message-text" class="control-label">SEMESTER</label>
                    <input type="number" class="form-control" id="c" name="c"  min="2" max="8" pattern="[3-6]{1}" title="Semester harus di antara semester 3-6" required>

                  </div>
              </div>
               <div class='col-md-6'>
                  <div class="form-group">
                    <label for="message-text" class="control-label">IPK</label>
                    <input type="text" class="form-control" id="d" name="d" pattern="[0-9]+([\.,][0-9]+)?" title="Nilai harus bilangan positif" required>

                  </div>
              </div>
              <div class='col-md-6'>

                  <div class="form-group">
                    <label for="message-text" class="control-label">WAWANCARA</label>
                    <input type="number" class="form-control" id="e" name="e" min="0" max="100" pattern="[0-9]" title="Nilai harus di antara 1 sd 100" required>

                  </div>
                </div>
               <div class='col-md-6'>
                  <div class="form-group">
                    <label for="message-text" class="control-label">SIKAP</label>
                    <input type="number" class="form-control" id="f" name="f" min="0" max="100" pattern="[0-9]" title="Nilai harus di antara 1 sd 100" required >

                  </div>
              </div>
              <div class='col-md-6'>
                  <div class="form-group">
                    <label for="message-text" class="control-label">KEHADIRAN</label>
                    <input type="number" class="form-control" id="g" name="g" min="0" max="14" pattern="[0-9]" title="Nilai harus di antara 1 sd 14" required>

                </div>
              </div>
              <div class='col-md-6'>
                  <div class="form-group">
                    <label for="message-text" class="control-label">SERTIFIKAT</label>
                    <input type="number" class="form-control" id="h" name="h" min="0" max="4" pattern="[0-9]" title="Nilai harus di antara 1 sd 4" required>

                  </div>
               </div>
               <div class='col-md-6'>
                   <div class="form-group">
                     <label for="message-text" class="control-label">TES UMUM</label>
                     <input type="number" class="form-control" id="i" name="i" min="0" max="100" pattern="[0-9]" title="Nilai harus di antara 1 sd 100" required>

                   </div>
                </div>
                <div class='col-md-6'>
                    <div class="form-group">
                     <label for="message-text" class="control-label">TES KHUSUS</label>
                     <input type="number" class="form-control" id="j" name="j" min="0" max="100" pattern="[0-9]" title="Nilai harus di antara 1 sd 100" required>

                  </div>
                </div>
                <div class='col-md-6'>
                    <div class="form-group">
                     <label for="message-text" class="control-label">NILAI MATA KULIAH</label>
                     <input type="number" class="form-control" id="l" name="l" min="0" max="100" pattern="[0-9]" title="Nilai harus di antara 1 sd 100" required>
                  </div>
                </div>
              </div>

                  <div class="modal-footer">

                    <button type="submit" class="btn btn-default " data-dismiss="modal">Close</button>
                    <button type="submit" name="savedata"  class="btn btn-primary enableOnInput" disabled='disabled'>Save</button>
                  </div>

           </form>
        </div>
      </div>
    </div>

    <div class="modal fade" id="deleteform" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="a">New message</h4>
          </div>
          <div class="modal-body">
            <form method="post" action="">
              <div class="form-group">
                <input type="text" id="a" name="a" hidden >
              </div>
              <button type="button" class="btn btn-default" data-dismiss="modal" >Close</button>
              <button type="submit" name="hapus" class="btn btn-primary"  >Save</button>
            </form>
          </div>
          <div class="modal-footer">

          </div>
        </div>
      </div>
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
    <script  type="text/javascript">

    function edit()
    {
      $('.enableOnInput').prop('disabled', false);
         $('.idedit').prop('disabled', false);
    }
    function tambah()
    {

         $('.idtambah').prop('disabled', false);
    }
  function checkname()
  {
   var name=document.getElementById( "a" ).value;
   var type=document.getElementById( "type" ).value;
   if((name)&&(type==='tambah'))
   {

    $.ajax({
    type: 'post',
    url: 'checkdata.php',
    data: {
     user_name:name,
    },
    success: function (response) {
     $( '#name_status' ).html(response);
     if(response=="OK")
     {
         $('.enableOnInput').prop('disabled', false);
      return true;

     }
     else
     {
       $('.enableOnInput').prop('disabled', true);


      return false;
     }
    }
    });
   }
   else if(type==='edit')
   {

    $('.enableOnInput').prop('disabled', false);
    return false;
   }
   else
   {
    $( '#name_status' ).html("");

    return false;
   }
  }

  function checkemail()
  {
   var email=document.getElementById( "UserEmail" ).value;

   if(email)
   {
    $.ajax({
    type: 'post',
    url: 'checkdata.php',
    data: {
     user_email:email,
    },
    success: function (response) {
     $( '#email_status' ).html(response);
     if(response=="OK")
     {
      return true;
     }
     else
     {
      return false;
     }
    }
    });
   }
   else
   {
    $( '#email_status' ).html("");
    return false;
   }
  }

  function checkall()
  {
   var namehtml=document.getElementById("name_status").innerHTML;
   var emailhtml=document.getElementById("email_status").innerHTML;

   if((namehtml && emailhtml)=="OK")
   {
    return true;
   }
   else
   {
    return false;
   }
  }

  </script>
    <script type="text/javascript">
        $('#form').on('show.bs.modal', function (event) {
          var button = $(event.relatedTarget) // Button that triggered the modal
          var judul = button.data('judul')
          var type = button.data('type')
          var a = button.data('a')
          var b = button.data('b')
          var c = button.data('c')
          var d = button.data('d')
          var e = button.data('e')
          var f = button.data('f')
          var g = button.data('g')
          var h = button.data('h')
          var i = button.data('i')
          var j = button.data('j')
          var k = button.data('k')
          var modal = $(this)
          modal.find('.modal-title').text(judul)

          modal.find('.modal-body #type').val(type)
          modal.find('.modal-body #a').val(a)
          modal.find('.modal-body #b').val(b)
          modal.find('.modal-body #c').val(c)
          modal.find('.modal-body #d').val(d)
          modal.find('.modal-body #e').val(e)
          modal.find('.modal-body #f').val(f)
          modal.find('.modal-body #g').val(g)
          modal.find('.modal-body #h').val(h)
          modal.find('.modal-body #i').val(i)
          modal.find('.modal-body #j').val(j)
          modal.find('.modal-body #k').val(k)
        })

        $('#deleteform').on('show.bs.modal', function (event) {
          var button = $(event.relatedTarget) // Button that triggered the modal
          var a = button.data('a')
          var b = button.data('b')
          var modal = $(this)
          modal.find('.modal-title').text(a)
          modal.find('.modal-body #a').val(b)
        })
    </script>
</body>

</html>
