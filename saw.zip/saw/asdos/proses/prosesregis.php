<?php
	include "../koneksi/koneksi.php";
	$user=$_POST['user'];
	$pass=$_POST['pass'];
	$nama=$_POST['name'];
	$sql = " INSERT INTO tbl_user (id,user,pass,nama,foto) values ('','$user','$pass','$nama','')";
	$result = $conn->query($sql);
	$conn->close();
	header('Location: ../');
	exit;
?>
