<?php
	include "../koneksi/koneksi.php";
	$user=$_POST['user'];
	$pass=$_POST['pass'];
	$roles=$_POST['roles'];
//$matkul=$_POST['matkul'];
	if($_POST['matkul']==''){

	}else {
			$matkul=$_POST['matkul'];
			$_SESSION['matkul']=$matkul;
	}
	$sql = "SELECT * FROM tbl_user where username='$user' and password='$pass' and roles='$roles'";
	$result = $conn->query($sql);
	if ($result->num_rows > 0) {
     	$row = $result->fetch_assoc();
    	$_SESSION['id']=$row["id"];
    	$_SESSION['name']=$row["name"];
    	$_SESSION['roles']=$row["roles"];

				header('Location: ../home.php');
     }else{

      	$conn->close();
      	header('Location: ../');
		exit;
     }
 ?>
