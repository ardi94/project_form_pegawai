<?php
    include "koneksi/koneksi.php";
    include "sql/sql.php";
    if($_SESSION['id']==''){
        header("location: index.php");
    }
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" type="image/png" sizes="16x16" href="plugins/images/favicon.png">
    <title>WEB - Seleksi Pemilihan Asisten Dosen</title>
    <!-- Bootstrap Core CSS -->
    <link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
    <!-- Menu CSS -->
    <link href="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.css" rel="stylesheet">
    <!-- animation CSS -->
    <link href="css/animate.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="css/style.css" rel="stylesheet">
    <!-- color CSS -->
    <link href="css/colors/green.css" id="theme" rel="stylesheet">
    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->
</head>

<body>
    <!-- Preloader -->
    <div class="preloader">
        <div class="cssload-speeding-wheel"></div>
    </div>
    <div id="wrapper">
        <!-- Navigation -->
        <?php include "nav.php"; ?>
        <!-- Left navbar-header -->
        <?php include "sidebar.php"; ?>
        <!-- Left navbar-header end -->
        <!-- Page Content -->
        <div id="page-wrapper">
            <div class="container-fluid">
                <div class="row bg-title">
                    <div class="col-lg-3 col-md-4 col-sm-4 col-xs-12">
                        <h4 class="page-title">Data Mahasiswa</h4> </div>
                    <div class="col-lg-9 col-sm-8 col-md-8 col-xs-12">
                        <ol class="breadcrumb">
                            <li><a href="#">Dashboard</a></li>
                            <li class="active">Data Mahasiswa</li>
                        </ol>
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /row -->
                <div class="row">
                    <div class="col-sm-12">
                      <?php
                        $sqlmat="select * from tbl_matkul order by id_m asc";
                        $resulmat=mysqli_query($conn,$sqlmat);
                        while($rowmat=mysqli_fetch_array($resulmat,MYSQLI_NUM))
                        {
                          $sql="select * from tbl_mahasiswa where id_m='".$rowmat['0']."'";
                          $result=mysqli_query($conn,$sql);
                          if ($result->num_rows > 0) {
                      ?>
                        <div class="white-box">

                            <h3 class="box-title">Daftar Mahasiswa <?php echo $rowmat['1']; ?></h3>
                             <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>NIM</th>
                                            <th>NAMA</th>
                                            <th>C1<br>PRODUKTIVITAS</th>
                                            <th>C2<br>KOMPETENSI</th>
                                            <th>C3<br>BUDAYA</th>
                                          
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no=1;

                                          $a=0;
                                            unset($nilai);
                                            $nilai = array();
                                            while($row=mysqli_fetch_array($result,MYSQLI_NUM))
                                            { $d=0;
                                              for($i=0; $i<4; $i++){
                                                $d=$i+2;
                                                $nilai[$a][$i]=$row[$d];
                                              }


                                        ?>
                                        <tr>
                                            <td><?php  echo $row['0']; ?></td>
                                            <td><?php  echo $row['1']; ?></td>

                                            <td><?php  echo $row['4']; ?></td>

                                            <td><?php  echo $row['5']; ?></td>
                                            <td><?php  echo $row['6']; ?></td>



                                        </tr>
                                        <?php
                                            $no++;
                                            $a++;
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            </div>
                             <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>NO</th>
                                            <th>NAMA</th>
                                            <th>C1<br>Produktivitas</th>
                                            <th>C2<br>KOMPETENSI</th>
                                            <th>C3<br>BUDAYA</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no=1;
                                            unset($index);
                                            $index = array();
                                            $sql="select * from tbl_mahasiswa where id_m='".$rowmat['0']."'";
                                            $result=mysqli_query($conn,$sql);
                                            $a=0;
                                            while($row=mysqli_fetch_array($result,MYSQLI_NUM))
                                            {
                                              $ix=$no-1;
                                              $index[$ix]=$row['0'];
                                              echo "<tr><td>".$no."</td>";
                                              echo "<td>".$row['1']."</td>";

                                              $d=0;
                                              for($i=0; $i<3; $i++){
                                                $d=$i+4;
                                                if($i==0){
                                                  $Produktivitas=$row[$d];
                                                  if(($Produktivitas<0)&&($Produktivitas<=1)){
                                                    $nilai[$a][$i]=1;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }elseif(($Produktivitas<1)&&($Produktivitas<=2)){
                                                    $nilai[$a][$i]=2;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }elseif(($Produktivitas>2)&&($Produktivitas<=3)){
                                                    $nilai[$a][$i]=3;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }elseif(($Produktivitas>3)&&($Produktivitas<=4)){
                                                    $nilai[$a][$i]=4;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }elseif(($Produktivitas>4)&&($Produktivitas<=5)){
                                                    $nilai[$a][$i]=5;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }elseif(($Produktivitas>5)&&($Produktivitas<=6)){
                                                    $nilai[$a][$i]=6;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }

                                                }elseif($i==1){
                                                  $KOMPETENSI=$row[$d];
                                                  if(($KOMPETENSI>0)&&($KOMPETENSI<=1)){
                                                    $nilai[$a][$i]=1;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }elseif(($KOMPETENSI>1)&&($KOMPETENSI<=2)){
                                                    $nilai[$a][$i]=2;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }elseif(($KOMPETENSI>2)&&($KOMPETENSI<=3)){
                                                    $nilai[$a][$i]=3;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }elseif(($KOMPETENSI>3)&&($KOMPETENSI<=4)){
                                                    $nilai[$a][$i]=4;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }elseif(($KOMPETENSI>4)&&($KOMPETENSI<=5)){
                                                    $nilai[$a][$i]=5;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }elseif(($KOMPETENSI>5)&&($KOMPETENSI<=6)){
                                                    $nilai[$a][$i]=6;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }

                                                }elseif($i==2){
                                                  $BUDAYA=$row[$d];
                                                  if(($KOMPETENSI>0)&&($BUDAYA<=1)){
                                                    $nilai[$a][$i]=1;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }elseif(($BUDAYA>1)&&($BUDAYA<=2)){
                                                    $nilai[$a][$i]=2;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }elseif(($BUDAYA>2)&&($BUDAYA<=3)){
                                                    $nilai[$a][$i]=3;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }elseif(($BUDAYA>3)&&($BUDAYA<=4)){
                                                    $nilai[$a][$i]=4;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }elseif(($BUDAYA>4)&&($BUDAYA<=5)){
                                                    $nilai[$a][$i]=5;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }elseif(($BUDAYA>5)&&($BUDAYA<=6)){
                                                    $nilai[$a][$i]=6;
                                                    echo "<td>".$nilai[$a][$i]. "</td>";
                                                  }
                                                }
                                                // elseif($i==3){
                                                //   $kehadiran=$row[$d];

                                                //   if($kehadiran<=10){
                                                //     $nilai[$a][$i]=1;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($kehadiran>10)&&($kehadiran<=11)){
                                                //     $nilai[$a][$i]=2;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($kehadiran>11)&&($kehadiran<=13)){
                                                //     $nilai[$a][$i]=3;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($kehadiran>13)&&($kehadiran<=14)){
                                                //     $nilai[$a][$i]=4;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }

                                                // }elseif($i==4){
                                                //   $sertifikat=$row[$d];
                                                //   if($sertifikat<=1){
                                                //     $nilai[$a][$i]=1;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($sertifikat==2)){
                                                //     $nilai[$a][$i]=2;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($sertifikat==3)){
                                                //     $nilai[$a][$i]=3;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($sertifikat>=4)){
                                                //     $nilai[$a][$i]=4;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }

                                                // }elseif($i==5){
                                                //   $umum=$row[$d];
                                                //   if($umum<=70){
                                                //     $nilai[$a][$i]=1;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($umum>70)&&($umum<=79)){
                                                //     $nilai[$a][$i]=2;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($umum>79)&&($umum<=89)){
                                                //     $nilai[$a][$i]=3;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($umum>89)&&($umum<=100)){
                                                //     $nilai[$a][$i]=4;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }
                                                // }elseif($i==6){
                                                //   $khusus=$row[$d];
                                                //   if($khusus<=70){
                                                //     $nilai[$a][$i]=1;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($khusus>70)&&($khusus<=79)){
                                                //     $nilai[$a][$i]=2;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($khusus>79)&&($khusus<=89)){
                                                //     $nilai[$a][$i]=3;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($khusus>89)&&($khusus<=100)){
                                                //     $nilai[$a][$i]=4;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }
                                                // }elseif($i==7){
                                                //   $mk=$row[$d];
                                                //   if($mk<=70){
                                                //     $nilai[$a][$i]=1;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($mk>70)&&($mk<=79)){
                                                //     $nilai[$a][$i]=2;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($mk>79)&&($mk<=89)){
                                                //     $nilai[$a][$i]=3;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }elseif(($mk>89)&&($mk<=100)){
                                                //     $nilai[$a][$i]=4;
                                                //     echo "<td>".$nilai[$a][$i]. "</td>";
                                                //   }
                                                // }
                                                //$nilai[$a][$i]=$row[$d];
                                               // echo ' index ['.$a.'-'.$i.'] = '.$nilai[$a][$i].' ';
                                              }
                                              //echo "<br>";

                                        ?>
                                        </tr>
                                        <?php
                                            $no++;
                                            $a++;
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            </div>

                            <?php
                            unset($nilai[1][3]);
                             $baris=count($nilai);
                             $kolom=count($nilai[1]);
                              $jum=0;
                            for($a=0; $a<$kolom; $a++){
                              $c=$a+1;
                                 $jum=0;

                              for($b=0; $b<$baris; $b++){
                                 $d=$b+1;
                              //  echo 'R ['.$d.' '.$c.']';
                               // echo ' ';
                                $nilai[$b][$a];
                                 $kuadrat[$a]=$nilai[$b][$a]*$nilai[$b][$a];
                                 $jum+=$kuadrat[$a];
                               ?>
                               <?php
                              }
                              // $jum.' '.' akar^2 ( '.$jum.' ) = ';
                              $jj[$a]=$jum;
                             $jumm[$a]=number_format(sqrt($jum),3);
                              ?>


                               <?php
                            }
                            ?>

                             <!--
                            Matrik Keputusan R -->
                          <hr>
                          <div style="text-align:center;">
                           <b >
                       Matrik Keputusan R
                           
                           </b> 
                          </div>
                            <hr>

                           <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $nog=1;
                                      $baris=count($nilai);
                                      $kolom=count($nilai[1]);
                                      for($a=0; $a<$baris; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';
                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          echo $nilai[$a][$b];
                                          echo '</td>';
                                        }
                                        echo " </tr>";
                                        $nog++;
                                      }
                                    ?>
                                    <tr>

                                    </tr>
                                    </tbody>
                                </table>
                            </div>

                            <!--
                           hasil normalisasi rij dari matrik r
                         -->
                               <hr>
                                <div style="text-align:center;">
                           <b>
                       hasil normalisasi rij dari matrik r
                           
                           </b> 
                           </div>
                            <hr>

                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $nog=1;
                                      $baris=count($nilai);
                                      $kolom=count($nilai[1]);
                                      for($a=0; $a<$baris; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';
                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          echo $kuadrat[$a]=$nilai[$a][$b]*$nilai[$a][$b];
                                          echo '</td>';
                                          //$jum+=$kuadrat[$a];
                                         // $jumlah[$a]=$jum;
                                        }

                                        echo " </tr>";
                                        $nog++;
                                      }
                                    ?>
                                    <tr>
                                    <td>Jumlah</td>
                                        <?php
                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          echo $jj[$b];
                                          echo '</td>';
                                          //$jum+=$kuadrat[$b];
                                        }
                                        ?>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                          <!--
                            Normalisai Rij
                          -->
                             <hr>
                              <div style="text-align:center;">
                           <b>
                        Normalisai Rij
                           
                           </b> 
                           </div>
                            <hr>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>
                                        </tr>
                                    </thead>
                                    <tbody>

                                    <tr>
                                    <td>Jumlah</td>
                                        <?php
                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          //echo $jj[$b];
                                          echo ' '.' akar^2 ( '.$jj[$b].' ) = ';

                                         echo $jumm[$a]=number_format(sqrt($jj[$b]),3);
                                         echo '</td>';
                                        }
                                        ?>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>




                            <!--Matrik X1-->
                            <hr>
                             <div style="text-align:center;">
                           <b>
                         Matrik X1
                           
                           </b> 
                           </div>
                            <hr>

                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>]
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $nog=1;
                                      $baris=count($nilai);
                                      $kolom=count($nilai[1]);
                                      $tmp=0;
                                      $r=[];
                                      for($a=0; $a<$baris; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';

                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          echo $nilai[$a][$b].' / '.$jumm[$b].' = ';
                                          $tmp= number_format($nilai[$a][$b]/$jumm[$b],3);
                                          $r[$a][$b]=$tmp;
                                          echo $tmp;
                                          echo '</td>';
                                        }
                                        echo " </tr>";
                                        $nog++;
                                      }
                                    ?>
                                    <tr>

                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                          <!--  Hasil Normalisi -->
                            <hr>
                             <div style="text-align:center;">
                           <b>
                          Hasil Normalisi
                           
                           </b> 
                           </div>
                            <hr>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $nog=1;
                                      $baris=count($nilai);
                                      $kolom=count($nilai[1]);
                                      for($a=0; $a<$baris; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';
                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          echo $r[$a][$b];
                                          echo '</td>';
                                        }
                                        echo " </tr>";
                                        $nog++;
                                      }
                                    ?>
                                    <tr>

                                    </tr>
                                    </tbody>
                                </table>
                            </div>

                        <!--    Matrik Normalisai Terbobot -->
                           <hr>
                            <div style="text-align:center;">
                           <b>
                           Matrik Normalisai Terbobot
                           
                           </b> 
                           </div>
                            <hr>
                            <div class="table-responsive">
                                <table class="table">
                                    <thead>
                                        <tr>
                                            <th>- </th>
                                            <th>1</th>
                                            <th>2</th>
                                            <th>3</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php
                                    $sql="select * from tbl_kriteria";
                                    $result=mysqli_query($conn,$sql);
                                             $a=0;
                                             while($row=mysqli_fetch_array($result,MYSQLI_NUM))
                                             {
                                                $bobot[$a]=$row['2'];
                                                $a++;
                                             }
                                      $nog=1;
                                      $baris=count($nilai);
                                      $kolom=count($nilai[1]);
                                      for($a=0; $a<$baris; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';
                                        for($b=0; $b<$kolom; $b++){
                                          echo '<td>';
                                          echo $bobot[$b].' * '.$r[$a][$b].' = ';
                                          echo $n[$a][$b]=$bobot[$b]*$r[$a][$b];
                                         // echo $r[$a][$b];
                                          echo '</td>';
                                        }
                                        echo " </tr>";
                                        $nog++;
                                      }
                                    ?>
                                    <tr>

                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                          <!--  Matrik Solusi Ideal Positif A + -->
                             <hr>
                              <div style="text-align:center;">
                           <b>
                           Matrik Solusi Ideal Negatif A +
                           
                           </b> 
                           </div>
                            <hr>
                            <div class="table-responsive">
                                <table class="table">

                                    <tbody>
                                    <?php
                                      $nog=1;
                                      $baris=count($nilai);
                                      $kolom=count($nilai[1]);
                                      for($a=0; $a<1; $a++){
                                        echo "<tr>";
                                        for($b=0; $b<=$baris; $b++){

                                          echo "<td>";
                                          echo $b;
                                          echo "</td>";

                                        }
                                        echo "<td>MAX</td>";
                                        echo "</tr>";
                                      }
                                      for($a=0; $a<$kolom; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';
                                        for($b=0; $b<$baris; $b++){
                                          echo '<td>';
                                          echo $n[$b][$a];
                                          $nill[$a][$b]=$n[$b][$a];
                                         // echo $r[$a][$b];
                                          echo '</td>';
                                        }
                                        echo "<td>".$max=max($nill[$a])."</td>";
                                        $nilaii[$a]=$max;
                                        echo " </tr>";
                                        $nog++;
                                      }
                                    ?>
                                    <tr>

                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            <?php // print_r($nilaii);  ?>

                            <!--
                            Matrik Solusi Ideal Negatif A -
                          -->
                            <hr>
                             <div style="text-align:center;">
                           <b>
                           Matrik Solusi Ideal Negatif A -
                           
                           </b> 
                           </div>
                            <hr>
                            <div class="table-responsive">
                                <table class="table">

                                    <tbody>
                                    <?php
                                      $nog=1;
                                      $baris=count($nilai);
                                      $kolom=count($nilai[1]);
                                      for($a=0; $a<1; $a++){
                                        echo "<tr>";
                                        for($b=0; $b<=$baris; $b++){

                                          echo "<td>";
                                          echo $b;
                                          echo "</td>";

                                        }
                                        echo "<td>MIN</td>";
                                        echo "</tr>";
                                      }
                                      for($a=0; $a<$kolom; $a++){
                                        echo ' <tr> ';
                                        echo '<td>'.$nog.'</td>';
                                        for($b=0; $b<$baris; $b++){
                                          echo '<td>';
                                          echo $n[$b][$a];
                                          $nill[$a][$b]=$n[$b][$a];
                                         // echo $r[$a][$b];
                                          echo '</td>';
                                        }
                                        echo "<td>".$min=min($nill[$a])."</td>";
                                       $nilaiii[$a]=$min;
                                        echo " </tr>";
                                        $nog++;
                                      }
                                    ?>
                                    <tr>

                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                            <?php // print_r($nilaiii);  ?>

                            <?php
                             $baris=count($nilai);
                             $kolom=count($nilai[1]);
                              $jum=0;
                              $max=0;
                          //    echo 'Y +';
                         //     echo '<br>';
                            for($a=0; $a<$kolom; $a++){
                              $e=$a+1;
                           ///   echo 'Y '.$e.'+ ';
                               for($b=0; $b<$baris; $b++){

                              $c=$a+1;
                                 $jum=0;


                                 $nill[$a][$b]=$n[$b][$a];
                                  $ba=$baris-1;
                                if($b==$ba){

                                }else{
                           //       echo ', ';
                                }


                              ?>

                               <?php
                              }
                           $max=max($nill[$a]);
                           $nilaii[$a]=$max;
                              ?>


                               <?php
                            }
                          //   print_r($nilaii);

                            ?>

                              <?php
                             $baris=count($nilai);
                             $kolom=count($nilai[1]);
                              $jum=0;
                           //   echo 'Y -';
                           //   echo '<br>';
                            for($a=0; $a<$kolom; $a++){
                              $e=$a+1;
                          //    echo 'Y '.$e.'- ';
                               for($b=0; $b<$baris; $b++){

                              $c=$a+1;
                                 $jum=0;


                                $nill[$a][$b]=$n[$b][$a];
                                  $ba=$baris-1;
                                if($b==$ba){

                                }else{
                               //   echo ', ';
                                }


                              ?>

                               <?php
                              }
                            $max=min($nill[$a]);
                            $nilaiii[$a]=$max;
                              ?>


                               <?php
                            }

                           // print_r($nilaiii);
                            ?>

                            <hr>
                             <div style="text-align:center;">
                           <b>
                           Distance nilai terbobot solusi ideal Positif
                           
                           </b> 
                           </div>
                            <hr>
                            <div class="table-responsive">
                                <table class="table">
                             <?php
                             $baris=count($nilai);
                             $kolom=count($nilai[1]);
                              $jum=0;
                              $dpf=0;

                               for($b=0; $b<$baris; $b++){

                              $d=$b+1;
                              echo '<tr>';

                              $dpf=0;
                              for($a=0; $a<$kolom; $a++){
                              $c=$a+1;
                                 $jum=0;

                                echo '<td> D+ ['.$c.' - '.$d.'] <br>Akar^2(('.$n[$b][$a].' - '.$nilaii[$a].')^2)';
                                $dp=$n[$b][$a]-$nilaii[$a];
                                $dpdp=$dp*$dp;
                                echo ' = '.$dpdp.'</td> ';
                                $dpf+=$dpdp;
                                //echo $kuadrat[$a]=$nilai[$b][$a]*$nilai[$b][$a];
                                //echo '='.$jum+=$kuadrat[$a];
                               ?>

                               <?php
                              }
                              $dpff=sqrt($dpf);
                              $dppf[$b]=number_format($dpff,4);

                              echo   '<td>D+ '.$d.'  = akar^2('.$dpf.')'.' = '.$dppf[$b].'</td>';
                            // echo $jumm[$a]=number_format(sqrt($jum),3);
                              ?>

                               <?php
                                echo '<tr>';
                            }

                            ?>

                            </table>
                            </div>

                            <hr>
                             <div style="text-align:center;">
                           <b>
                           Distance nilai terbobot solusi ideal Negatif
                           
                           </b> 
                           </div>
                            <hr>

                            <div class="table-responsive" >
                                <table class="table">
                             <?php
                             $baris=count($nilai);
                             $kolom=count($nilai[1]);
                              $jum=0;
                              $dmf=0;

                               for($b=0; $b<$baris; $b++){

                              $d=$b+1;
                              echo '<tr>';

                              $dmf=0;
                              for($a=0; $a<$kolom; $a++){
                              $c=$a+1;
                                 $jum=0;

                                echo '<td> D - ['.$c.' - '.$d.'] <br> Akar^2(('.$n[$b][$a].' - '.$nilaiii[$a].')^2)';
                                $dm=$n[$b][$a]-$nilaiii[$a];
                                $dmdm=$dm*$dm;
                                echo ' = '.$dmdm;
                                $dmf+=$dmdm;
                                //echo $kuadrat[$a]=$nilai[$b][$a]*$nilai[$b][$a];
                                //echo '='.$jum+=$kuadrat[$a];
                               ?>

                               <?php
                              }
                              $dmff=sqrt($dmf);
                              $dmmf[$b]=number_format($dmff,4);

                              echo   '<td>D- '.$d.'  = akar^2('.$dmf.')'.' = '.$dmmf[$b].'</td>';
                            // echo $jumm[$a]=number_format(sqrt($jum),3);
                              ?>

                               <?php
                                echo '<tr>';
                            }

                            ?>

                            </table>
                            </div>

                            <div class="table-responsive" >
                                <table class="table">
                                     <tbody>

                            <?php
                            for($r=0;$r<$baris;$r++){
                              $rr=$r+1;
                              echo ' <tr><td>V-'.$rr.'</td><td>';

                             echo $dmmf[$r].' /  ('.$dppf[$r].' + '.$dmmf[$r].')';
                            // echo '<br>';
                             echo 'V-'.$rr;

                             $v=$dppf[$r]+$dmmf[$r];
                             $vv=number_format($dmmf[$r]/$v,3);
                             echo ' = '.$vv;
                           //  echo '<br>';
                            $ind=$index[$r];
                            echo ' </td></tr>';
                             $sql="update tbl_mahasiswa set nilai='$vv' where nim='$ind'";
                             mysqli_query($conn, $sql);
                           }
                            ?>
                                  </tbody>
                                </table>
                            </div>
                            <div class="table-responsive" style="display:none;">
                                <table class="table">
                                    <thead>
                                      <tr>
                                              <th>NIM</th>
                                              <th>NAMA</th>

                                              <th>Hasil<br>Nilai</th>
                                              <th><b>Rangking</b></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php
                                            $no=1;

                                            $sql="select * from tbl_mahasiswa where id_m='".$rowmat['0']."' order by nilai desc";
                                            $result=mysqli_query($conn,$sql);
                                            $a=0;
                                            while($row=mysqli_fetch_array($result,MYSQLI_NUM))
                                            {

                                        ?>
                                        <tr>
                                            <td><?php  echo $row['0']; ?></td>
                                            <td><?php  echo $row['1']; ?></td>
                                            <td><?php  echo $row['11']; ?></td>

                                            <td><?php echo $no; ?></td>
                                        </tr>
                                        <?php
                                            $no++;
                                            $a++;
                                        }
                                        ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                      <?php }else {
                        // code...
                      }
                    }
                       ?>
                    </div>
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
            <footer class="footer text-center"> 2018 &copy; Modified by Vany Rofika </footer>
        </div>
        <!-- /#page-wrapper -->
    </div>
    <div class="modal fade" id="form" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="exampleModalLabel">New message</h4>
          </div>
          <form method="post" action="">
              <div class="modal-body">
                  <div class="form-group">
                    <label for="message-text" class="control-label">NIM</label>
                    <input type="text" id="type" name="type" value="tambah" hidden >
                     <input type="text" id="a" name="a" hidden>

                    <input type="text" class="form-control" id="b" name="b">
                  </div>
                  <div class="form-group">
                    <label for="recipient-name" class="control-label">NAMA</label>
                    <input type="text" class="form-control" id="c" name="c">
                  </div>
                  <div class="form-group">
                    <label for="message-text" class="control-label">Produktivitas</label>
                    <input type="text" class="form-control" id="d" name="d">
                  </div>
                  <div class="form-group">
                    <label for="message-text" class="control-label">SEMESTER</label>
                    <input type="text" class="form-control" id="e" name="e">
                  </div>

                  </div>
                  <div class="modal-footer">
                    <button type="submit" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="submit" name="savedata"  class="btn btn-primary">Save</button>
                  </div>
           </form>
        </div>
      </div>
    </div>
    <div class="modal fade" id="deleteform" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
            <h4 class="modal-title" id="a">New message</h4>
          </div>
          <div class="modal-body">
            <form method="post" action="">
              <div class="form-group">
                <label for="message-text" class="control-label">NIM</label>
                <input type="text" id="a" name="a" hidden >
              </div>
              <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
              <button type="submit" name="hapus" class="btn btn-primary"  >Save</button>
            </form>
          </div>
          <div class="modal-footer">

          </div>
        </div>
      </div>
    </div>
    <!-- /#wrapper -->
    <!-- jQuery -->
    <script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap Core JavaScript -->
    <script src="bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Menu Plugin JavaScript -->
    <script src="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>
    <!--slimscroll JavaScript -->
    <script src="js/jquery.slimscroll.js"></script>
    <!--Wave Effects -->
    <script src="js/waves.js"></script>
    <!-- Custom Theme JavaScript -->
    <script src="js/custom.min.js"></script>
    <script type="text/javascript">
        $('#form').on('show.bs.modal', function (event) {
          var button = $(event.relatedTarget) // Button that triggered the modal
          var judul = button.data('judul')
          var type = button.data('type')
          var a = button.data('a')
          var b = button.data('b')
          var c = button.data('c')
          var d = button.data('d')
          var e = button.data('e')
          var modal = $(this)
          modal.find('.modal-title').text(judul)

          modal.find('.modal-body #type').val(type)
          modal.find('.modal-body #a').val(a)
          modal.find('.modal-body #b').val(b)
          modal.find('.modal-body #c').val(c)
          modal.find('.modal-body #d').val(d)
          modal.find('.modal-body #e').val(e)
        })

        $('#deleteform').on('show.bs.modal', function (event) {
          var button = $(event.relatedTarget) // Button that triggered the modal
          var a = button.data('a')
          var b = button.data('b')
          var modal = $(this)
          modal.find('.modal-title').text(a)
          modal.find('.modal-body #a').val(b)
        })
    </script>
</body>

</html>
