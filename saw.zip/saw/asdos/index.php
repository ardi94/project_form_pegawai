<?php
    include "koneksi/koneksi.php";
    include "sql/sql.php";

?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="description" content="">
<meta name="author" content="">
<link rel="icon" type="image/png" sizes="16x16" href="plugins/images/favicon.png">
<title>WEB - Seleksi Pemilihan Asisten Dosen</title>
<!-- Bootstrap Core CSS -->
<link href="bootstrap/dist/css/bootstrap.min.css" rel="stylesheet">
<!-- animation CSS -->
<link href="css/animate.css" rel="stylesheet">
<!-- Custom CSS -->
<link href="css/style.css" rel="stylesheet">
<!-- color CSS -->
<link href="css/colors/default.css" id="theme"  rel="stylesheet">
<!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
<!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
<![endif]-->

</head>
<body>
<!-- Preloader -->
<div class="preloader">
  <div class="cssload-speeding-wheel"></div>
</div>
<section id="wrapper" class="login-register">
  <div class="login-box">
    <div class="white-box">
      <form class="form-horizontal form-material" id="loginform" action="proses/proseslogin.php" method="post" >
        <h3 class="box-title m-b-20">Sign In</h3>
        <div class="form-group ">
          <div class="col-xs-12">
            <input class="form-control" type="text" name="user" required=""  placeholder="Username">
          </div>
        </div>
        <div class="form-group">
          <div class="col-xs-12">
            <input class="form-control" type="password" name="pass" required="" placeholder="Password">
          </div>
        </div>
        <div class="form-group">
          <div class="col-xs-12">
            <select class="form-control" name="roles" id="colorselector" type="text" required="" placeholder="Roles">
                <option value="admin" >Admin</option>
                <option value="mahasiswa" >Mahasiswa</option>
                <option value="dosen" >Dosen</option>
            </select>
          </div>

        </div>
        <div class="form-group">
          <div class="col-xs-12">
            <div class="output">
              <div id="mahasiswa" class="colors mahasiswa" hidden>
                <select class="form-control" name="matkul" type="text" placeholder="Matakuliah">
                  <?php
                  $sqlmat="select * from tbl_matkul ";
                  $resultt=mysqli_query($conn,$sqlmat);
                  while($rowmat=mysqli_fetch_array($resultt,MYSQLI_NUM))
                  {
                  ?>
                   <option value="<?php echo $rowmat['0']; ?>"><?php echo $rowmat['1']; ?></option>
                 <?php } ?>
                </select>
            </div>
            </div>
          </div>
        </div>
        <div class="form-group">
          <div class="col-md-12">
            <div class="checkbox checkbox-primary pull-left p-t-0">
              <input id="checkbox-signup" type="checkbox">
              <label for="checkbox-signup"> Remember me </label>
            </div>
             </div>
        </div>
        <div class="form-group text-center m-t-20">
          <div class="col-xs-12">
            <button class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" type="submit">Log In</button>
          </div>
        </div>
        <div class="row">

        </div>
        <div class="form-group m-b-0">
            <!--
          <div class="col-sm-12 text-center">
            <p>Don't have an account? <a href="register.html" class="text-primary m-l-5"><b>Sign Up</b></a></p>
          </div>
      -->
        </div>
      </form>
      <form class="form-horizontal" id="recoverform" action="" method="post">
        <div class="form-group ">
          <div class="col-xs-12">
            <h3>Daftar sebagai Asisten Dosen</h3>
            <p class="text-muted">Daftar Sebagai Asisten Dosen </p>
          </div>
        </div>
        <div class="form-group ">
          <div class="col-xs-12">
            <input class="form-control" type="text" name="user" required="" placeholder="Username">
          </div>
        </div>
        <div class="form-group">
          <div class="col-xs-12">
            <input class="form-control" type="password" name="pass" required="" placeholder="Password">
          </div>
        </div>
        <div class="form-group">
          <div class="col-xs-12">
            <input class="form-control" type="text" name="name" required="" placeholder="Nama Lengkap">
          </div>
        </div>
        <div class="form-group">
          <div class="col-xs-12">
            <input class="form-control" type="text" name="nim" required="" placeholder="NIM">
          </div>
        </div>
        <div class="form-group text-center m-t-20">
          <div class="col-xs-12">
            <button class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light"
             type="submit" name="daftar">Daftar</button>
Cancel          </div>
        </div>
      </form>
      

    </div>
  </div>
</section>
<!-- jQuery -->
<script src="plugins/bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap Core JavaScript -->
<script src="bootstrap/dist/js/bootstrap.min.js"></script>
<!-- Menu Plugin JavaScript -->
<script src="plugins/bower_components/sidebar-nav/dist/sidebar-nav.min.js"></script>

<!--slimscroll JavaScript -->
<script src="js/jquery.slimscroll.js"></script>
<!--Wave Effects -->
<script src="js/waves.js"></script>
<!-- Custom Theme JavaScript -->
<script src="js/custom.min.js"></script>
<!--Style Switcher -->
<script src="plugins/jQuery.style.switcher.js"></script>
<script type="text/javascript">
$(function() {
$('#colorselector').change(function(){
  $('.colors').hide();
  $('#' + $(this).val()).show();
});
});
</script>
</body>
</html>
